#!/usr/bin/env python3
"""
TOSEC ROM Sorter
================
Created by normanlove.

Run it, choose the folder that holds your TOSEC collection (Browse...; it is
remembered), and it scans that folder and every subfolder, then MOVES (never deletes) files into:

    <Kept folder>/<System>/[<A-Z>/]...        ROMs that passed your filters
    <Filtered folder>/<System>/[<A-Z>/]...    everything that was sorted out

* Choose what to sort out (languages, hacks, bad dumps, alpha/beta, demos, duplicates).
* Name the system folders for your frontend: Batocera, MiSTer, RetroPie, ES-DE,
  Recalbox, plain TOSEC names, or your own mapping.
* Optionally split every system folder into alphabetical subfolders.

Every run can write a CSV report explaining each decision (switch it off on the Output
tab), can build a single-file HTML library of your games, and keeps a journal so the run
can be undone. Settings are remembered. Requires Python 3.8+ with Tkinter.
"""

import csv
import datetime
import json
import os
import re
import shutil
import sys
import threading
import queue
import traceback
import zlib
import unicodedata
from collections import defaultdict
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
except ImportError:  # lets the sorting logic be imported/tested without a GUI
    tk = None

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #

if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
    SELF_PATH = Path(sys.executable).resolve()
else:
    APP_DIR = Path(__file__).resolve().parent
    SELF_PATH = Path(__file__).resolve()

JOURNAL = APP_DIR / "tosec_sorter_journal.json"
SETTINGS = APP_DIR / "tosec_sorter_settings.json"
SYSTEMS_FILE = APP_DIR / "tosec_sorter_systems.json"

IGNORE_EXT = {
    ".txt", ".nfo", ".dat", ".xml", ".jpg", ".jpeg", ".png", ".gif", ".bmp",
    ".htm", ".html", ".url", ".diz", ".py", ".pyw", ".pyc", ".exe",
    ".log", ".csv", ".ini", ".db", ".json", ".pdf", ".sfv", ".md5", ".sha1",
}

FLAG_INFO = {
    "cr": ("Cracked", "Hacks and modified"),
    "f": ("Fixed", "Hacks and modified"),
    "h": ("Hacked", "Hacks and modified"),
    "m": ("Modified", "Hacks and modified"),
    "p": ("Pirated", "Hacks and modified"),
    "t": ("Trained", "Hacks and modified"),
    "tr": ("Translated", "Hacks and modified"),
    "b": ("Bad dump", "Bad dumps"),
    "o": ("Over dump", "Bad dumps"),
    "u": ("Under dump", "Bad dumps"),
    "v": ("Virus infected", "Bad dumps"),
    "a": ("Alternate", "Alternates"),
}
HACK_FLAGS = {"cr", "f", "h", "m", "p", "t", "tr"}
DEFECT_FLAGS = {"b", "o", "u", "v"}
DEV_STATUS = ["alpha", "beta", "preview", "pre-release", "proto"]
DEMO_TAGS = {"demo", "demo-kiosk", "demo-playable", "demo-rolling", "demo-slideshow"}

COUNTRY_LANGS = {
    "US": {"en"}, "GB": {"en"}, "AU": {"en"}, "CA": {"en"}, "NZ": {"en"},
    "IE": {"en"}, "ZA": {"en"}, "EU": {"en"}, "IN": {"en"},
    "JP": {"ja"}, "DE": {"de"}, "AT": {"de"}, "CH": {"de"}, "FR": {"fr"},
    "ES": {"es"}, "MX": {"es"}, "AR": {"es"}, "IT": {"it"}, "NL": {"nl"},
    "BE": {"nl", "fr"}, "SE": {"sv"}, "DK": {"da"}, "NO": {"no"},
    "FI": {"fi"}, "PT": {"pt"}, "BR": {"pt"}, "PL": {"pl"}, "RU": {"ru"},
    "KR": {"ko"}, "CN": {"zh"}, "TW": {"zh"}, "HK": {"zh"}, "GR": {"el"},
    "CZ": {"cs"}, "HU": {"hu"}, "TR": {"tr"}, "IL": {"he"},
}

DATE_RE = re.compile(r"^[0-9x]{4}(-[0-9x]{2}(-[0-9x]{2})?)?$", re.I)
COUNTRY_RE = re.compile(r"^[A-Z]{2}(-[A-Z]{2})*$")
LANG_RE = re.compile(r"^[a-z]{2}(-[a-z]{2})*$")
MULTI_RE = re.compile(r"^M\d+$")
COPYRIGHT = {"CW", "FW", "GW", "LW", "PD", "SW"}
MEDIA_RE = re.compile(r"^(disk|disc|side|tape|part|cart\w*|cassette)\s+\w+", re.I)
FLAG_RE = re.compile(r"\[([^\]]*)\]")
PAREN_RE = re.compile(r"\(([^)]*)\)")


# --------------------------------------------------------------------------- #
# System folder layouts (Batocera, MiSTer, ...)
# --------------------------------------------------------------------------- #

# (canonical id, label, regex matched against the lower-cased TOSEC system name).
# Order matters: the first match wins, so specific rules come before general ones.
SYSTEM_RULES = [
    ("camplynx", "Camputers Lynx", r"camputers"),
    ("amiga_cd32", "Commodore Amiga CD32", r"cd32"),
    ("amiga_cdtv", "Commodore CDTV", r"cdtv"),
    ("amiga", "Commodore Amiga", r"amiga"),
    ("c128", "Commodore 128", r"commodore 128|\bc128\b"),
    ("c64", "Commodore 64", r"commodore 64|\bc64\b"),
    ("vic20", "Commodore VIC-20", r"vic-?20"),
    ("plus4", "Commodore 16/116/Plus-4", r"plus-?4|commodore 16\b|commodore 116\b|\bc16\b"),
    ("pet", "Commodore PET", r"commodore pet|\bpet\b"),
    ("atari2600", "Atari 2600", r"2600"),
    ("atari5200", "Atari 5200", r"5200"),
    ("atari7800", "Atari 7800", r"7800"),
    ("jaguar", "Atari Jaguar", r"jaguar"),
    ("lynx", "Atari Lynx", r"atari lynx"),
    ("xegs", "Atari XEGS", r"xegs"),
    ("atari800", "Atari 8-bit", r"atari (8-?bit|800|400|xl|xe)"),
    ("atarist", "Atari ST / Falcon", r"atari (st|falcon|tt)"),
    ("zx81", "Sinclair ZX81/ZX80", r"zx ?(81|80)"),
    ("zxspectrum", "Sinclair ZX Spectrum", r"spectrum"),
    ("ql", "Sinclair QL", r"sinclair ql"),
    ("gx4000", "Amstrad GX4000", r"gx4000"),
    ("pcw", "Amstrad PCW", r"pcw"),
    ("amstradcpc", "Amstrad CPC", r"amstrad cpc|\bcpc\b"),
    ("msx2plus", "MSX2+", r"msx2\+|msx2plus"),
    ("msxturbor", "MSX turboR", r"turbo ?r"),
    ("msx2", "MSX2", r"msx2"),
    ("msx1", "MSX", r"msx"),
    ("apple2gs", "Apple IIGS", r"iigs|2gs"),
    ("apple2", "Apple II", r"apple ii"),
    ("macintosh", "Apple Macintosh", r"macintosh"),
    ("archimedes", "Acorn Archimedes", r"archimedes"),
    ("bbcmicro", "Acorn BBC Micro", r"\bbbc\b"),
    ("electron", "Acorn Electron", r"electron"),
    ("atom", "Acorn Atom", r"acorn atom"),
    ("adam", "Coleco Adam", r"coleco adam"),
    ("colecovision", "ColecoVision", r"coleco"),
    ("intellivision", "Mattel Intellivision", r"intellivision"),
    ("vectrex", "GCE Vectrex", r"vectrex"),
    ("channelf", "Fairchild Channel F", r"channel f"),
    ("odyssey2", "Magnavox Odyssey 2 / Videopac", r"odyssey|videopac"),
    ("astrocade", "Bally Astrocade", r"astrocade"),
    ("arcadia", "Emerson Arcadia 2001", r"arcadia"),
    ("fds", "Famicom Disk System", r"famicom disk|\bfds\b"),
    ("snes", "Super Nintendo / Super Famicom", r"super (nintendo|famicom|nes)|snes"),
    ("nes", "Nintendo NES / Famicom", r"entertainment system|famicom|\bnes\b"),
    ("n64", "Nintendo 64", r"nintendo 64|\bn64\b"),
    ("gba", "Game Boy Advance", r"advance"),
    ("gbc", "Game Boy Color", r"game ?boy color"),
    ("gb", "Game Boy", r"game ?boy"),
    ("gamegear", "Sega Game Gear", r"game gear"),
    ("mastersystem", "Sega Master System", r"master system"),
    ("segacd", "Sega Mega CD / Sega CD", r"mega cd|sega cd"),
    ("sega32x", "Sega 32X", r"32x"),
    ("sg1000", "Sega SG-1000", r"sg-?1000"),
    ("megadrive", "Sega Mega Drive / Genesis", r"mega ?drive|genesis"),
    ("saturn", "Sega Saturn", r"saturn"),
    ("dreamcast", "Sega Dreamcast", r"dreamcast"),
    ("pcenginecd", "PC Engine CD", r"(pc engine|turbo ?grafx).*cd"),
    ("pcengine", "PC Engine / TurboGrafx-16", r"pc engine|turbo ?grafx|supergrafx"),
    ("neogeocd", "Neo Geo CD", r"neo ?geo cd"),
    ("ngpc", "Neo Geo Pocket Color", r"pocket color"),
    ("ngp", "Neo Geo Pocket", r"neo ?geo pocket"),
    ("neogeo", "Neo Geo", r"neo ?geo"),
    ("wswanc", "WonderSwan Color", r"wonderswan color"),
    ("wswan", "WonderSwan", r"wonderswan"),
    ("ps2", "Sony PlayStation 2", r"playstation 2"),
    ("psx", "Sony PlayStation", r"playstation"),
    ("3do", "3DO", r"\b3do\b"),
    ("cdi", "Philips CD-i", r"\bcd-?i\b"),
    ("coco", "Tandy Color Computer", r"color computer|coco|trs-?80 color"),
    ("trs80", "Tandy TRS-80", r"trs-?80"),
    ("ti99", "Texas Instruments TI-99", r"ti-?99"),
    ("thomson", "Thomson MO/TO", r"thomson"),
    ("oric", "Oric", r"oric"),
    ("dragon", "Dragon 32/64", r"dragon"),
    ("samcoupe", "SAM Coupe", r"sam coup|mgt sam"),
    ("x68000", "Sharp X68000", r"x68000"),
    ("pc88", "NEC PC-8801", r"pc-?88"),
    ("pc98", "NEC PC-9801", r"pc-?98"),
    ("fm7", "Fujitsu FM-7", r"fm-?7"),
    ("fmtowns", "Fujitsu FM Towns", r"fm towns"),
    ("enterprise", "Enterprise", r"enterprise"),
]
_RULES = [(c, re.compile(rx, re.I)) for c, _l, rx in SYSTEM_RULES]


def canonical_system(name):
    low = name.lower()
    for canon, rx in _RULES:
        if rx.search(low):
            return canon
    return None


def _table(text):
    return {k.strip(): v.strip() for k, v in
            (p.split("=", 1) for p in text.replace("\n", ";").split(";") if "=" in p)}


# Batocera: folder names checked against the Batocera wiki system list.
BATOCERA = _table("""
amiga=amiga500; amiga_cd32=amigacd32; amiga_cdtv=amigacdtv; c64=c64; c128=c128; vic20=c20;
plus4=cplus4; pet=pet; atari2600=atari2600; atari5200=atari5200; atari7800=atari7800;
jaguar=jaguar; lynx=lynx; atari800=atari800; xegs=xegs; atarist=atarist;
zxspectrum=zxspectrum; zx81=zx81; amstradcpc=amstradcpc; gx4000=gx4000; pcw=pcw;
msx1=msx1; msx2=msx2; msx2plus=msx2+; msxturbor=msxturbor; apple2=apple2; apple2gs=apple2gs;
macintosh=macintosh; archimedes=archimedes; bbcmicro=bbcmicro; electron=electron; atom=atom;
colecovision=colecovision; adam=adam; intellivision=intellivision; vectrex=vectrex;
channelf=channelf; odyssey2=odyssey2; astrocade=astrocade; arcadia=arcadia; nes=nes; fds=fds;
snes=snes; n64=n64; gb=gb; gbc=gbc; gba=gba; mastersystem=mastersystem; gamegear=gamegear;
megadrive=megadrive; segacd=megacd; sega32x=sega32x; sg1000=sg1000; saturn=saturn;
dreamcast=dreamcast; pcengine=pcengine; pcenginecd=pcenginecd; neogeo=neogeo;
neogeocd=neogeocd; ngp=ngp; ngpc=ngpc; wswan=wswan; wswanc=wswanc; psx=psx; ps2=ps2;
3do=3do; cdi=cdi; trs80=trs80; coco=coco; ti99=ti99; thomson=thomson; oric=oricatmos;
dragon=dragon64; samcoupe=samcoupe; x68000=x68000; pc88=pc88; pc98=pc98; fm7=fm7;
fmtowns=fmtowns; camplynx=camplynx; enterprise=enterprise
""")

# MiSTer: the /media/fat/games/<folder> names (case-insensitive on the device).
MISTER = _table("""
amiga=Amiga; amiga_cd32=Amiga; amiga_cdtv=Amiga; c64=C64; c128=C128; vic20=VIC20; plus4=C16;
pet=PET2001; atari2600=ATARI2600; atari5200=ATARI5200; atari7800=ATARI7800; lynx=AtariLynx;
atari800=ATARI800; atarist=AtariST; zxspectrum=Spectrum; zx81=ZX81; ql=QL;
amstradcpc=Amstrad; pcw=Amstrad PCW; msx1=MSX; msx2=MSX; msx2plus=MSX; msxturbor=MSX;
apple2=Apple-II; macintosh=MACPLUS; archimedes=ARCHIE; bbcmicro=BBCMicro;
electron=AcornElectron; atom=AcornAtom; colecovision=Coleco; intellivision=Intellivision;
vectrex=VECTREX; channelf=ChannelF; odyssey2=ODYSSEY2; astrocade=Astrocade; arcadia=Arcadia;
nes=NES; fds=NES; snes=SNES; n64=N64; gb=GAMEBOY; gbc=GAMEBOY; gba=GBA; mastersystem=SMS;
gamegear=SMS; megadrive=Genesis; segacd=MegaCD; sega32x=S32X; sg1000=SG1000; saturn=Saturn;
pcengine=TGFX16; pcenginecd=TGFX16-CD; neogeo=NeoGeo; neogeocd=NeoGeo; wswan=WonderSwan;
wswanc=WonderSwan; psx=PSX; cdi=CD-i; trs80=TRS-80; ti99=TI-99_4A; oric=Oric;
samcoupe=SAMCOUPE; x68000=X68000; pc88=PC8801
""")

# RetroPie: /home/pi/RetroPie/roms/<folder>
RETROPIE = _table("""
amiga=amiga; amiga_cd32=amiga; amiga_cdtv=amiga; c64=c64; c128=c128; vic20=vic20; plus4=plus4;
pet=pet; atari2600=atari2600; atari5200=atari5200; atari7800=atari7800; jaguar=atarijaguar;
lynx=atarilynx; atari800=atari800; xegs=atari800; atarist=atarist; zxspectrum=zxspectrum;
zx81=zx81; amstradcpc=amstradcpc; msx1=msx; msx2=msx; msx2plus=msx; msxturbor=msx;
apple2=apple2; macintosh=macintosh; bbcmicro=bbcmicro; colecovision=coleco;
intellivision=intellivision; vectrex=vectrex; channelf=channelf; odyssey2=videopac;
astrocade=astrocade; nes=nes; fds=fds; snes=snes; n64=n64; gb=gb; gbc=gbc; gba=gba;
mastersystem=mastersystem; gamegear=gamegear; megadrive=megadrive; segacd=segacd;
sega32x=sega32x; sg1000=sg-1000; saturn=saturn; dreamcast=dreamcast; pcengine=pcengine;
pcenginecd=pcenginecd; neogeo=neogeo; ngp=ngp; ngpc=ngpc; wswan=wonderswan;
wswanc=wonderswancolor; psx=psx; 3do=3do; trs80=trs-80; coco=coco; ti99=ti99; oric=oric;
dragon=dragon32; x68000=x68000
""")

# ES-DE (EmulationStation Desktop Edition) ROM folder names.
ESDE = _table("""
amiga=amiga; amiga_cd32=amigacd32; amiga_cdtv=cdtv; c64=c64; c128=c128; vic20=vic20;
atari2600=atari2600; atari5200=atari5200; atari7800=atari7800; jaguar=atarijaguar;
lynx=atarilynx; atari800=atari800; xegs=atarixe; atarist=atarist; zxspectrum=zxspectrum;
zx81=zx81; amstradcpc=amstradcpc; gx4000=gx4000; msx1=msx; msx2=msx2; msx2plus=msx2;
msxturbor=msxturbor; apple2=apple2; apple2gs=apple2gs; macintosh=macintosh;
archimedes=archimedes; bbcmicro=bbcmicro; electron=electron; colecovision=colecovision;
intellivision=intellivision; vectrex=vectrex; channelf=channelf; odyssey2=videopac;
astrocade=astrocade; arcadia=arcadia; nes=nes; fds=fds; snes=snes; n64=n64; gb=gb; gbc=gbc;
gba=gba; mastersystem=mastersystem; gamegear=gamegear; megadrive=megadrive; segacd=segacd;
sega32x=sega32x; sg1000=sg-1000; saturn=saturn; dreamcast=dreamcast; pcengine=pcengine;
pcenginecd=pcenginecd; neogeo=neogeo; neogeocd=neogeocd; ngp=ngp; ngpc=ngpc;
wswan=wonderswan; wswanc=wonderswancolor; psx=psx; ps2=ps2; 3do=3do; cdi=cdimono1;
trs80=trs-80; coco=coco; ti99=ti99; oric=oric; dragon=dragon32; samcoupe=samcoupe;
x68000=x68000; pc88=pc88; pc98=pc98; fm7=fm7; fmtowns=fmtowns
""")

# Recalbox (best effort - use the mapping file to correct anything you need).
RECALBOX = _table("""
amiga=amiga600; amiga_cd32=amigacd32; c64=c64; vic20=vic20; atari2600=atari2600;
atari5200=atari5200; atari7800=atari7800; jaguar=jaguar; lynx=lynx; atari800=atari800;
atarist=atarist; zxspectrum=zxspectrum; zx81=zx81; amstradcpc=amstradcpc; gx4000=amstradgx4000;
msx1=msx1; msx2=msx2; msxturbor=msxturbor; apple2=apple2; apple2gs=apple2gs;
colecovision=colecovision; intellivision=intellivision; vectrex=vectrex; channelf=channelf;
odyssey2=o2em; nes=nes; fds=fds; snes=snes; n64=n64; gb=gb; gbc=gbc; gba=gba;
mastersystem=mastersystem; gamegear=gamegear; megadrive=megadrive; segacd=segacd;
sega32x=sega32x; sg1000=sg1000; saturn=saturn; dreamcast=dreamcast; pcengine=pcengine;
pcenginecd=pcenginecd; neogeo=neogeo; neogeocd=neogeocd; ngp=ngp; ngpc=ngpc; wswan=wswan;
wswanc=wswanc; psx=psx; 3do=3do; oric=oricatmos; samcoupe=samcoupe; x68000=x68000; pc88=pc88;
pc98=pc98
""")

TOSEC_LAYOUT = "TOSEC names"
CUSTOM_LAYOUT = "Custom"
LAYOUTS = {
    TOSEC_LAYOUT: {},
    "Batocera": BATOCERA,
    "MiSTer": MISTER,
    "RetroPie": RETROPIE,
    "ES-DE": ESDE,
    "Recalbox": RECALBOX,
    CUSTOM_LAYOUT: {},
}
LAYOUT_HINTS = {
    TOSEC_LAYOUT: "System folders keep their TOSEC names (e.g. Commodore Amiga).",
    "Batocera": "Copy the contents of the kept folder into /userdata/roms/ (the 'share/roms' network folder).",
    "MiSTer": "Copy the contents of the kept folder into /media/fat/games/ (the 'games' folder on the SD card).",
    "RetroPie": "Copy the contents of the kept folder into ~/RetroPie/roms/ (the 'roms' network share).",
    "ES-DE": "Copy the contents of the kept folder into your ES-DE ROMs directory.",
    "Recalbox": "Copy the contents of the kept folder into /recalbox/share/roms/. (Best-effort names - check them.)",
    CUSTOM_LAYOUT: "Folder names come entirely from tosec_sorter_systems.json (use 'Export mapping file' below).",
}

# Folder name -> canonical id, used to recognise already-sorted folders on re-runs.
REVERSE = {}
for _name, _tbl in LAYOUTS.items():
    for _canon, _folder in _tbl.items():
        REVERSE.setdefault(_folder.lower(), _canon)


def _safe_folder(name):
    return re.sub(r'[<>:"/\\|?*]', "_", str(name)).strip(" .")


def load_overrides(layout):
    """User overrides from tosec_sorter_systems.json -> {lowercase key: folder}."""
    try:
        data = json.loads(SYSTEMS_FILE.read_text(encoding="utf-8"))
        raw = data.get("overrides", {}).get(layout, {})
        return {str(k).strip().lower(): _safe_folder(v) for k, v in raw.items() if _safe_folder(v)}
    except (OSError, ValueError, AttributeError):
        return {}


def export_systems_file():
    """Write an editable reference/override file, keeping any overrides already there."""
    existing = {}
    try:
        existing = json.loads(SYSTEMS_FILE.read_text(encoding="utf-8")).get("overrides", {})
    except (OSError, ValueError, AttributeError):
        pass
    data = {
        "_help": [
            "Put your own folder names under 'overrides', inside the layout you use.",
            "A key can be a system id from '_system_ids' (e.g. \"amiga\") or the TOSEC system name",
            "in lower case (e.g. \"commodore amiga\"). Example: \"Batocera\": {\"amiga\": \"amiga1200\"}",
            "'_system_ids' and '_layout_defaults' are for reference only and are ignored when loading.",
        ],
        "overrides": existing or {name: {} for name in LAYOUTS if name != TOSEC_LAYOUT},
        "_system_ids": {c: label for c, label, _rx in SYSTEM_RULES},
        "_layout_defaults": {n: t for n, t in LAYOUTS.items() if t},
    }
    SYSTEMS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return SYSTEMS_FILE


class SystemMapper:
    """Turns a TOSEC system name into the folder name the chosen layout expects."""

    def __init__(self, layout):
        self.layout = layout if layout in LAYOUTS else TOSEC_LAYOUT
        self.table = LAYOUTS[self.layout]
        self.overrides = load_overrides(self.layout)
        self.unmapped = set()
        self.used = {}

    def resolve(self, name, existing=False):
        """Return (folder_name, system_id). system_id is stable across layouts."""
        low = name.lower()
        canon = REVERSE.get(low) if existing else None
        canon = canon or canonical_system(name)
        sysid = canon or low
        if low in self.overrides:
            folder = self.overrides[low]
        elif canon and canon in self.overrides:
            folder = self.overrides[canon]
        elif self.layout == TOSEC_LAYOUT or name == "Unknown System":
            folder = name
        elif canon and canon in self.table:
            folder = self.table[canon]
        else:
            folder = name
            if not existing:
                self.unmapped.add(name)
        if not existing:
            self.used[name] = folder
        return folder, sysid


# --------------------------------------------------------------------------- #
# Options
# --------------------------------------------------------------------------- #

class Options:
    def __init__(self):
        self.root = ""                     # the ROM folder to sort (chosen in the GUI)
        # language
        self.filter_language = True
        self.languages = "en"
        self.missing_lang_by_country = True
        self.accept_multi = True
        # what to sort out
        self.sort_flags = sorted(HACK_FLAGS | DEFECT_FLAGS)
        self.sort_dev = []
        self.sort_demo = False
        # duplicates
        self.dedup = True
        self.fallback = False
        self.prefer_newest = True
        self.region_priority = ""
        # layout
        self.layout = TOSEC_LAYOUT
        self.alpha = False
        self.alpha_group = 1
        self.alpha_filtered = False
        self.group_categories = False      # keep TOSEC categories (Games, Demos...) inside each system folder
        # output
        self.eng_dir = "English ROMs"
        self.other_dir = "Filtered Out"
        self.split_by_reason = False
        self.skip_levels = 0
        self.remove_empty = False
        self.write_csv = True              # CSV report after each run
        self.build_library = False         # HTML library after each real run
        self.library_filtered = False      # ...also listing the filtered-out games

    def to_dict(self):
        return dict(self.__dict__)

    @classmethod
    def from_dict(cls, d):
        o = cls()
        for k, v in (d or {}).items():
            if k in o.__dict__:
                setattr(o, k, v)
        return o

    def save(self):
        try:
            SETTINGS.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        except OSError:
            pass

    @classmethod
    def load(cls):
        try:
            return cls.from_dict(json.loads(SETTINGS.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            return cls()

    def target_langs(self):
        langs = [x.strip().lower() for x in re.split(r"[,\s;]+", self.languages) if x.strip()]
        return langs or ["en"]

    def regions(self):
        return [x.strip().upper() for x in re.split(r"[,\s;]+", self.region_priority) if x.strip()]

    def normalise(self):
        self.eng_dir = _safe_folder(self.eng_dir) or "English ROMs"
        self.other_dir = _safe_folder(self.other_dir) or "Filtered Out"
        if self.eng_dir.lower() == self.other_dir.lower():
            self.other_dir += " (filtered)"
        for attr, lo, hi, default in (("skip_levels", 0, 10, 0), ("alpha_group", 1, 13, 1)):
            try:
                setattr(self, attr, min(hi, max(lo, int(getattr(self, attr)))))
            except (TypeError, ValueError):
                setattr(self, attr, default)
        if self.layout not in LAYOUTS:
            self.layout = TOSEC_LAYOUT
        return self


# --------------------------------------------------------------------------- #
# TOSEC filename parsing
# --------------------------------------------------------------------------- #

def _extract_version(title):
    m = re.search(r"\s[vV](\d+(?:[.\-]\d+)*)([a-zA-Z]?)(?=\s|$)", title)
    if m:
        nums = tuple(int(x) for x in re.split(r"[.\-]", m.group(1)))
        if m.group(2):
            nums += (ord(m.group(2).lower()),)
        return (title[:m.start()] + title[m.end():]).strip(), nums
    m = re.search(r"\sRev\s?(\w+)(?=\s|$)", title, re.I)
    if m:
        v = m.group(1)
        val = (int(v),) if v.isdigit() else (ord(v[0].lower()),)
        return (title[:m.start()] + title[m.end():]).strip(), val
    return title, ()


def _normalise_title(title):
    t = title.lower().replace("&", "and")
    m = re.match(r"^(.*),\s*(the|a|an)$", t)
    if m:
        t = f"{m.group(2)} {m.group(1)}"
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


class RomInfo:
    pass


def parse_rom(path, system, sysid=None):
    info = RomInfo()
    info.path = path
    info.system = system                       # folder name in the chosen layout
    info.sysid = sysid or system.lower()       # layout-independent id, used for grouping
    info.name = path.name
    stem = path.stem

    flags = [f.strip().lower() for f in FLAG_RE.findall(stem)]
    tokens = [f.split()[0] for f in flags if f.split()]
    info.flag_bases = [re.sub(r"\d+$", "", t) for t in tokens if t != "!"]
    info.hack = any(b in HACK_FLAGS for b in info.flag_bases)
    info.defect = any(b in DEFECT_FLAGS for b in info.flag_bases)
    info.alt = sum(1 for b in info.flag_bases if b == "a")
    info.verified = "!" in tokens
    info.other_flags = len(info.flag_bases)

    clean = FLAG_RE.sub("", stem).strip()
    idx = clean.find("(")
    title_part = (clean[:idx] if idx >= 0 else clean).strip()
    groups = [g.strip() for g in PAREN_RE.findall(clean)]

    date_i = next((i for i, g in enumerate(groups) if DATE_RE.match(g)), None)
    if date_i is not None:
        pre = groups[:date_i]
        rest = groups[date_i + 2:]
        year_txt = groups[date_i][:4].lower().replace("x", "0")
        year = int(year_txt) if year_txt.isdigit() else 9999
        if year < 1900:
            year = 9999
    else:
        pre, rest, year = [], groups, 9999
    info.year = year

    info.countries, info.langs, info.multi = [], [], False
    for g in rest:
        if not info.countries and COUNTRY_RE.match(g) and g not in COPYRIGHT:
            info.countries = g.split("-")
        elif not info.langs and LANG_RE.match(g):
            info.langs = g.split("-")
        elif MULTI_RE.match(g):
            info.multi = True

    lowered = [g.lower() for g in groups]
    info.dev = {g for g in lowered if g in DEV_STATUS}
    info.demo = any(g in DEMO_TAGS for g in lowered)
    info.devpen = 1 if info.dev else 0
    media = tuple(sorted(g for g in lowered if MEDIA_RE.match(g)))

    title, info.version = _extract_version(title_part)
    info.key = (info.sysid, _normalise_title(title), tuple(g.lower() for g in pre), media)
    return info


# --------------------------------------------------------------------------- #
# Filtering and ranking
# --------------------------------------------------------------------------- #

def language_match(info, opts):
    if not opts.filter_language:
        return True, ",".join(sorted(info.langs)) or "-"
    targets = opts.target_langs()
    if info.langs:
        for t in targets:
            if t in info.langs:
                return True, t
        return False, ""
    if info.multi:
        return (True, targets[0]) if opts.accept_multi else (False, "")
    if not opts.missing_lang_by_country:
        return False, ""
    if not info.countries:
        return True, targets[0]
    for t in targets:
        if any(t in COUNTRY_LANGS.get(c, set()) for c in info.countries):
            return True, t
    return False, ""


def exclusion_reason(info, opts):
    chosen = set(opts.sort_flags)
    for b in info.flag_bases:
        if b in chosen and b in FLAG_INFO:
            label, cat = FLAG_INFO[b]
            return cat, f"{label} [{b}]"
    for d in DEV_STATUS:
        if d in info.dev and d in opts.sort_dev:
            return "Pre-release", f"Development build ({d})"
    if info.demo and opts.sort_demo:
        return "Demos", "Demo"
    return None


def _version_value(v):
    return sum(min(p, 999) * 1000 ** (5 - i) for i, p in enumerate(v[:6]))


def rank(info, opts):
    prio = opts.regions()
    idxs = [prio.index(c) for c in info.countries if c in prio]
    region = -min(idxs) if idxs else -len(prio)
    ver = _version_value(info.version)
    return (not info.hack, not info.defect, -info.devpen, info.verified, -info.alt,
            ver if opts.prefer_newest else -ver, region, -info.year, -info.other_flags)


# --------------------------------------------------------------------------- #
# Alphabetical subfolders
# --------------------------------------------------------------------------- #

def alpha_bucket(name, size=1):
    """Folder for a ROM name: '0-9', 'A'..'Z' (or groups like 'A-C'), or '#'."""
    ch = next((c for c in unicodedata.normalize("NFKD", name) if c.isalnum()), "")
    if not ch:
        return "#"
    if ch.isdigit():
        return "0-9"
    up = ch.upper()
    if len(up) == 1 and "A" <= up <= "Z":
        if size <= 1:
            return up
        i = ord(up) - 65
        start = (i // size) * size
        end = min(start + size - 1, 25)
        return up if start == end else f"{chr(65 + start)}-{chr(65 + end)}"
    return "#"


# --------------------------------------------------------------------------- #
# Scanning and planning
# --------------------------------------------------------------------------- #

def clean_system(name):
    s = re.sub(r"\s*\(TOSEC[^)]*\)", "", name)
    s = s.split(" - ")[0].strip()
    s = re.sub(r'[<>:"/\\|?*]', "_", s).strip(" .")
    return s or "Unknown System"


ALPHA_DIR_RE = re.compile(r"^(0-9|#|[A-Z](-[A-Z])?)$")


def clean_category(name):
    """'Commodore Amiga - Games - [ADF] (TOSEC-v2020)' -> 'Games'.
    Format tags such as [ADF] are dropped so every format of one kind lands together."""
    s = re.sub(r"\s*\(TOSEC[^)]*\)", "", name)
    parts = [x.strip() for x in s.split(" - ")][1:]
    parts = [x for x in parts if x and not x.startswith("[")]
    return re.sub(r'[<>:"/\\|?*]', "_", " - ".join(parts)).strip(" .")


def category_for(dirs):
    """The TOSEC category (Games, Demos, Applications...) from the source folder names."""
    if not dirs:
        return ""
    cat = clean_category(dirs[0])
    if not cat and len(dirs) > 1 and not dirs[1].startswith("["):
        cat = clean_category("x - " + dirs[1])
    return cat


def system_for(path, root, opts, mapper):
    """Return (system folder, system id, category folder or '')."""
    rel = path.relative_to(root).parts
    if rel[0] == opts.eng_dir:                      # already-sorted file from an earlier run
        name = rel[1] if len(rel) > 2 else "Unknown System"
        cat = ""
        if opts.group_categories and len(rel) > 3 and not ALPHA_DIR_RE.match(rel[2]):
            cat = rel[2]
        return mapper.resolve(name, existing=True) + (cat,)
    dirs = list(rel[:-1])[opts.skip_levels:]
    while len(dirs) > 1 and dirs[0].lower().startswith("tosec"):
        dirs.pop(0)
    cat = category_for(dirs) if opts.group_categories else ""
    return mapper.resolve(clean_system(dirs[0]) if dirs else "Unknown System") + (cat,)


class Decision:
    def __init__(self, info, keep, category, reason, dest_dir, opts):
        self.info, self.keep, self.category, self.reason = info, keep, category, reason
        parts = [dest_dir, info.system]
        if getattr(info, "cat", ""):
            parts.append(info.cat)
        if opts.alpha and (keep or opts.alpha_filtered):
            parts.append(alpha_bucket(info.name, opts.alpha_group))
        self.dest = Path(*parts) / info.name


def build_plan(root, opts, log):
    """Return (plan, mapper)."""
    opts.normalise()
    eng_root = root / opts.eng_dir
    other_root = root / opts.other_dir
    mapper = SystemMapper(opts.layout)
    skip_files = {SELF_PATH, JOURNAL, SETTINGS, SYSTEMS_FILE}
    entries = []
    for dirpath, dirnames, filenames in os.walk(root):
        dp = Path(dirpath)
        dirnames[:] = sorted(d for d in dirnames
                             if not d.startswith(".") and d != "__pycache__"
                             and (dp / d) != other_root)
        for fn in sorted(filenames):
            p = dp / fn
            if (fn.startswith(".") or p.suffix.lower() in IGNORE_EXT or p in skip_files
                    or fn.lower().startswith("readme")):
                continue
            entries.append(p)
    log(f"Found {len(entries):,} files to examine.")

    infos = []
    for p in entries:
        folder, sysid, cat = system_for(p, root, opts, mapper)
        info = parse_rom(p, folder, sysid)
        info.cat = cat
        infos.append(info)

    plan = []

    def filtered(info, cat, reason):
        d = other_root / cat if opts.split_by_reason else other_root
        plan.append(Decision(info, False, cat, reason, d, opts))

    groups = defaultdict(list)
    for i in infos:
        ok, bucket = language_match(i, opts)
        if not ok:
            filtered(i, "Other languages", "Language not selected")
        else:
            groups[(i.key, bucket)].append(i)

    for items in groups.values():
        items.sort(key=lambda x: x.name.lower())
        excl = {id(i): exclusion_reason(i, opts) for i in items}
        allowed = [i for i in items if excl[id(i)] is None]
        fallback = False
        if not allowed and opts.fallback:
            allowed = [max(items, key=lambda x: rank(x, opts))]
            fallback = True
        winner = None
        if opts.dedup and allowed:
            winner = max(allowed, key=lambda x: rank(x, opts))
            keepers = [winner]
        else:
            keepers = allowed
        keep_ids = {id(i) for i in keepers}
        for i in items:
            if id(i) in keep_ids:
                why = "Kept (only copy available)" if fallback else "Kept"
                plan.append(Decision(i, True, "", why, eng_root, opts))
            elif excl[id(i)]:
                filtered(i, *excl[id(i)])
            else:
                filtered(i, "Duplicates", f"Duplicate - superseded by: {winner.name}")
    return plan, mapper


def unique_path(p):
    if not p.exists():
        return p
    n = 2
    while True:
        c = p.with_name(f"{p.stem} ({n}){p.suffix}")
        if not c.exists():
            return c
        n += 1


def remove_empty_dirs(root, protected):
    removed = 0
    for dirpath, dirnames, filenames in os.walk(root, topdown=False):
        dp = Path(dirpath)
        if dp == root or any(dp == pr or pr in dp.parents for pr in protected):
            continue
        try:
            if not any(dp.iterdir()):
                dp.rmdir()
                removed += 1
        except OSError:
            pass
    return removed


def write_report(root, plan, opts):
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = root / f"tosec_sorter_report_{stamp}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Result", "Category", "System folder", "Reason", "File",
                    "Source path", "Destination path"])
        for d in plan:
            w.writerow(["Kept" if d.keep else "Filtered out", d.category, d.info.system,
                        d.reason, d.info.name, str(d.info.path.relative_to(root)),
                        str(d.dest.relative_to(root))])
    return path


def execute_plan(root, plan, opts, log, progress):
    moved, journal = 0, []
    total = len(plan)
    for n, d in enumerate(plan, 1):
        if d.dest != d.info.path:
            try:
                d.dest.parent.mkdir(parents=True, exist_ok=True)
                dest = unique_path(d.dest)
                shutil.move(str(d.info.path), str(dest))
                journal.append([str(d.info.path), str(dest)])
                moved += 1
            except Exception as e:
                log(f"ERROR moving {d.info.path}: {e}")
        if n % 50 == 0 or n == total:
            progress(n, total)
    with open(JOURNAL, "w", encoding="utf-8") as f:
        json.dump({"root": str(root), "moves": journal}, f)
    removed = remove_empty_dirs(root / opts.eng_dir, []) + remove_empty_dirs(root / opts.other_dir, [])
    if opts.remove_empty:
        removed += remove_empty_dirs(root, [root / opts.eng_dir, root / opts.other_dir])
    if removed:
        log(f"Removed {removed:,} empty folders.")
    return moved


def undo_last_run(root, log, progress):
    if not JOURNAL.exists():
        log("Nothing to undo (no journal found).")
        return
    with open(JOURNAL, encoding="utf-8") as f:
        journal = json.load(f)
    if isinstance(journal, dict):          # newer journals remember the folder they ran in
        if journal.get("root"):
            root = Path(journal["root"])
        journal = journal.get("moves", [])
    total, restored = len(journal), 0
    for n, (src, dst) in enumerate(reversed(journal), 1):
        s, d = Path(src), Path(dst)
        try:
            if d.exists() and not s.exists():
                s.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(d), str(s))
                restored += 1
        except Exception as e:
            log(f"ERROR restoring {d}: {e}")
        if n % 50 == 0 or n == total:
            progress(n, total)
    remove_empty_dirs(root, [])
    target = JOURNAL.with_suffix(".undone.json")
    if target.exists():
        target.unlink()
    JOURNAL.rename(target)
    log(f"Undo complete: {restored:,} files returned to their original locations.")


# --------------------------------------------------------------------------- #
# GUI
# --------------------------------------------------------------------------- #

# >>> ROM LIBRARY (identical in tosec_sorter.py and rom_archiver.py) >>>
# --------------------------------------------------------------------------- #
# HTML library: one self-contained page (inline CSS/JS/data, no other files)
# --------------------------------------------------------------------------- #

LIB_FILENAME = "ROM Library.html"
LIB_REASONS = {"other languages", "duplicates", "hacks and modified", "bad dumps",
               "alternates", "pre-release", "demos"}
LIB_SKIP_EXT = {".txt", ".nfo", ".dat", ".xml", ".jpg", ".jpeg", ".png", ".gif", ".bmp",
                ".htm", ".html", ".url", ".diz", ".py", ".pyw", ".pyc", ".exe",
                ".log", ".csv", ".ini", ".db", ".json", ".pdf", ".sfv", ".md5", ".sha1",
                ".part"}
LIB_HACK = {"cr", "f", "h", "m", "p", "t", "tr"}
LIB_DEFECT = {"b", "o", "u", "v"}
LIB_DEV = {"alpha", "beta", "preview", "pre-release", "proto"}
LIB_COPYRIGHT = {"CW", "FW", "GW", "LW", "PD", "SW"}
LIB_DATE_RE = re.compile(r"^[0-9x]{4}(-[0-9x]{2}(-[0-9x]{2})?)?$", re.I)
LIB_COUNTRY_RE = re.compile(r"^[A-Z]{2}(-[A-Z]{2})*$")
LIB_LANG_RE = re.compile(r"^[a-z]{2}(-[a-z]{2})*$")
LIB_MEDIA_RE = re.compile(r"^(disk|disc|side|tape|part|cart\w*|cassette)\s+\w+", re.I)
LIB_FLAG_RE = re.compile(r"\[([^\]]*)\]")
LIB_PAREN_RE = re.compile(r"\(([^)]*)\)")


def lib_split_name(filename):
    """'Game (1990)(Pub).adf.zip' -> ('Game (1990)(Pub)', 'adf', True)."""
    n, zipped = filename, False
    if n.lower().endswith(".zip"):
        n, zipped = n[:-4], True
    m = re.search(r"\.([A-Za-z][A-Za-z0-9]{0,3})$", n)
    if m and (zipped or len(m.group(1)) <= 4):
        return n[:m.start()], m.group(1).lower(), zipped
    return n, ("zip" if zipped else ""), zipped


def lib_parse(filename):
    """Pull the human-readable facts out of a TOSEC file name."""
    stem, ext, zipped = lib_split_name(filename)
    flags = [f.strip().lower() for f in LIB_FLAG_RE.findall(stem)]
    bases = [re.sub(r"\d+$", "", f.split()[0]) for f in flags if f.split() and f.split()[0] != "!"]
    verified = any(f.split() and f.split()[0] == "!" for f in flags)
    clean = LIB_FLAG_RE.sub("", stem).strip()
    idx = clean.find("(")
    title = (clean[:idx] if idx >= 0 else clean).strip() or stem
    groups = [g.strip() for g in LIB_PAREN_RE.findall(clean)]

    year, publisher, rest = 0, "", groups
    for i, g in enumerate(groups):
        if LIB_DATE_RE.match(g):
            ytxt = g[:4].lower().replace("x", "0")
            year = int(ytxt) if ytxt.isdigit() and int(ytxt) >= 1950 else 0
            if i + 1 < len(groups):
                pub = groups[i + 1]
                if pub != "-":
                    publisher = pub.replace(" - ", " / ")
            rest = groups[i + 2:]
            break

    countries, langs, multi, dev, demo, media = [], [], False, [], False, []
    for g in rest:
        low = g.lower()
        if not countries and LIB_COUNTRY_RE.match(g) and g not in LIB_COPYRIGHT:
            countries = g.split("-")
        elif not langs and LIB_LANG_RE.match(g):
            langs = g.split("-")
        elif re.match(r"^M\d+$", g):
            multi = True
        elif low in LIB_DEV:
            dev.append(low)
        elif low.startswith("demo"):
            demo = True
        elif LIB_MEDIA_RE.match(g):
            media.append(g)

    version = ""
    m = re.search(r"\s[vV](\d+(?:[.\-]\d+)*[a-zA-Z]?)(?=\s|$)", title)
    if m:
        version = "v" + m.group(1)
        title = (title[:m.start()] + title[m.end():]).strip()
    else:
        m = re.search(r"\sRev\s?(\w+)(?=\s|$)", title, re.I)
        if m:
            version = "Rev " + m.group(1)
            title = (title[:m.start()] + title[m.end():]).strip()
    m = re.match(r"^(.*),\s*(The|A|An)$", title)
    display = f"{m.group(2)} {m.group(1)}" if m else title
    m = re.match(r"^(.*?),\s*(The|A|An)(\s+-\s+.*)$", title)       # 'Title, The - Subtitle'
    if m:
        display = f"{m.group(2)} {m.group(1)}{m.group(3)}"

    tags = []
    if verified:
        tags.append("Verified")
    if any(b in LIB_HACK for b in bases):
        tags.append("Modified")
    else:
        tags.append("Unmodified")
    if any(b in LIB_DEFECT for b in bases):
        tags.append("Bad dump")
    if "a" in bases:
        tags.append("Alternate")
    if dev:
        tags.append("Pre-release")
    if demo:
        tags.append("Demo")
    unflagged = re.sub(r"\([^)]*\)", lambda mm: "" if LIB_MEDIA_RE.match(mm.group(0)[1:-1].strip()) else mm.group(0), stem)
    return {
        "title": display, "version": version, "year": year, "publisher": publisher,
        "countries": countries, "langs": langs, "multi": multi, "tags": tags,
        "ext": ext, "group": re.sub(r"\s+", " ", unflagged).strip().lower(),
    }


def scan_library(root, eng_dir, other_dir, include_filtered, log=print):
    """Walk the sorted folders and return one record per game."""
    root = Path(root)
    games, files_seen = {}, 0
    for setno, dname in ((0, eng_dir), (1, other_dir)):
        if setno and not include_filtered:
            continue
        base = root / dname
        if not base.is_dir():
            continue
        for dp, dns, fns in os.walk(base):
            dns[:] = sorted(d for d in dns if not d.startswith("."))
            rel = list(Path(dp).relative_to(base).parts)
            reason = ""
            if setno:
                reason = "Filtered out"
                if rel and rel[0].lower() in LIB_REASONS:
                    reason = rel.pop(0)
            system = rel[0] if rel else "Loose files"
            for fn in sorted(fns):
                p = Path(dp) / fn
                if fn.startswith(".") or p.suffix.lower() in LIB_SKIP_EXT or fn.lower().startswith("readme"):
                    continue
                try:
                    sz = p.stat().st_size
                except OSError:
                    continue
                info = lib_parse(fn)
                key = (setno, system, info["group"])
                g = games.get(key)
                if g is None:
                    t = info["title"]
                    sk = re.sub(r"^(the|a|an)\s+", "", t.lower())
                    games[key] = g = {
                        "id": format(zlib.crc32(repr(key).encode("utf-8", "replace")) & 0xffffffff, "08x"),
                        "t": t, "k": sk, "s": system, "y": info["year"], "v": info["version"],
                        "p": info["publisher"], "c": info["countries"], "l": info["langs"],
                        "m": info["multi"], "a": info["tags"], "q": setno, "r": reason,
                        "z": 0, "f": [],
                    }
                g["z"] += sz
                g["f"].append([fn, sz])
                files_seen += 1
                if files_seen % 5000 == 0:
                    log(f"   library scan: {files_seen:,} files...")
    out = sorted(games.values(), key=lambda g: (g["k"], g["s"]))
    log(f"Library: {len(out):,} games from {files_seen:,} files.")
    return out


def render_library(games, title, source):
    """Return the finished HTML text."""
    stamp = datetime.datetime.now().strftime("%d %b %Y, %H:%M")
    ident = format(zlib.crc32((title + source).encode("utf-8", "replace")) & 0xffffffff, "08x")
    data = {"meta": {"title": title, "generated": stamp, "source": source, "id": ident}, "games": games}
    blob = json.dumps(data, ensure_ascii=True, separators=(",", ":"))
    blob = blob.replace("</", "<\\/").replace("<!--", "<\\u0021--")
    page = LIB_TEMPLATE.replace("__TITLE__", _html_escape(title))
    return page.replace("__DATA__", blob)       # data goes in last so it can't be re-scanned


def _html_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def write_library(root, eng_dir, other_dir, include_filtered=False, log=print, title="ROM Library"):
    """Scan the sorted folders and write ROM Library.html next to the script."""
    root = Path(root).resolve()
    games = scan_library(root, eng_dir, other_dir, include_filtered, log)
    if not games:
        log("Library not written: no ROM files were found in the sorted folders.")
        return None
    html = render_library(games, title, root.name or str(root))
    path = root / LIB_FILENAME
    tmp = path.with_name(path.name + ".part")
    tmp.write_text(html, encoding="utf-8")
    os.replace(tmp, path)
    log(f"Library written: {path.name}  ({len(games):,} games, {path.stat().st_size / 1048576:.1f} MB)")
    return path


LIB_TEMPLATE = r"""
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="dark light">
<meta name="author" content="normanlove">
<title>__TITLE__</title>
<style>
:root{
  --bg:#0c0f14;--bg2:#10151c;--surf:#151b25;--surf2:#1c2431;--line:#27303f;--line2:#334057;
  --text:#ece7da;--muted:#8d95a6;--faint:#5c6577;--acc:#ffb347;--acc-ink:#1a1204;--acc2:#58d3c6;
  --shadow:0 18px 50px -18px rgba(0,0,0,.7);--glow:rgba(255,179,71,.14);
  --serif:"Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;
  --sans:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,"Liberation Mono",monospace;
  --r:12px;
}
:root[data-theme="light"]{
  --bg:#f3eee2;--bg2:#ede6d6;--surf:#fffaf0;--surf2:#f7f0df;--line:#ddd2ba;--line2:#c9bb9c;
  --text:#1f1b13;--muted:#6d6652;--faint:#9b937c;--acc:#b45309;--acc-ink:#fff8ec;--acc2:#0f766e;
  --shadow:0 16px 40px -20px rgba(70,50,10,.45);--glow:rgba(180,83,9,.10);
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--text);font:15px/1.5 var(--sans);-webkit-font-smoothing:antialiased;
  background-image:radial-gradient(1200px 500px at 85% -10%,var(--glow),transparent 60%),radial-gradient(900px 400px at -10% 10%,rgba(88,211,198,.06),transparent 60%);
  background-attachment:fixed}
button{font:inherit;color:inherit;cursor:pointer}
button:focus-visible,input:focus-visible,select:focus-visible,.card:focus-visible,.row:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
.mono{font-family:var(--mono)}

/* top bar */
.top{position:sticky;top:0;z-index:20;display:flex;gap:12px;align-items:center;padding:12px clamp(16px,3vw,32px);
  background:color-mix(in srgb,var(--bg) 82%,transparent);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.brand{display:flex;align-items:center;gap:10px;font-family:var(--serif);font-weight:700;font-size:19px;letter-spacing:.2px;white-space:nowrap}
.mark{width:28px;height:28px;border-radius:8px;background:conic-gradient(from 210deg,var(--acc),#ff6b6b,var(--acc2),var(--acc));display:grid;place-items:center;box-shadow:0 0 0 1px rgba(255,255,255,.08) inset}
.mark::after{content:"";width:12px;height:12px;border-radius:3px;background:var(--bg);transform:rotate(45deg)}
.search{flex:1;max-width:620px;margin-inline:auto;position:relative}
.search input{width:100%;height:42px;border-radius:999px;border:1px solid var(--line2);background:var(--surf);color:var(--text);padding:0 44px 0 42px;font-size:15px;transition:border-color .15s,box-shadow .15s}
.search input::placeholder{color:var(--faint)}
.search input:focus{outline:none;border-color:var(--acc);box-shadow:0 0 0 4px var(--glow)}
.search svg{position:absolute;left:14px;top:11px;width:20px;height:20px;color:var(--faint)}
.search kbd{position:absolute;right:12px;top:10px;font:12px var(--mono);color:var(--faint);border:1px solid var(--line2);border-radius:6px;padding:1px 7px}
.iconbtn{height:42px;min-width:42px;padding:0 12px;border-radius:999px;border:1px solid var(--line2);background:var(--surf);display:inline-flex;align-items:center;justify-content:center;gap:8px;transition:transform .12s,border-color .15s,background .15s}
.iconbtn:hover{border-color:var(--acc);transform:translateY(-1px)}
.iconbtn svg{width:18px;height:18px}
.iconbtn.on{background:var(--acc);color:var(--acc-ink);border-color:var(--acc)}
.only-m{display:none}

/* layout */
.shell{display:grid;grid-template-columns:288px minmax(0,1fr);gap:0;max-width:1700px;margin:0 auto}
aside{position:sticky;top:67px;align-self:start;height:calc(100vh - 67px);overflow:auto;padding:18px 14px 40px clamp(16px,3vw,32px);scrollbar-width:thin;scrollbar-color:var(--line2) transparent}
main{padding:22px clamp(16px,3vw,32px) 80px 18px;min-width:0}

/* facets */
.facet{margin-bottom:6px;border-bottom:1px solid var(--line);padding-bottom:10px}
.facet summary{list-style:none;cursor:pointer;display:flex;justify-content:space-between;align-items:center;padding:8px 4px;font:600 11.5px var(--mono);text-transform:uppercase;letter-spacing:.14em;color:var(--muted)}
.facet summary::-webkit-details-marker{display:none}
.facet summary::after{content:"+";font-size:15px;color:var(--faint)}
.facet[open] summary::after{content:"–"}
.opts{display:flex;flex-direction:column;gap:2px;max-height:330px;overflow:auto;scrollbar-width:thin;scrollbar-color:var(--line2) transparent}
.opt{position:relative;display:flex;justify-content:space-between;gap:8px;align-items:center;text-align:left;border:0;background:transparent;padding:6px 10px;border-radius:8px;color:var(--text);overflow:hidden;font-size:14px}
.opt::before{content:"";position:absolute;inset:0;width:var(--w,0%);background:var(--surf2);z-index:0;border-radius:8px;transition:width .3s}
.opt>*{position:relative;z-index:1}
.opt span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.opt i{font:12px var(--mono);color:var(--muted);font-style:normal}
.opt:hover{background:var(--surf)}
.opt.on{outline:1px solid var(--acc);color:var(--text)}
.opt.on::before{background:var(--glow);width:100%}
.opt.on i{color:var(--acc)}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{border:1px solid var(--line2);background:var(--surf);border-radius:999px;padding:4px 11px;font-size:13px;display:inline-flex;gap:6px;align-items:center}
.chip i{font:11px var(--mono);color:var(--muted);font-style:normal}
.chip:hover{border-color:var(--acc)}
.chip.on{background:var(--acc);color:var(--acc-ink);border-color:var(--acc)}
.chip.on i{color:inherit;opacity:.75}
.chip.x::after{content:"×";margin-left:2px;font-size:15px;line-height:1}

/* hero */
.hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(220px,380px);gap:28px;align-items:end;padding:14px 0 22px;border-bottom:1px solid var(--line)}
.kicker{font:600 11.5px var(--mono);text-transform:uppercase;letter-spacing:.2em;color:var(--acc)}
h1{font:700 clamp(34px,5vw,60px)/1.02 var(--serif);margin:8px 0 6px;letter-spacing:-.01em}
.sub{color:var(--muted);margin:0}
.stats{display:flex;flex-wrap:wrap;gap:12px 34px;margin-top:20px}
.stat b{display:block;font:700 clamp(26px,3vw,38px)/1 var(--serif);color:var(--text);font-variant-numeric:tabular-nums}
.stat span{font:11.5px var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:.12em}
.tl{display:flex;align-items:flex-end;gap:5px;height:118px;padding-bottom:20px;position:relative}
.tl button{flex:1;border:0;background:transparent;padding:0;height:100%;display:flex;align-items:flex-end;position:relative}
.tl button i{display:block;width:100%;min-height:3px;border-radius:5px 5px 2px 2px;background:linear-gradient(180deg,var(--acc),color-mix(in srgb,var(--acc) 30%,transparent));height:var(--h);transition:height .35s,opacity .2s;opacity:.85}
.tl button:hover i,.tl button.on i{opacity:1;filter:brightness(1.15)}
.tl button.dim i{opacity:.28}
.tl button em{position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font:10.5px var(--mono);color:var(--faint);font-style:normal;white-space:nowrap}
.tl-t{font:600 11px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--faint);margin-bottom:8px}

/* toolbar */
.bar{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center;padding:16px 0 10px}
.bar .grow{flex:1}
.seg{display:inline-flex;border:1px solid var(--line2);border-radius:999px;overflow:hidden;background:var(--surf)}
.seg button{border:0;background:transparent;height:38px;width:42px;display:grid;place-items:center}
.seg button.on{background:var(--acc);color:var(--acc-ink)}
.seg svg{width:17px;height:17px}
select{height:38px;border-radius:999px;border:1px solid var(--line2);background:var(--surf);color:var(--text);padding:0 14px;font:inherit}
.count{font:13px var(--mono);color:var(--muted)}
.active{display:flex;flex-wrap:wrap;gap:6px;padding-bottom:6px}
.rail{display:flex;flex-wrap:wrap;gap:2px;padding:4px 0 14px}
.rail button{border:0;background:transparent;width:28px;height:28px;border-radius:7px;font:600 12.5px var(--mono);color:var(--muted)}
.rail button:hover:not(:disabled){background:var(--surf2);color:var(--text)}
.rail button.on{background:var(--acc);color:var(--acc-ink)}
.rail button:disabled{opacity:.25;cursor:default}

/* grid */
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:22px 18px}
.card{position:relative;display:flex;flex-direction:column;gap:9px;cursor:pointer;animation:rise .45s both;border-radius:var(--r)}
@keyframes rise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.cover{position:relative;aspect-ratio:3/4;border-radius:10px;overflow:hidden;color:#fff;isolation:isolate;
  background:linear-gradient(150deg,hsl(var(--h) 58% 42%),hsl(calc(var(--h) + 48) 62% 20%));
  box-shadow:0 1px 0 rgba(255,255,255,.12) inset,0 10px 24px -12px rgba(0,0,0,.65);transition:transform .22s cubic-bezier(.2,.8,.2,1),box-shadow .22s}
.cover::before{content:"";position:absolute;inset:0;z-index:-1;opacity:.5;
  background:repeating-linear-gradient(135deg,rgba(255,255,255,.07) 0 2px,transparent 2px 14px),radial-gradient(120% 70% at 20% 0%,rgba(255,255,255,.28),transparent 55%)}
.cover::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(255,255,255,.22),rgba(255,255,255,0) 7%,rgba(0,0,0,0) 90%,rgba(0,0,0,.25));pointer-events:none}
.cover b{position:absolute;left:0;right:0;top:50%;transform:translateY(-54%);text-align:center;font:700 clamp(40px,5.2vw,62px)/1 var(--serif);letter-spacing:-.02em;text-shadow:0 3px 18px rgba(0,0,0,.35)}
.cover .sys{position:absolute;left:9px;top:9px;right:40px;font:600 10px var(--mono);letter-spacing:.08em;text-transform:uppercase;background:rgba(0,0,0,.38);backdrop-filter:blur(4px);padding:3px 8px;border-radius:999px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:max-content;max-width:calc(100% - 50px)}
.cover em{position:absolute;right:10px;bottom:8px;font:600 12px var(--mono);font-style:normal;opacity:.85}
.fav{position:absolute;right:7px;top:6px;width:28px;height:28px;border:0;border-radius:50%;background:rgba(0,0,0,.32);color:rgba(255,255,255,.7);font-size:15px;line-height:1;display:grid;place-items:center;transition:transform .15s,background .15s}
.fav:hover{transform:scale(1.15)}
.fav.on{color:#ff5d73;background:rgba(0,0,0,.5)}
.card:hover .cover{transform:translateY(-5px) rotate(-.4deg);box-shadow:0 1px 0 rgba(255,255,255,.14) inset,0 22px 34px -14px rgba(0,0,0,.75)}
.card h3{margin:0;font:600 15px/1.25 var(--serif);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.card p{margin:-5px 0 0;color:var(--muted);font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tag{display:inline-block;font:600 10.5px var(--mono);text-transform:uppercase;letter-spacing:.06em;border:1px solid var(--line2);border-radius:5px;padding:1px 6px;color:var(--muted)}
.tag.v{color:var(--acc2);border-color:color-mix(in srgb,var(--acc2) 50%,transparent)}
.tag.w{color:var(--acc);border-color:color-mix(in srgb,var(--acc) 50%,transparent)}

/* list view */
.list{display:flex;flex-direction:column}
.row{display:grid;grid-template-columns:44px minmax(0,2.2fr) minmax(0,1.2fr) 56px minmax(0,1.2fr) minmax(0,.8fr) 76px;gap:14px;align-items:center;padding:8px 10px;border-bottom:1px solid var(--line);cursor:pointer;border-radius:8px}
.row:hover{background:var(--surf)}
.row .cover{width:44px;aspect-ratio:1;border-radius:7px;box-shadow:none}
.row .cover b{font-size:19px}
.row .cover .sys,.row .cover em,.row .cover .fav{display:none}
.row strong{font:600 15px var(--serif);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row span{color:var(--muted);font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row .num{font-family:var(--mono);text-align:right}
.head{font:600 11px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--faint);cursor:default}
.head:hover{background:none}
.empty{text-align:center;padding:90px 20px;color:var(--muted)}
.empty h2{font:700 28px var(--serif);color:var(--text);margin:0 0 6px}
.sentinel{height:1px}

/* modal */
dialog{border:0;padding:0;background:transparent;color:var(--text);max-width:min(940px,calc(100vw - 24px));width:100%;max-height:calc(100vh - 24px)}
dialog::backdrop{background:rgba(5,7,10,.66);backdrop-filter:blur(6px)}
.sheet{display:grid;grid-template-columns:260px minmax(0,1fr);gap:28px;background:var(--surf);border:1px solid var(--line2);border-radius:18px;padding:26px;box-shadow:var(--shadow);max-height:calc(100vh - 24px);overflow:auto;animation:pop .28s cubic-bezier(.2,.9,.3,1.1)}
@keyframes pop{from{opacity:0;transform:scale(.96) translateY(12px)}to{opacity:1;transform:none}}
.sheet .cover{box-shadow:0 24px 44px -18px rgba(0,0,0,.8)}
.sheet .cover b{font-size:84px}
.sheet h2{font:700 clamp(26px,3.4vw,38px)/1.08 var(--serif);margin:0 0 10px;padding-right:40px}
.tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px}
.close{position:absolute;right:18px;top:16px;width:38px;height:38px;border-radius:50%;border:1px solid var(--line2);background:var(--surf2);font-size:20px;line-height:1}
.sheetwrap{position:relative}
dl{display:grid;grid-template-columns:116px minmax(0,1fr);gap:9px 14px;margin:0 0 18px}
dt{font:600 11px var(--mono);text-transform:uppercase;letter-spacing:.12em;color:var(--faint);padding-top:3px}
dd{margin:0;overflow-wrap:anywhere}
.files{display:flex;flex-direction:column;gap:6px}
.file{display:flex;gap:10px;align-items:center;background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:8px 10px}
.file code{flex:1;font:12.5px/1.4 var(--mono);overflow-wrap:anywhere;color:var(--text)}
.file small{font:12px var(--mono);color:var(--muted);white-space:nowrap}
.file button{border:1px solid var(--line2);background:var(--surf);border-radius:8px;padding:4px 10px;font-size:12.5px}
.file button:hover{border-color:var(--acc)}
.actions{display:flex;gap:8px;margin-top:16px}
.btn{height:40px;padding:0 18px;border-radius:999px;border:1px solid var(--line2);background:var(--surf2)}
.btn.p{background:var(--acc);color:var(--acc-ink);border-color:var(--acc);font-weight:600}
.btn:hover{filter:brightness(1.08)}
footer{max-width:1700px;margin:0 auto;padding:0 clamp(16px,3vw,32px) 40px;color:var(--faint);font:12px var(--mono)}
.toast{position:fixed;left:50%;bottom:26px;transform:translate(-50%,20px);background:var(--text);color:var(--bg);padding:9px 18px;border-radius:999px;font-size:13.5px;opacity:0;pointer-events:none;transition:.25s;z-index:60}
.toast.show{opacity:1;transform:translate(-50%,0)}
.scrim{display:none}

@media (max-width:980px){
  .shell{grid-template-columns:1fr}
  aside{position:fixed;z-index:40;left:0;top:0;bottom:0;height:auto;width:min(86vw,340px);background:var(--bg);border-right:1px solid var(--line2);padding-top:20px;transform:translateX(-102%);transition:transform .28s;box-shadow:var(--shadow)}
  body.drawer aside{transform:none}
  body.drawer .scrim{display:block;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:30}
  main{padding-left:clamp(16px,3vw,32px)}
  .only-m{display:inline-flex}
  .hero{grid-template-columns:1fr}
  .brand span{display:none}
}
@media (max-width:720px){
  .sheet{grid-template-columns:1fr;padding:18px}
  .sheet .cover{max-width:200px}
  dl{grid-template-columns:96px 1fr}
  .row{grid-template-columns:40px minmax(0,1fr) 52px}
  .row .c3,.row .c5,.row .c6,.row .c7{display:none}
  .search kbd{display:none}
  .top{flex-wrap:wrap;row-gap:10px}
  .search{order:9;flex:1 0 100%;max-width:none;margin:0}
  .brand{flex:1}
  .grid{grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:18px 12px}
}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<header class="top">
  <button class="iconbtn only-m" id="openDrawer" aria-label="Filters"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M7 12h10M10 18h4"/></svg></button>
  <div class="brand"><div class="mark"></div><span id="brandName"></span></div>
  <label class="search">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
    <input id="q" type="search" placeholder="Search titles, publishers, systems, filenames…" autocomplete="off" spellcheck="false" aria-label="Search the library">
    <kbd>/</kbd>
  </label>
  <button class="iconbtn" id="favOnly" title="Show favourites only" aria-pressed="false"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7.5-4.6-9.5-9.2C1.2 8.6 3 5 6.4 5c2 0 3.6 1.1 5.6 3.2C14 6.1 15.600 5 17.600 5 21 5 22.800 8.600 21.500 11.800 19.500 16.400 12 21 12 21z"/></svg><b id="favN" class="mono" style="font-weight:600;font-size:13px">0</b></button>
  <button class="iconbtn" id="rand" title="Surprise me"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/></svg></button>
  <button class="iconbtn" id="theme" title="Toggle light / dark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 12.800A9 9 0 1 1 11.200 3a7 7 0 0 0 9.800 9.800z"/></svg></button>
</header>
<div class="scrim" id="scrim"></div>
<div class="shell">
  <aside id="side">
    <details class="facet" open><summary>Systems</summary><div class="opts" id="f-sys"></div></details>
    <details class="facet" open><summary>Decade</summary><div class="chips" id="f-dec"></div></details>
    <details class="facet" open><summary>Region</summary><div class="opts" id="f-reg"></div></details>
    <details class="facet"><summary>Language</summary><div class="opts" id="f-lang"></div></details>
    <details class="facet" open><summary>Status</summary><div class="chips" id="f-tag"></div></details>
    <details class="facet" id="setFacet"><summary>Collection</summary><div class="chips" id="f-set"></div></details>
  </aside>
  <main>
    <section class="hero">
      <div>
        <div class="kicker" id="kicker"></div>
        <h1 id="h1"></h1>
        <p class="sub" id="sub"></p>
        <div class="stats">
          <div class="stat"><b id="s-games">0</b><span>Games</span></div>
          <div class="stat"><b id="s-sys">0</b><span>Systems</span></div>
          <div class="stat"><b id="s-years">–</b><span>Years</span></div>
          <div class="stat"><b id="s-size">0</b><span>On disk</span></div>
        </div>
      </div>
      <div><div class="tl-t">Releases by decade</div><div class="tl" id="tl"></div></div>
    </section>
    <div class="bar">
      <span class="count" id="count"></span>
      <span class="grow"></span>
      <select id="sort" aria-label="Sort by">
        <option value="az">Title A → Z</option><option value="za">Title Z → A</option>
        <option value="new">Newest first</option><option value="old">Oldest first</option>
        <option value="sys">System, then title</option><option value="big">Largest first</option><option value="small">Smallest first</option>
      </select>
      <div class="seg" role="group" aria-label="View">
        <button id="vGrid" title="Cover view" class="on"><svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/></svg></button>
        <button id="vList" title="List view"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>
      </div>
    </div>
    <div class="active" id="active"></div>
    <nav class="rail" id="rail" aria-label="Jump to letter"></nav>
    <div id="out"></div>
    <div class="sentinel" id="sentinel"></div>
  </main>
</div>
<footer id="foot"></footer>
<dialog id="dlg"><div class="sheetwrap"><div class="sheet" id="sheet"></div><button class="close" id="dclose" aria-label="Close">×</button></div></dialog>
<div class="toast" id="toast"></div>
<script type="application/json" id="data">__DATA__</script>
<script>
(()=>{
"use strict";
const D=JSON.parse(document.getElementById("data").textContent);
const META=D.meta, games=D.games;
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const REGION={US:"USA",GB:"United Kingdom",EU:"Europe",JP:"Japan",DE:"Germany",FR:"France",ES:"Spain",IT:"Italy",NL:"Netherlands",SE:"Sweden",AU:"Australia",CA:"Canada",BR:"Brazil",KR:"Korea",CN:"China",TW:"Taiwan",HK:"Hong Kong",AT:"Austria",CH:"Switzerland",BE:"Belgium",DK:"Denmark",NO:"Norway",FI:"Finland",PT:"Portugal",PL:"Poland",RU:"Russia",MX:"Mexico",AR:"Argentina",NZ:"New Zealand",IE:"Ireland",ZA:"South Africa",GR:"Greece",CZ:"Czechia",HU:"Hungary",TR:"Türkiye",IL:"Israel",IN:"India",YU:"Yugoslavia",SK:"Slovakia",HR:"Croatia",SI:"Slovenia",RO:"Romania",BG:"Bulgaria",UA:"Ukraine",ZZ:"Unknown","—":"Not stated"};
const LANG={en:"English",ja:"Japanese",de:"German",fr:"French",es:"Spanish",it:"Italian",nl:"Dutch",sv:"Swedish",da:"Danish",no:"Norwegian",fi:"Finnish",pt:"Portuguese",pl:"Polish",ru:"Russian",ko:"Korean",zh:"Chinese",el:"Greek",cs:"Czech",hu:"Hungarian",tr:"Turkish",he:"Hebrew",hr:"Croatian",sk:"Slovak",ca:"Catalan",multi:"Multi-language"};
const rn=c=>REGION[c]||c, ln=c=>LANG[c]||c.toUpperCase();
const fmt=n=>n.toLocaleString();
const size=b=>{if(!b)return"0 B";const u=["B","KB","MB","GB","TB"];let i=Math.min(4,Math.floor(Math.log(b)/Math.log(1024)));const v=b/Math.pow(1024,i);return(v>=100||i===0?v.toFixed(0):v.toFixed(1))+" "+u[i]};
const hash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
const col=new Intl.Collator(undefined,{numeric:true,sensitivity:"base"});
const ART=/^(the|a|an)\s+/i;
const initials=t=>{const w=t.replace(ART,"").replace(/[^\p{L}\p{N}\s]/gu," ").split(/\s+/).filter(Boolean);if(!w.length)return"?";if(/^\d/.test(w[0]))return w[0].slice(0,3);return(w[0][0]+(w[1]?w[1][0]:w[0][1]||"")).toUpperCase()};
const letterOf=k=>{const c=(k[0]||"#").toUpperCase();return/[A-Z]/.test(c)?c:"#"};

/* ---- store ---- */
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
const FK="romlib:fav:"+META.id;
let fav=new Set();try{fav=new Set(JSON.parse(store.get(FK)||"[]"))}catch(e){}
const saveFav=()=>store.set(FK,JSON.stringify([...fav]));

games.forEach((g,i)=>{
  g.i=i;g.rg=g.c.length?g.c:["—"];g.lg=g.l.length?g.l:(g.m?["multi"]:[]);
  g.dc=g.y?Math.floor(g.y/10)*10+"s":"Unknown";g.sn=g.q?"Filtered out":"Kept";
  g.hay=[g.t,g.p,g.s,g.v,g.f.map(f=>f[0]).join(" ")].join(" ").toLowerCase();
  g.L=letterOf(g.k);g.hue=hash(g.t+g.s)%360;g.ini=initials(g.t);
});
const FAC={sys:g=>[g.s],reg:g=>g.rg,lang:g=>g.lg,dec:g=>[g.dc],tag:g=>g.a,set:g=>[g.sn]};
const LABEL={sys:v=>v,reg:rn,lang:ln,dec:v=>v,tag:v=>v,set:v=>v};
const F={sys:new Set,reg:new Set,lang:new Set,dec:new Set,tag:new Set,set:new Set,fav:false,letter:null,q:""};
let qw=[],res=[],view="grid",shown=0;
const BATCH=96;

function pass(g,except){
  for(const k in FAC){if(k===except)continue;const s=F[k];if(s.size&&!FAC[k](g).some(v=>s.has(v)))return false}
  if(F.fav&&!fav.has(g.id))return false;
  if(except!=="letter"&&F.letter&&g.L!==F.letter)return false;
  for(const w of qw)if(!g.hay.includes(w))return false;
  return true;
}
const SORTS={
  az:(a,b)=>col.compare(a.k,b.k),za:(a,b)=>col.compare(b.k,a.k),
  new:(a,b)=>(b.y||-1)-(a.y||-1)||col.compare(a.k,b.k),
  old:(a,b)=>(a.y||1e9)-(b.y||1e9)||col.compare(a.k,b.k),
  sys:(a,b)=>col.compare(a.s,b.s)||col.compare(a.k,b.k),
  big:(a,b)=>b.z-a.z||col.compare(a.k,b.k),small:(a,b)=>a.z-b.z||col.compare(a.k,b.k)
};

/* ---- facets ---- */
function facetCounts(k){
  const m=new Map();
  for(const g of games){if(!pass(g,k))continue;for(const v of FAC[k](g))m.set(v,(m.get(v)||0)+1)}
  for(const v of F[k])if(!m.has(v))m.set(v,0);
  return m;
}
function renderFacet(k,mode){
  const el=$("#f-"+k),m=facetCounts(k);
  let ents=[...m.entries()];
  if(k==="sys"||k==="reg"||k==="lang")ents.sort((a,b)=>k==="sys"?col.compare(a[0],b[0]):(b[1]-a[1])||col.compare(a[0],b[0]));
  else if(k==="dec")ents.sort((a,b)=>col.compare(a[0],b[0]));
  else ents.sort((a,b)=>b[1]-a[1]);
  const max=Math.max(1,...ents.map(e=>e[1]));
  el.innerHTML=ents.filter(([v,n])=>n>0||F[k].has(v)).map(([v,n])=>{
    const on=F[k].has(v);
    return mode==="chip"
      ?`<button class="chip${on?" on":""}" data-k="${k}" data-v="${esc(v)}">${esc(LABEL[k](v))}<i>${fmt(n)}</i></button>`
      :`<button class="opt${on?" on":""}" data-k="${k}" data-v="${esc(v)}" style="--w:${(n/max*100).toFixed(1)}%"><span>${esc(LABEL[k](v))}</span><i>${fmt(n)}</i></button>`;
  }).join("")||'<span class="count" style="padding:6px 10px">Nothing here</span>';
}
function renderTimeline(){
  const m=new Map();
  for(const g of games){if(!pass(g,"dec"))continue;m.set(g.dc,(m.get(g.dc)||0)+1)}
  const decs=[...new Set(games.map(g=>g.dc))].filter(d=>d!=="Unknown").sort();
  if(games.some(g=>g.dc==="Unknown"))decs.push("Unknown");
  const max=Math.max(1,...decs.map(d=>m.get(d)||0));
  $("#tl").innerHTML=decs.map(d=>{const n=m.get(d)||0,on=F.dec.has(d);
    return`<button data-k="dec" data-v="${d}" class="${on?"on":""}${F.dec.size&&!on?" dim":""}" title="${d}: ${fmt(n)} games"><i style="--h:${(n/max*100).toFixed(1)}%"></i><em>${d==="Unknown"?"?":d.replace("s","")}</em></button>`}).join("");
}
function renderRail(){
  const have=new Set();
  for(const g of games)if(pass(g,"letter"))have.add(g.L);
  $("#rail").innerHTML=["#",..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"].map(l=>`<button data-l="${l}" class="${F.letter===l?"on":""}" ${have.has(l)||F.letter===l?"":"disabled"}>${l}</button>`).join("");
}
function renderActive(){
  const out=[];
  for(const k of ["sys","dec","reg","lang","tag","set"])for(const v of F[k])out.push(`<button class="chip on x" data-k="${k}" data-v="${esc(v)}">${esc(LABEL[k](v))}</button>`);
  if(F.letter)out.push(`<button class="chip on x" data-l="${F.letter}">Starts with ${F.letter}</button>`);
  if(F.fav)out.push(`<button class="chip on x" id="clrFav">Favourites</button>`);
  if(out.length>1)out.push(`<button class="chip" id="clrAll">Clear all</button>`);
  $("#active").innerHTML=out.join("");
}

/* ---- results ---- */
function meta(g){const a=[];if(g.p)a.push(g.p);if(g.c.length)a.push(g.c.map(rn).join(", "));return a.join(" · ")||"—"}
function cover(g,big){
  return`<div class="cover" style="--h:${g.hue}"><span class="sys">${esc(g.s)}</span><b>${esc(g.ini)}</b>${g.y?`<em>${g.y}</em>`:""}${big?"":`<button class="fav${fav.has(g.id)?" on":""}" data-fav="${g.i}" aria-label="Favourite" title="Favourite">♥</button>`}</div>`;
}
function card(g,d){
  const tags=[];if(g.v)tags.push(`<span class="tag v">${esc(g.v)}</span>`);
  return`<article class="card" tabindex="0" data-i="${g.i}" style="animation-delay:${d}ms">${cover(g)}<h3 title="${esc(g.t)}">${esc(g.t)}</h3><p>${esc(g.s)}${g.y?" · "+g.y:""}</p></article>`;
}
function row(g){
  return`<article class="row" tabindex="0" data-i="${g.i}">${cover(g)}<strong title="${esc(g.t)}">${esc(g.t)}${g.v?` <small class="tag v">${esc(g.v)}</small>`:""}</strong><span class="c3">${esc(g.s)}</span><span class="num">${g.y||"–"}</span><span class="c5">${esc(g.p||"—")}</span><span class="c6">${esc(g.c.map(rn).join(", ")||"—")}</span><span class="num c7">${size(g.z)}</span></article>`;
}
function more(){
  const out=$("#out>div");if(!out||shown>=res.length)return;
  const end=Math.min(res.length,shown+BATCH);let h="";
  for(let i=shown;i<end;i++)h+=view==="grid"?card(res[i],Math.min((i-shown)*8,300)):row(res[i]);
  out.insertAdjacentHTML("beforeend",h);shown=end;
  if(shown<res.length&&$("#sentinel").getBoundingClientRect().top<innerHeight+600)more();
}
function renderOut(){
  shown=0;const o=$("#out");
  if(!res.length){o.innerHTML=`<div class="empty"><h2>Nothing on the shelf</h2><p>No games match these filters.</p><button class="btn p" id="clrAll2">Clear filters</button></div>`;return}
  o.innerHTML=view==="grid"?'<div class="grid"></div>':'<div class="list"><div class="row head"><i></i><span>Title</span><span class="c3">System</span><span class="num">Year</span><span class="c5">Publisher</span><span class="c6">Region</span><span class="num c7">Size</span></div></div>';
  more();
}
function stats(){
  const sy=new Set();let mn=1e9,mx=0,z=0;
  for(const g of res){sy.add(g.s);z+=g.z;if(g.y){mn=Math.min(mn,g.y);mx=Math.max(mx,g.y)}}
  $("#s-games").textContent=fmt(res.length);$("#s-sys").textContent=fmt(sy.size);
  $("#s-years").textContent=mx?(mn===mx?mn:mn+"–"+String(mx).slice(2)):"–";
  $("#s-size").textContent=size(z);
  $("#count").textContent=res.length===games.length?`${fmt(games.length)} games`:`${fmt(res.length)} of ${fmt(games.length)} games`;
}
let tm=0;
function update(){
  qw=F.q.toLowerCase().split(/\s+/).filter(Boolean);
  res=games.filter(g=>pass(g)).sort(SORTS[$("#sort").value]);
  renderFacet("sys");renderFacet("reg");renderFacet("lang");renderFacet("dec","chip");renderFacet("tag","chip");renderFacet("set","chip");
  renderTimeline();renderRail();renderActive();stats();renderOut();
  $("#favN").textContent=fav.size;$("#favOnly").classList.toggle("on",F.fav);$("#favOnly").setAttribute("aria-pressed",F.fav);
}

/* ---- detail ---- */
function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");clearTimeout(tm);tm=setTimeout(()=>e.classList.remove("show"),1500)}
function copy(t){
  const done=()=>toast("Copied to clipboard");
  if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(done,fallback);else fallback();
  function fallback(){const a=document.createElement("textarea");a.value=t;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{document.execCommand("copy");done()}catch(e){toast("Copy failed")}a.remove()}
}
function open(g){
  const tags=[];
  g.a.forEach(t=>tags.push(`<span class="tag ${t==="Verified"||t==="Unmodified"?"v":(t==="Modified"||t==="Bad dump"||t==="Pre-release"?"w":"")}">${esc(t)}</span>`));
  if(g.v)tags.unshift(`<span class="tag v">${esc(g.v)}</span>`);
  const dl=[["System",g.s],["Year",g.y||"Unknown"],["Publisher",g.p||"Unknown"],["Region",g.c.map(rn).join(", ")||"Not stated"],["Language",g.l.map(ln).join(", ")||(g.m?"Multi-language":"Not stated")],["Version",g.v||"—"],["Size",size(g.z)+(g.f.length>1?` across ${g.f.length} files`:"")],["Collection",g.q?("Filtered out"+(g.r?" – "+g.r:"")):"Kept"]];
  $("#sheet").innerHTML=`<div>${cover(g,true)}</div><div><h2>${esc(g.t)}</h2><div class="tags">${tags.join("")}</div><dl>${dl.map(([a,b])=>`<dt>${a}</dt><dd>${esc(b)}</dd>`).join("")}</dl><div class="files">${g.f.map((f,i)=>`<div class="file"><code>${esc(f[0])}</code><small>${size(f[1])}</small><button data-copy="${i}">Copy</button></div>`).join("")}</div><div class="actions"><button class="btn p" data-fav="${g.i}" id="dfav">${fav.has(g.id)?"♥ In favourites":"♡ Add to favourites"}</button><button class="btn" id="dcopy">Copy title</button></div></div>`;
  $("#sheet").dataset.i=g.i;
  const d=$("#dlg");if(!d.open)d.showModal();
}

/* ---- events ---- */
function toggle(k,v){const s=F[k];s.has(v)?s.delete(v):s.add(v);update()}
document.addEventListener("click",e=>{
  const t=e.target;
  let b=t.closest("[data-fav]");
  if(b){e.stopPropagation();const g=games[+b.dataset.fav];fav.has(g.id)?fav.delete(g.id):fav.add(g.id);saveFav();
    if(b.id==="dfav")b.textContent=fav.has(g.id)?"♥ In favourites":"♡ Add to favourites";
    document.querySelectorAll(`.fav[data-fav="${g.i}"]`).forEach(x=>x.classList.toggle("on",fav.has(g.id)));
    $("#favN").textContent=fav.size;if(F.fav)update();return}
  b=t.closest("[data-copy]");
  if(b){const g=games[+$("#sheet").dataset.i];copy(g.f[+b.dataset.copy][0]);return}
  b=t.closest("[data-k]");if(b){toggle(b.dataset.k,b.dataset.v);return}
  b=t.closest("[data-l]");if(b&&!b.disabled){F.letter=F.letter===b.dataset.l?null:b.dataset.l;update();return}
  b=t.closest("[data-i]");if(b){open(games[+b.dataset.i]);return}
  if(t.closest("#clrAll,#clrAll2")){for(const k of["sys","reg","lang","dec","tag","set"])F[k].clear();F.fav=false;F.letter=null;F.q="";$("#q").value="";update();return}
  if(t.closest("#clrFav")){F.fav=false;update();return}
  if(t.closest("#dcopy")){copy(games[+$("#sheet").dataset.i].t);return}
  if(t.closest("#dclose")||t.id==="dlg"){$("#dlg").close();return}
});
document.addEventListener("keydown",e=>{
  if((e.key==="Enter"||e.key===" ")&&e.target.matches&&e.target.matches(".card,.row")){e.preventDefault();open(games[+e.target.dataset.i]);return}
  if(e.key==="/"&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)){e.preventDefault();$("#q").focus()}
  if(e.key==="Escape"&&document.activeElement===$("#q")){$("#q").blur()}
});
let qt=0;
$("#q").addEventListener("input",e=>{clearTimeout(qt);qt=setTimeout(()=>{F.q=e.target.value;update()},120)});
$("#sort").addEventListener("change",update);
$("#favOnly").addEventListener("click",()=>{F.fav=!F.fav;update()});
$("#vGrid").addEventListener("click",()=>setView("grid"));
$("#vList").addEventListener("click",()=>setView("list"));
function setView(v){view=v;$("#vGrid").classList.toggle("on",v==="grid");$("#vList").classList.toggle("on",v==="list");store.set("romlib:view",v);renderOut()}
$("#rand").addEventListener("click",()=>{const p=res.length?res:games;if(p.length)open(p[Math.floor(Math.random()*p.length)])});
$("#openDrawer").addEventListener("click",()=>document.body.classList.add("drawer"));
$("#scrim").addEventListener("click",()=>document.body.classList.remove("drawer"));
function setTheme(t){document.documentElement.dataset.theme=t;store.set("romlib:theme",t)}
$("#theme").addEventListener("click",()=>setTheme(document.documentElement.dataset.theme==="dark"?"light":"dark"));
new IntersectionObserver(es=>{if(es[0].isIntersecting)more()},{rootMargin:"700px"}).observe($("#sentinel"));

/* ---- boot ---- */
(function(){
  const saved=store.get("romlib:theme");
  setTheme(saved||(matchMedia("(prefers-color-scheme: light)").matches?"light":"dark"));
  const sv=store.get("romlib:view");if(sv==="list"){view="list";$("#vGrid").classList.remove("on");$("#vList").classList.add("on")}
  $("#brandName").textContent=META.title;$("#h1").textContent=META.title;
  $("#kicker").textContent="Collection catalogue";
  $("#sub").textContent=`Generated ${META.generated} from ${META.source}. Everything on this page is in this one file – it works offline.`;
  $("#foot").textContent=`${META.title} · ${fmt(games.length)} games · built ${META.generated} · created by normanlove · single-file page, no network access needed`;
  if(!games.some(g=>g.q))$("#setFacet").style.display="none";
  document.title=META.title;
  update();
})();
})();
</script>
</body>
</html>
"""
# <<< ROM LIBRARY <<<


class App:
    def __init__(self, win):
        self.win = win
        self.q = queue.Queue()
        self.busy = False
        win.title("TOSEC ROM Sorter - created by normanlove")
        win.geometry("940x800")
        frm = ttk.Frame(win, padding=10)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="ROM folder to sort (it and all subfolders are scanned):",
                  font=("TkDefaultFont", 10, "bold")).pack(anchor="w")
        rf = ttk.Frame(frm)
        rf.pack(fill="x", pady=(0, 6))
        self.v_root = tk.StringVar(value=Options.load().root)
        ttk.Entry(rf, textvariable=self.v_root).pack(side="left", fill="x", expand=True)
        ttk.Button(rf, text="Browse...", command=self.pick_root).pack(side="left", padx=(6, 0))

        self.nb = ttk.Notebook(frm)
        self.nb.pack(fill="x")
        self.build_language_tab()
        self.build_sortout_tab()
        self.build_duplicates_tab()
        self.build_layout_tab()
        self.build_output_tab()

        btns = ttk.Frame(frm)
        btns.pack(fill="x", pady=8)
        self.buttons = [
            ttk.Button(btns, text="Preview (moves nothing)", command=lambda: self.start(True)),
            ttk.Button(btns, text="Sort ROMs", command=lambda: self.start(False)),
            ttk.Button(btns, text="Undo last run", command=self.undo),
            ttk.Button(btns, text="Build library now", command=self.library_now),
            ttk.Button(btns, text="Reset options", command=self.reset),
        ]
        for b in self.buttons:
            b.pack(side="left", padx=(0, 8))

        self.bar = ttk.Progressbar(frm, mode="determinate")
        self.bar.pack(fill="x")
        box = ttk.Frame(frm)
        box.pack(fill="both", expand=True, pady=(8, 0))
        sb = ttk.Scrollbar(box)
        sb.pack(side="right", fill="y")
        self.text = tk.Text(box, height=12, wrap="word", state="disabled", yscrollcommand=sb.set)
        self.text.pack(side="left", fill="both", expand=True)
        sb.config(command=self.text.yview)

        self.apply(Options.load())
        self.log("TOSEC ROM Sorter - created by normanlove.\nReady. Run a Preview first - it writes a CSV report showing what would happen.")
        win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.after(100, self.poll)

    # ---- tabs ----
    def tab(self, title):
        f = ttk.Frame(self.nb, padding=10)
        self.nb.add(f, text=title)
        return f

    def build_language_tab(self):
        t = self.tab("Language")
        self.v_filter_lang = tk.BooleanVar()
        self.v_langs = tk.StringVar()
        self.v_missing = tk.BooleanVar()
        self.v_multi = tk.BooleanVar()
        ttk.Checkbutton(t, variable=self.v_filter_lang,
                        text="Sort out ROMs that are not in the languages below").pack(anchor="w")
        row = ttk.Frame(t)
        row.pack(anchor="w", pady=4)
        ttk.Label(row, text="Languages to keep (TOSEC codes, comma separated, in order of preference):").pack(side="left")
        ttk.Entry(row, textvariable=self.v_langs, width=16).pack(side="left", padx=6)
        ttk.Label(t, foreground="gray",
                  text="e.g. en  |  en, de  |  ja.   Codes: en de fr es it nl sv da no fi pt pl ru ja ko zh el cs hu tr he ...").pack(anchor="w")
        ttk.Checkbutton(t, variable=self.v_missing,
                        text="ROMs with no language tag: decide by country (e.g. (US) -> en, (JP) -> ja); no country counts as a match"
                        ).pack(anchor="w", pady=(8, 0))
        ttk.Checkbutton(t, variable=self.v_multi,
                        text="Accept multi-language ROMs tagged like (M3), where the languages aren't listed").pack(anchor="w")
        ttk.Label(t, foreground="gray",
                  text="If you keep several languages, you get one copy of each ROM per language.").pack(anchor="w", pady=(6, 0))

    def build_sortout_tab(self):
        t = self.tab("Sort out")
        ttk.Label(t, text="Ticked items are moved to the filtered-out folder.").pack(anchor="w", pady=(0, 6))
        self.v_flags = {}
        self.v_dev = {}
        self.v_demo = tk.BooleanVar()

        def group(title, items, store, label):
            lf = ttk.LabelFrame(t, text=title, padding=6)
            lf.pack(fill="x", pady=3)
            for n, (code, text) in enumerate(items):
                v = tk.BooleanVar()
                store[code] = v
                ttk.Checkbutton(lf, variable=v, text=label(code, text)).grid(row=0, column=n, padx=8, sticky="w")

        flag_items = lambda codes: [(c, FLAG_INFO[c][0]) for c in codes]
        group("Hacks and modified ROMs", flag_items(["cr", "f", "h", "m", "p", "t", "tr"]),
              self.v_flags, lambda c, x: f"{x} [{c}]")
        group("Bad dumps", flag_items(["b", "o", "u", "v"]), self.v_flags, lambda c, x: f"{x} [{c}]")
        group("Alternates", flag_items(["a"]), self.v_flags, lambda c, x: f"{x} [{c}]")
        group("Pre-release / development builds", [(d, d.title()) for d in DEV_STATUS],
              self.v_dev, lambda c, x: f"{x} ({c})")
        lf = ttk.LabelFrame(t, text="Demos", padding=6)
        lf.pack(fill="x", pady=3)
        ttk.Checkbutton(lf, variable=self.v_demo, text="Demo versions (demo, demo-kiosk, demo-playable...)").pack(anchor="w")

    def build_duplicates_tab(self):
        t = self.tab("Duplicates")
        self.v_dedup = tk.BooleanVar()
        self.v_fallback = tk.BooleanVar()
        self.v_newest = tk.BooleanVar()
        self.v_region = tk.StringVar()
        ttk.Checkbutton(t, variable=self.v_dedup,
                        text="Keep only one copy of each ROM (sort out the other versions as duplicates)").pack(anchor="w")
        ttk.Checkbutton(t, variable=self.v_fallback,
                        text="If every copy of a title would be sorted out by the filters, keep the best one anyway"
                        ).pack(anchor="w", pady=(6, 0))
        lf = ttk.LabelFrame(t, text="Which copy wins", padding=6)
        lf.pack(fill="x", pady=8)
        ttk.Radiobutton(lf, variable=self.v_newest, value=True,
                        text="Highest version number (most up to date)").pack(anchor="w")
        ttk.Radiobutton(lf, variable=self.v_newest, value=False,
                        text="Lowest version number (closest to the original release)").pack(anchor="w")
        row = ttk.Frame(lf)
        row.pack(anchor="w", pady=(6, 0))
        ttk.Label(row, text="Preferred regions when otherwise equal (e.g. GB, US, EU):").pack(side="left")
        ttk.Entry(row, textvariable=self.v_region, width=18).pack(side="left", padx=6)
        ttk.Label(t, foreground="gray", justify="left",
                  text="Always preferred first: unmodified over hacked, undamaged dumps, finished builds over\n"
                       "alpha/beta, and [!] verified dumps. Ties go to the earliest release date.").pack(anchor="w")

    def build_layout_tab(self):
        t = self.tab("Layout")
        self.v_layout = tk.StringVar()
        self.v_alpha = tk.BooleanVar()
        self.v_alpha_group = tk.IntVar()
        self.v_alpha_filtered = tk.BooleanVar()
        self.v_group = tk.BooleanVar()

        lf = ttk.LabelFrame(t, text="System folder names", padding=8)
        lf.pack(fill="x")
        row = ttk.Frame(lf)
        row.pack(anchor="w")
        ttk.Label(row, text="Name the system folders for:").pack(side="left")
        cb = ttk.Combobox(row, textvariable=self.v_layout, values=list(LAYOUTS), state="readonly", width=16)
        cb.pack(side="left", padx=6)
        self.hint = ttk.Label(lf, foreground="gray", wraplength=820, justify="left")
        self.hint.pack(anchor="w", pady=(6, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.update_hint())
        row2 = ttk.Frame(lf)
        row2.pack(anchor="w", pady=(8, 0))
        ttk.Button(row2, text="Export mapping file...", command=self.export_mapping).pack(side="left")
        ttk.Label(row2, foreground="gray",
                  text="  Writes tosec_sorter_systems.json - edit it to rename any system folder.").pack(side="left")

        lf3 = ttk.LabelFrame(t, text="TOSEC categories", padding=8)
        lf3.pack(fill="x", pady=(8, 0))
        ttk.Checkbutton(lf3, variable=self.v_group,
                        text="Keep each system's TOSEC folders together: <System>/Games, <System>/Demos, <System>/Applications...").pack(anchor="w")
        ttk.Label(lf3, foreground="gray", wraplength=780,
                  text="TOSEC splits one system into several folders ('Commodore Amiga - Games - [ADF]', "
                       "'Commodore Amiga - Demos'...). Off: they are merged into one system folder (best for "
                       "frontends). On: they stay separate, but all inside that system's folder. Format tags "
                       "like [ADF] are ignored.").pack(anchor="w")
        lf2 = ttk.LabelFrame(t, text="Alphabetical subfolders", padding=8)
        lf2.pack(fill="x", pady=10)
        ttk.Checkbutton(lf2, variable=self.v_alpha,
                        text="Split each system folder into alphabetical subfolders (0-9, A, B, C ... #)").pack(anchor="w")
        row3 = ttk.Frame(lf2)
        row3.pack(anchor="w", pady=4)
        ttk.Label(row3, text="Letters per folder:").pack(side="left")
        ttk.Spinbox(row3, from_=1, to=13, width=3, textvariable=self.v_alpha_group).pack(side="left", padx=6)
        ttk.Label(row3, foreground="gray", text="1 = A, B, C...   3 = A-C, D-F, G-I...   (digits go in '0-9', anything else in '#')").pack(side="left")
        ttk.Checkbutton(lf2, variable=self.v_alpha_filtered,
                        text="Also do this inside the filtered-out folder").pack(anchor="w")

    def build_output_tab(self):
        t = self.tab("Output")
        self.v_eng = tk.StringVar()
        self.v_oth = tk.StringVar()
        self.v_split = tk.BooleanVar()
        self.v_skip = tk.IntVar()
        self.v_empty = tk.BooleanVar()
        for label, var in (("Folder for kept ROMs:", self.v_eng), ("Folder for filtered-out ROMs:", self.v_oth)):
            r = ttk.Frame(t)
            r.pack(anchor="w", pady=2)
            ttk.Label(r, text=label, width=30).pack(side="left")
            ttk.Entry(r, textvariable=var, width=30).pack(side="left")
        ttk.Checkbutton(t, variable=self.v_split,
                        text="Split the filtered-out folder by reason first (Other languages, Duplicates, Hacks and modified...)"
                        ).pack(anchor="w", pady=(8, 0))
        ttk.Checkbutton(t, variable=self.v_empty,
                        text="Remove empty folders left behind after moving").pack(anchor="w")
        rf = ttk.LabelFrame(t, text="Reports", padding=6)
        rf.pack(fill="x", pady=(10, 0))
        self.v_csv = tk.BooleanVar()
        self.v_lib = tk.BooleanVar()
        self.v_lib_f = tk.BooleanVar()
        ttk.Checkbutton(rf, variable=self.v_csv,
                        text="Write a CSV report after each run (one row per file: what happened and why)").pack(anchor="w")
        ttk.Checkbutton(rf, variable=self.v_lib,
                        text=f"Build the HTML library ('{LIB_FILENAME}') after each sort - a single browsable page of your games"
                        ).pack(anchor="w")
        ttk.Checkbutton(rf, variable=self.v_lib_f,
                        text="Include the filtered-out games in the library too").pack(anchor="w", padx=(22, 0))
        r = ttk.Frame(t)
        r.pack(anchor="w", pady=(6, 0))
        ttk.Label(r, text="Folder levels to skip before the system folder:").pack(side="left")
        ttk.Spinbox(r, from_=0, to=5, width=3, textvariable=self.v_skip).pack(side="left", padx=6)

    def update_hint(self):
        self.hint.config(text=LAYOUT_HINTS.get(self.v_layout.get(), ""))

    def export_mapping(self):
        try:
            p = export_systems_file()
            self.log(f"Mapping file written: {p.name}  (edit the 'overrides' section, then re-run)")
        except OSError as e:
            self.log(f"Could not write mapping file: {e}")

    # ---- option <-> widgets ----
    def reset(self):
        o = Options()
        o.root = self.v_root.get().strip()
        self.apply(o)

    def pick_root(self):
        d = filedialog.askdirectory(title="Choose the ROM folder to sort",
                                    initialdir=self.v_root.get() or str(Path.home()))
        if d:
            self.v_root.set(d)
            self.options().save()

    def root_path(self):
        r = self.v_root.get().strip()
        if not r or not Path(r).is_dir():
            messagebox.showinfo("ROM folder", "Choose the ROM folder first (Browse... at the top).")
            return None
        return Path(r).resolve()

    def apply(self, o):
        self.v_filter_lang.set(o.filter_language)
        self.v_langs.set(o.languages)
        self.v_missing.set(o.missing_lang_by_country)
        self.v_multi.set(o.accept_multi)
        for c, v in self.v_flags.items():
            v.set(c in o.sort_flags)
        for c, v in self.v_dev.items():
            v.set(c in o.sort_dev)
        self.v_demo.set(o.sort_demo)
        self.v_dedup.set(o.dedup)
        self.v_fallback.set(o.fallback)
        self.v_newest.set(o.prefer_newest)
        self.v_region.set(o.region_priority)
        self.v_layout.set(o.layout if o.layout in LAYOUTS else TOSEC_LAYOUT)
        self.v_alpha.set(o.alpha)
        self.v_alpha_group.set(o.alpha_group)
        self.v_alpha_filtered.set(o.alpha_filtered)
        self.v_group.set(o.group_categories)
        self.v_eng.set(o.eng_dir)
        self.v_oth.set(o.other_dir)
        self.v_split.set(o.split_by_reason)
        self.v_skip.set(o.skip_levels)
        self.v_empty.set(o.remove_empty)
        self.v_csv.set(o.write_csv)
        self.v_lib.set(o.build_library)
        self.v_lib_f.set(o.library_filtered)
        self.update_hint()

    def options(self):
        o = Options()
        o.root = self.v_root.get().strip()
        o.filter_language = self.v_filter_lang.get()
        o.languages = self.v_langs.get()
        o.missing_lang_by_country = self.v_missing.get()
        o.accept_multi = self.v_multi.get()
        o.sort_flags = [c for c, v in self.v_flags.items() if v.get()]
        o.sort_dev = [c for c, v in self.v_dev.items() if v.get()]
        o.sort_demo = self.v_demo.get()
        o.dedup = self.v_dedup.get()
        o.fallback = self.v_fallback.get()
        o.prefer_newest = self.v_newest.get()
        o.region_priority = self.v_region.get()
        o.layout = self.v_layout.get()
        o.alpha = self.v_alpha.get()
        o.alpha_filtered = self.v_alpha_filtered.get()
        o.group_categories = self.v_group.get()
        for attr, var in (("alpha_group", self.v_alpha_group), ("skip_levels", self.v_skip)):
            try:
                setattr(o, attr, int(var.get()))
            except (ValueError, tk.TclError):
                pass
        o.eng_dir = self.v_eng.get()
        o.other_dir = self.v_oth.get()
        o.split_by_reason = self.v_split.get()
        o.remove_empty = self.v_empty.get()
        o.write_csv = self.v_csv.get()
        o.build_library = self.v_lib.get()
        o.library_filtered = self.v_lib_f.get()
        return o.normalise()

    def close(self):
        self.options().save()
        self.win.destroy()

    # ---- thread-safe helpers ----
    def log(self, msg):
        self.q.put(("log", msg))

    def progress(self, n, total):
        self.q.put(("progress", n, total))

    def poll(self):
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "log":
                    self.text.configure(state="normal")
                    self.text.insert("end", item[1] + "\n")
                    self.text.see("end")
                    self.text.configure(state="disabled")
                elif item[0] == "progress":
                    self.bar["maximum"], self.bar["value"] = item[2], item[1]
                elif item[0] == "done":
                    self.busy = False
                    for b in self.buttons:
                        b.state(["!disabled"])
        except queue.Empty:
            pass
        self.win.after(100, self.poll)

    def lock(self):
        self.busy = True
        for b in self.buttons:
            b.state(["disabled"])

    def start(self, dry):
        if self.busy:
            return
        root = self.root_path()
        if root is None:
            return
        opts = self.options()
        opts.save()
        if not dry and not messagebox.askyesno(
                "Sort ROMs",
                f"Files will be MOVED (not deleted) into '{opts.eng_dir}' and '{opts.other_dir}'.\n"
                "You can reverse this with 'Undo last run'.\n\nContinue?"):
            return
        self.lock()
        threading.Thread(target=self.worker, args=(dry, opts, root), daemon=True).start()

    def worker(self, dry, opts, root):
        try:
            self.log("--- " + ("PREVIEW" if dry else "SORTING") + f" (layout: {opts.layout}) ---")
            plan, mapper = build_plan(root, opts, self.log)
            kept = sum(1 for d in plan if d.keep)
            self.log(f"Kept: {kept:,}   Filtered out: {len(plan) - kept:,}")
            cats = defaultdict(int)
            for d in plan:
                if not d.keep:
                    cats[d.category] += 1
            for c, n in sorted(cats.items(), key=lambda x: -x[1]):
                self.log(f"   {c}: {n:,}")
            if mapper.used:
                self.log("System folders:")
                for raw, folder in sorted(mapper.used.items()):
                    self.log(f"   {raw}  ->  {folder}")
            if mapper.unmapped:
                self.log(f"No '{opts.layout}' folder known for: {', '.join(sorted(mapper.unmapped))}. "
                         "They keep their TOSEC names - use 'Export mapping file' on the Layout tab to set them.")
            if opts.write_csv:
                report = write_report(root, plan, opts)
                self.log(f"Report written: {report.name}")
            else:
                self.log("CSV report skipped (turned off on the Output tab).")
            if not dry:
                moved = execute_plan(root, plan, opts, self.log, self.progress)
                self.log(f"Done. {moved:,} files moved.")
                if opts.build_library:
                    write_library(root, opts.eng_dir, opts.other_dir, opts.library_filtered, self.log)
            elif opts.build_library:
                self.log("Library not built during a preview - it is made after a real sort, "
                         "or any time with 'Build library now'.")
        except Exception:
            self.log("ERROR:\n" + traceback.format_exc())
        self.q.put(("done",))

    def library_now(self):
        if self.busy:
            return
        root = self.root_path()
        if root is None:
            return
        opts = self.options()
        opts.save()
        self.lock()

        def work():
            try:
                self.log("--- BUILDING LIBRARY ---")
                write_library(root, opts.eng_dir, opts.other_dir, opts.library_filtered, self.log)
            except Exception:
                self.log("ERROR:\n" + traceback.format_exc())
            self.q.put(("done",))
        threading.Thread(target=work, daemon=True).start()

    def undo(self):
        if self.busy:
            return
        if not messagebox.askyesno("Undo", "Move every file from the last run back to where it was?"):
            return
        root = Path(self.v_root.get().strip() or ".")
        self.lock()

        def work():
            try:
                undo_last_run(root, self.log, self.progress)
            except Exception:
                self.log("ERROR:\n" + traceback.format_exc())
            self.q.put(("done",))
        threading.Thread(target=work, daemon=True).start()


def main():
    if tk is None:
        print("Tkinter is not available in this Python installation.")
        sys.exit(1)
    win = tk.Tk()
    App(win)
    win.mainloop()


if __name__ == "__main__":
    main()
