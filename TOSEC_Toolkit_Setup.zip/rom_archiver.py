#!/usr/bin/env python3
"""
ROM Archiver
============
Created by normanlove.

Companion to TOSEC ROM Sorter. Choose the ROM folder (the one holding the
'English ROMs' and 'Filtered Out' folders; it defaults to the sorter's) and run it.
CLI: --root "D:\\Roms". Two jobs:

  ZIP     every file gets its own .zip and the original is removed
  UNZIP   every file is taken out of its .zip and the .zip is removed

You choose which folders (English / Filtered / both) and which SYSTEMS to work on.
The system list shows, for each system, whether the usual emulator can run a
zipped ROM ("Zip OK") or needs the file unzipped ("Needs unzipped files"), and
one click ticks just the zip-friendly systems.

Nothing is removed until the new files have been written and checked: zips are
re-read and CRC-tested, extracted files are checked against the zip's own sizes
and CRCs, and a file that changes while it is being processed is left alone.
A CSV report can be written for every run (tick box / --no-report), and the games can be
exported as one self-contained, browsable HTML library page. Needs only Python 3.8+ with Tkinter.

Command line (no window):
  python rom_archiver.py --list-systems
  python rom_archiver.py --action zip --preset zip-friendly [--dry-run]
  python rom_archiver.py --action unzip --systems "Atari ST,Commodore Amiga"
  python rom_archiver.py --action zip --preset zip-friendly --no-report --library
  python rom_archiver.py --library-only [--library-include-filtered]
"""

import argparse
import csv
import datetime
import json
import os
import queue
import re
import shutil
import stat
import sys
import tempfile
import threading
import time
import traceback
import zlib
import zipfile
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
except ImportError:  # the command line mode still works without Tk
    tk = None

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #

if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent

SETTINGS = APP_DIR / "rom_archiver_settings.json"
SORTER_SETTINGS = APP_DIR / "tosec_sorter_settings.json"

TMP_PREFIX = ".rom_archiver_tmp_"
JUNK_NAMES = {".ds_store", "thumbs.db", "desktop.ini"}
# Files with these endings are already compressed; zipping them again gains nothing.
ARCHIVE_ENDINGS = (".zip", ".7z", ".rar", ".lha", ".lzh", ".gz", ".bz2", ".xz", ".tar", ".tgz", ".adz")
EXT_RE = re.compile(r"\.(?=[A-Za-z0-9]{1,6}$)[A-Za-z0-9]*[A-Za-z][A-Za-z0-9]*$")

# When the sorter splits the filtered folder by reason, the system folders sit one level lower.
REASON_FOLDERS = {"other languages", "duplicates", "hacks and modified", "bad dumps",
                  "alternates", "pre-release", "demos"}
LOOSE = "(files not in a system folder)"

MOVE_LOCK = threading.Lock()

COMPRESSION_LABELS = {
    "max": "Maximum (smallest zips)",
    "normal": "Normal",
    "store": "Store only (no compression, fastest)",
}


class ArchiveError(Exception):
    pass


# --------------------------------------------------------------------------- #
# Which systems can run zipped ROMs?
#
# Derived from the "Accepted ROM formats" listed on Batocera's wiki page for each
# system (wiki.batocera.org/systems:<name>), which reflects what its default
# emulators (RetroArch cores, VICE, Hatari, MAME ...) can load. Frontends such as
# RetroPie, ES-DE and Recalbox use largely the same emulators, but check your own
# setup for anything important. Edit the table below to suit your devices.
# --------------------------------------------------------------------------- #

ZIP_OK, ZIP_PARTIAL, ZIP_NO, ZIP_UNKNOWN = "zip", "partial", "no", "unknown"
STATUS_TEXT = {
    ZIP_OK: "Zip OK",
    ZIP_PARTIAL: "Depends on emulator",
    ZIP_NO: "Needs unzipped files",
    ZIP_UNKNOWN: "Unknown",
}
DISC = "Disc images (.cue/.iso/.chd) - emulators can't read them from a zip"

# (label, regex on the folder name with spaces/punctuation removed and lower-cased, status, note)
# The first matching rule wins, so specific rules come before general ones.
ZIP_RULES = [
    # --- disc / CD based: need unzipped files ---
    ("Amiga CD32 / CDTV", r"cd32|cdtv|amigacd", ZIP_NO, DISC),
    ("Sega CD / Mega CD", r"megacd|segacd", ZIP_NO, DISC),
    ("PC Engine CD", r"(pcengine|turbografx|tgfx16).*cd", ZIP_NO, DISC),
    ("Neo Geo CD", r"neogeocd", ZIP_NO, DISC),
    ("Atari Jaguar CD", r"jaguarcd", ZIP_NO, DISC),
    ("Sega Saturn", r"saturn", ZIP_NO, DISC + "; Beetle Saturn won't open zips"),
    ("Sega Dreamcast", r"dreamcast", ZIP_NO, DISC),
    ("Sony PlayStation 2", r"playstation2|^ps2$", ZIP_NO, DISC),
    ("Sony PSP", r"playstationportable|^psp$", ZIP_NO, "Disc images (.iso/.cso/.chd)"),
    ("Sony PlayStation", r"playstation|^psx$", ZIP_NO, DISC),
    ("3DO", r"^3do|3dointeractive", ZIP_NO, DISC),
    ("Philips CD-i", r"^cdi|philipscdi|cdimono", ZIP_NO, DISC),
    ("GameCube / Wii", r"gamecube|nintendowii|^wii", ZIP_NO, "Disc images"),
    # --- other systems whose emulators don't take zips ---
    ("NEC PC-8801", r"pc88", ZIP_NO, "Emulator lists .d88/.u88 only"),
    # --- partly supported ---
    ("Nintendo 64", r"nintendo64|^n64$", ZIP_PARTIAL,
     "Libretro Mupen64Plus-Next reads zips; standalone Mupen64Plus does not"),
    ("DOS / IBM PC", r"^dos$|^pc$|ibmpc|pccompatible|msdos|dosbox", ZIP_PARTIAL,
     "Only DOSBox Pure reads zips; DOSBox / Staging / DOSBox-X do not"),
    # --- Commodore ---
    ("Commodore Amiga", r"amiga", ZIP_OK,
     "UAE cores read zipped disks; multi-disk games need their disks in one zip or an .m3u"),
    ("Commodore 64", r"commodore64|c64", ZIP_OK, ""),
    ("Commodore 128", r"commodore128|c128", ZIP_OK, ""),
    ("Commodore VIC-20", r"vic20|^c20$|vc20", ZIP_OK, ""),
    ("Commodore Plus/4", r"plus4|commodore16|commodore116|^c16$", ZIP_OK, ""),
    ("Commodore PET", r"commodorepet|^pet$|pet2001", ZIP_OK, ""),
    # --- Atari ---
    ("Atari 2600", r"2600", ZIP_OK, ""),
    ("Atari 5200", r"5200", ZIP_OK, ""),
    ("Atari 7800", r"7800", ZIP_OK, ""),
    ("Atari Jaguar", r"jaguar", ZIP_OK, ""),
    ("Camputers Lynx", r"camputers|camplynx", ZIP_OK, ""),
    ("Atari Lynx", r"atarilynx|^lynx$", ZIP_OK, ""),
    ("Atari 8-bit", r"atari8bit|atari800|atarixe|xegs|atarixl|atari400", ZIP_OK, ""),
    ("Atari ST", r"atarist|atarifalcon|atarite|ataritt", ZIP_OK, ""),
    # --- Sinclair / Amstrad / MSX / Apple / Acorn ---
    ("Sinclair ZX81", r"zx81|zx80", ZIP_OK, ""),
    ("Sinclair ZX Spectrum", r"spectrum", ZIP_OK, ""),
    ("Amstrad GX4000", r"gx4000", ZIP_OK, ""),
    ("Amstrad PCW", r"pcw", ZIP_OK, "Run by MAME"),
    ("Amstrad CPC", r"amstradcpc|^amstrad$|^cpc", ZIP_OK, ""),
    ("MSX", r"msx", ZIP_OK, ""),
    ("Apple IIGS", r"iigs|apple2gs", ZIP_OK, "Run by MAME"),
    ("Apple II", r"appleii|apple2", ZIP_OK, "Run by MAME"),
    ("Apple Macintosh", r"macintosh|macplus|^mac$", ZIP_OK, "Run by MAME"),
    ("Acorn Archimedes", r"archimedes|archie", ZIP_OK, "Run by MAME"),
    ("Acorn BBC Micro", r"bbc", ZIP_OK, "Run by MAME"),
    ("Acorn Electron", r"electron", ZIP_OK, "Run by MAME"),
    ("Acorn Atom", r"acornatom|^atom$", ZIP_OK, "Run by MAME"),
    # --- consoles ---
    ("Coleco Adam", r"colecoadam|^adam$", ZIP_OK, ""),
    ("ColecoVision", r"colecovision|^coleco$", ZIP_OK, ""),
    ("Intellivision", r"intellivision", ZIP_OK, ""),
    ("Vectrex", r"vectrex", ZIP_OK, ""),
    ("Fairchild Channel F", r"channelf", ZIP_OK, ""),
    ("Magnavox Odyssey 2 / Videopac", r"odyssey|videopac|o2em", ZIP_OK, ""),
    ("Bally Astrocade", r"astrocade", ZIP_OK, ""),
    ("Emerson Arcadia 2001", r"arcadia", ZIP_OK, ""),
    ("Famicom Disk System", r"famicomdisk|^fds$", ZIP_OK, ""),
    ("Super Nintendo", r"supernintendo|supernes|superfamicom|^snes$", ZIP_OK, ""),
    ("Nintendo NES", r"entertainmentsystem|^nes$|^famicom$|nesfamicom", ZIP_OK, ""),
    ("Game Boy Advance", r"gameboyadvance|^gba$", ZIP_OK, ""),
    ("Game Boy Color", r"gameboycolor|^gbc$", ZIP_OK, ""),
    ("Game Boy", r"gameboy|^gb$", ZIP_OK, ""),
    ("Nintendo DS", r"nintendods|^nds$", ZIP_OK, ""),
    ("Virtual Boy", r"virtualboy", ZIP_OK, ""),
    ("Sega Master System", r"mastersystem|^sms$", ZIP_OK, ""),
    ("Sega Game Gear", r"gamegear", ZIP_OK, ""),
    ("Sega SC-3000", r"sc3000", ZIP_OK, ""),
    ("Sega SG-1000", r"sg1000", ZIP_OK, ""),
    ("Sega 32X", r"32x", ZIP_OK, ""),
    ("Sega Mega Drive / Genesis", r"megadrive|genesis|^md$", ZIP_OK, ""),
    ("PC Engine / TurboGrafx", r"pcengine|turbografx|tgfx16|supergrafx", ZIP_OK, ""),
    ("Neo Geo Pocket", r"neogeopocket|^ngp|ngpc", ZIP_OK, ""),
    ("Neo Geo", r"neogeo", ZIP_OK, ""),
    ("WonderSwan", r"wonderswan|^wswan", ZIP_OK, ""),
    # --- other computers ---
    ("Tandy Color Computer", r"coco|colorcomputer", ZIP_OK, "Run by MAME"),
    ("Tandy TRS-80", r"trs80", ZIP_OK, ""),
    ("TI-99", r"ti99", ZIP_OK, ""),
    ("Thomson MO/TO", r"thomson", ZIP_OK, ""),
    ("Oric", r"oric", ZIP_OK, ""),
    ("Dragon 32/64", r"dragon", ZIP_OK, ""),
    ("SAM Coupe", r"samcoupe|samcoup", ZIP_OK, ""),
    ("Sharp X68000", r"x68000", ZIP_OK, ""),
    ("NEC PC-9801", r"pc98", ZIP_OK, ""),
    ("Fujitsu FM-7", r"fm7", ZIP_OK, ""),
    ("Fujitsu FM Towns", r"fmtowns", ZIP_OK, ""),
    ("Enterprise", r"enterprise", ZIP_OK, ""),
]
_ZIP_RULES = [(label, re.compile(rx), status, note) for label, rx, status, note in ZIP_RULES]


def classify(name):
    """Return (status, label, note) for a system folder name (TOSEC or frontend style)."""
    key = re.sub(r"[^a-z0-9]", "", name.lower())
    for label, rx, status, note in _ZIP_RULES:
        if rx.search(key):
            return status, label, note
    return ZIP_UNKNOWN, "", "Not in the zip-support list, so the zip-friendly preset leaves it alone"


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #

def split_ext(name):
    """'Game (1990).adf' -> ('Game (1990)', '.adf'). Version dots like 'v1.1' are not extensions."""
    m = EXT_RE.search(name)
    if m and m.start() > 0:
        return name[:m.start()], name[m.start():]
    return name, ""


def is_archive_name(name):
    return name.lower().endswith(ARCHIVE_ENDINGS)


def is_junk(name):
    low = name.lower()
    return low in JUNK_NAMES or name.startswith("._") or low.endswith(".part")


def human(n):
    n = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:,.0f} {unit}" if unit == "B" else f"{n:,.1f} {unit}"
        n /= 1024
    return f"{n:,.1f} TB"


def safe_folder(name):
    return re.sub(r'[<>:"/\\|?*]', "_", str(name)).strip(" .")


def remove_file(p):
    try:
        os.remove(p)
    except PermissionError:
        os.chmod(p, stat.S_IWRITE)
        os.remove(p)


def unique_path(p):
    if not p.exists():
        return p
    n = 2
    while True:
        c = p.with_name(f"{p.stem} ({n}){p.suffix}")
        if not c.exists():
            return c
        n += 1


def safe_rel(name):
    """A safe relative path for a zip member name, or None if it tries to escape."""
    parts = []
    for p in name.replace("\\", "/").split("/"):
        if p in ("", "."):
            continue
        if p == "..":
            return None
        p = p.replace("\x00", "_")
        if os.name == "nt":
            p = re.sub(r'[<>:"|?*\x00-\x1f]', "_", p).rstrip(" .")
        if not p:
            return None
        parts.append(p)
    return Path(*parts) if parts else None


def sorter_root():
    """The ROM folder the sorter used last time, so both apps agree by default."""
    try:
        return json.loads(SORTER_SETTINGS.read_text(encoding="utf-8")).get("root") or ""
    except (OSError, ValueError, AttributeError):
        return ""


def sorter_folders():
    """Folder names the sorter used last time, so both apps agree by default."""
    try:
        d = json.loads(SORTER_SETTINGS.read_text(encoding="utf-8"))
        return d.get("eng_dir") or "English ROMs", d.get("other_dir") or "Filtered Out"
    except (OSError, ValueError, AttributeError):
        return "English ROMs", "Filtered Out"


# --------------------------------------------------------------------------- #
# Options
# --------------------------------------------------------------------------- #

class Options:
    SESSION_ONLY = ("selected", "preset")      # not saved: they depend on the collection

    def __init__(self):
        eng, oth = sorter_folders()
        self.root = ""                 # the ROM folder to work in (chosen in the GUI)
        self.action = "zip"            # zip | unzip
        self.scope = "both"            # english | filtered | both
        self.eng_dir = eng
        self.other_dir = oth
        self.delete_source = True
        self.compression = "max"       # max | normal | store
        self.name_style = "stem"       # stem (Game.zip) | full (Game.adf.zip)
        self.skip_archives = True
        self.container_folder = False
        self.workers = 2
        self.write_csv = True          # CSV report after each run
        self.build_library = False     # HTML library after each real run
        self.library_filtered = False  # ...also listing the filtered-out games
        self.selected = None           # list of lower-case system names, or None = every system
        self.preset = None             # None | "zip-friendly" | "needs-unzipped" (used when selected is None)

    def to_dict(self):
        return {k: v for k, v in self.__dict__.items() if k not in self.SESSION_ONLY}

    @classmethod
    def from_dict(cls, d):
        o = cls()
        for k, v in (d or {}).items():
            if k in o.__dict__ and k not in cls.SESSION_ONLY:
                setattr(o, k, v)
        return o

    def save(self):
        try:
            SETTINGS.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        except OSError:
            pass

    @classmethod
    def load(cls):
        try:
            return cls.from_dict(json.loads(SETTINGS.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            return cls()

    def normalise(self):
        self.eng_dir = safe_folder(self.eng_dir) or "English ROMs"
        self.other_dir = safe_folder(self.other_dir) or "Filtered Out"
        if self.action not in ("zip", "unzip"):
            self.action = "zip"
        if self.scope not in ("english", "filtered", "both"):
            self.scope = "both"
        if self.compression not in COMPRESSION_LABELS:
            self.compression = "max"
        if self.name_style not in ("stem", "full"):
            self.name_style = "stem"
        try:
            self.workers = min(16, max(1, int(self.workers)))
        except (TypeError, ValueError):
            self.workers = 2
        return self


# --------------------------------------------------------------------------- #
# Finding the systems
# --------------------------------------------------------------------------- #

def scope_dirs(root, opts):
    dirs = []
    if opts.scope in ("english", "both"):
        dirs.append(root / opts.eng_dir)
    if opts.scope in ("filtered", "both"):
        dirs.append(root / opts.other_dir)
    return dirs


def walk_dirs(base, recursive=True):
    if recursive:
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(d for d in dirnames if not d.startswith(TMP_PREFIX))
            yield Path(dirpath), sorted(filenames)
    else:
        try:
            names = sorted(f for f in os.listdir(base) if (Path(base) / f).is_file())
        except OSError:
            names = []
        yield Path(base), names


class SystemInfo:
    def __init__(self, name):
        self.name = name
        self.roots = []                # [(Path, recursive)]
        self.files = 0
        self.zips = 0
        self.status, self.label, self.note = classify(name)


def discover(root, opts, log=None):
    """Find every system folder in the chosen scope. Returns a list of SystemInfo, sorted by name."""
    found = {}

    def add(name, path, recursive):
        info = found.setdefault(name.lower(), SystemInfo(name))
        info.roots.append((path, recursive))

    def scan(base, allow_reasons):
        try:
            entries = sorted(os.scandir(base), key=lambda e: e.name.lower())
        except OSError:
            return
        has_loose = False
        for e in entries:
            if e.is_dir(follow_symlinks=False):
                if e.name.startswith(TMP_PREFIX):
                    continue
                if allow_reasons and e.name.lower() in REASON_FOLDERS:
                    scan(Path(e.path), False)
                else:
                    add(e.name, Path(e.path), True)
            elif not is_junk(e.name):
                has_loose = True
        if has_loose:
            add(LOOSE, base, False)

    for base in scope_dirs(root, opts):
        if base.is_dir():
            scan(base, True)
        elif log:
            log(f"Folder not found, skipping: {base.name}")

    systems = sorted(found.values(), key=lambda s: s.name.lower())
    for s in systems:
        for path, recursive in s.roots:
            for _dp, filenames in walk_dirs(path, recursive):
                for fn in filenames:
                    if is_junk(fn):
                        continue
                    s.files += 1
                    if fn.lower().endswith(".zip"):
                        s.zips += 1
    return systems


def choose_systems(systems, opts):
    if opts.selected is not None:
        wanted = {str(n).lower() for n in opts.selected}
        return [s for s in systems if s.name.lower() in wanted]
    if opts.preset == "zip-friendly":
        return [s for s in systems if s.status == ZIP_OK]
    if opts.preset == "needs-unzipped":
        return [s for s in systems if s.status in (ZIP_NO, ZIP_PARTIAL)]
    return list(systems)


# --------------------------------------------------------------------------- #
# Planning
# --------------------------------------------------------------------------- #

class Job:
    def __init__(self, path, system, target=None, arcname=None):
        self.path, self.system, self.target, self.arcname = path, system, target, arcname


def plan_zip(systems, opts):
    todo, skipped = [], []
    for s in systems:
        for base, recursive in s.roots:
            for dp, filenames in walk_dirs(base, recursive):
                taken = {f.lower() for f in filenames}
                cands = []
                for fn in filenames:
                    p = dp / fn
                    if is_junk(fn):
                        skipped.append((p, s.name, "system/temporary file"))
                    elif p.is_symlink():
                        skipped.append((p, s.name, "symbolic link"))
                    elif opts.skip_archives and is_archive_name(fn):
                        skipped.append((p, s.name, "already an archive"))
                    else:
                        cands.append(fn)
                stems = Counter(split_ext(f)[0].lower() for f in cands)
                for fn in cands:
                    stem, ext = split_ext(fn)
                    choices = []
                    if opts.name_style == "stem" and ext and stems[stem.lower()] == 1:
                        choices.append(stem + ".zip")           # Game.adf -> Game.zip
                    choices.append(fn + ".zip")                  # Game.adf -> Game.adf.zip
                    target = next((c for c in choices if c.lower() not in taken), None)
                    n = 2
                    while target is None:
                        c = f"{fn} ({n}).zip"
                        if c.lower() not in taken:
                            target = c
                        n += 1
                    taken.add(target.lower())
                    todo.append(Job(dp / fn, s.name, dp / target, fn))
    return todo, skipped


def plan_unzip(systems):
    todo, skipped = [], []
    for s in systems:
        for base, recursive in s.roots:
            for dp, filenames in walk_dirs(base, recursive):
                for fn in filenames:
                    if is_junk(fn) or not fn.lower().endswith(".zip"):
                        continue
                    p = dp / fn
                    if p.is_symlink():
                        skipped.append((p, s.name, "symbolic link"))
                    else:
                        todo.append(Job(p, s.name))
    return todo, skipped


# --------------------------------------------------------------------------- #
# Workers
# --------------------------------------------------------------------------- #

def zip_one(job, opts, stop):
    if stop.is_set():
        return "SKIPPED", "stopped by user", None
    src, target = job.path, job.target
    part = target.with_name(target.name + ".part")
    try:
        st = src.stat()
        if opts.compression == "store":
            ctype, level = zipfile.ZIP_STORED, None
        else:
            ctype, level = zipfile.ZIP_DEFLATED, (9 if opts.compression == "max" else 6)
        with zipfile.ZipFile(part, "w", ctype, allowZip64=True, compresslevel=level,
                             strict_timestamps=False) as zf:
            zf.write(src, job.arcname)
        with zipfile.ZipFile(part) as zf:                    # read it all back and CRC-check it
            infos = zf.infolist()
            if len(infos) != 1 or infos[0].file_size != st.st_size:
                raise RuntimeError("the zip does not match the source file")
            bad = zf.testzip()
            if bad is not None:
                raise RuntimeError(f"verification failed ({bad})")
        st2 = src.stat()
        if (st2.st_size, st2.st_mtime_ns) != (st.st_size, st.st_mtime_ns):
            raise RuntimeError("the file changed while it was being zipped")
        if target.exists():
            raise RuntimeError("a file with the zip's name appeared during the run")
        try:
            os.utime(part, ns=(st.st_atime_ns, st.st_mtime_ns))
        except OSError:
            pass
        os.replace(part, target)
        new_size = target.stat().st_size
        if opts.delete_source:
            remove_file(src)
        return "OK", f"{human(st.st_size)} -> {human(new_size)}", (st.st_size, new_size)
    except Exception as e:
        try:
            part.unlink()
        except OSError:
            pass
        return "FAILED", f"{type(e).__name__}: {e}", None


def _set_mtime(path, date_time):
    try:
        ts = time.mktime(tuple(date_time) + (0, 0, -1))
        os.utime(path, (ts, ts))
    except (OverflowError, OSError, ValueError):
        pass


def unzip_into(archive, tmp):
    with zipfile.ZipFile(archive) as zf:
        infos = zf.infolist()
        if any(i.flag_bits & 0x1 for i in infos):
            raise ArchiveError("password-protected")
        for info in infos:
            if info.is_dir():
                continue
            rel = safe_rel(info.filename)
            if rel is None:
                raise ArchiveError(f"unsafe path inside zip: {info.filename!r}")
            dst = unique_path(tmp / rel)
            dst.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as s, open(dst, "wb") as o:      # CRC is checked as it is read
                shutil.copyfileobj(s, o, 1 << 20)
            if dst.stat().st_size != info.file_size:
                raise ArchiveError(f"size mismatch for {info.filename!r}")
            _set_mtime(dst, info.date_time)


def unzip_one(job, opts, stop):
    if stop.is_set():
        return "SKIPPED", "stopped by user", None
    archive = job.path
    tmp = None
    try:
        tmp = Path(tempfile.mkdtemp(prefix=TMP_PREFIX, dir=str(archive.parent)))
        unzip_into(archive, tmp)
        files = []
        for dp, _dn, fn in os.walk(tmp):
            for f in fn:
                p = Path(dp) / f
                if not p.is_symlink():
                    files.append(p)
        if not files:
            return "SKIPPED", "zip contains no files - left in place", None
        base = archive.parent
        if opts.container_folder and len(files) > 1:
            base = base / (safe_folder(archive.name[:-4]) or "extracted")
        moved, renamed = [], 0
        with MOVE_LOCK:                                      # one writer at a time -> no name races
            try:
                for f in files:
                    dst = base / f.relative_to(tmp)
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    final = unique_path(dst)
                    if final != dst:
                        renamed += 1
                    shutil.move(str(f), str(final))
                    moved.append(final)
            except Exception:
                for m in moved:                              # roll back a half-finished move
                    try:
                        m.unlink()
                    except OSError:
                        pass
                raise
            if opts.delete_source:
                remove_file(archive)
        msg = f"{len(files)} file(s)" + (f", {renamed} renamed to avoid overwriting" if renamed else "")
        return "OK", msg, None
    except Exception as e:
        return "FAILED", (str(e) if isinstance(e, ArchiveError) else f"{type(e).__name__}: {e}"), None
    finally:
        if tmp is not None:
            shutil.rmtree(tmp, ignore_errors=True)


def peek_zip(job):
    """Cheap description for a preview run."""
    try:
        with zipfile.ZipFile(job.path) as zf:
            infos = [i for i in zf.infolist() if not i.is_dir()]
            if any(i.flag_bits & 0x1 for i in infos):
                return "password-protected (would fail)"
            return f"contains {len(infos)} file(s)"
    except Exception as e:
        return f"unreadable ({e})"


# --------------------------------------------------------------------------- #
# Job runner
# --------------------------------------------------------------------------- #

def write_report(root, rows):
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = root / f"rom_archiver_report_{stamp}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Result", "Action", "System", "File", "Detail", "Folder", "New file"])
        w.writerows(rows)
    return path


def run_job(root, opts, dry, log, progress, stop):
    """Run the chosen action. Returns a dict of counts."""
    opts.normalise()
    summary = {"ok": 0, "failed": 0, "skipped": 0, "saved": 0, "report": None}
    systems = discover(root, opts, log)
    if not systems:
        log("Nothing to do - no system folders were found in the chosen folders.")
        return summary
    chosen = choose_systems(systems, opts)
    if not chosen:
        log("Nothing to do - none of the found systems are selected.")
        return summary
    log(f"{len(chosen)} of {len(systems)} system(s) selected.")
    if opts.action == "zip":
        risky = [s.name for s in chosen if s.status != ZIP_OK]
        if risky:
            log("Note: these selected systems may not run zipped games: " + ", ".join(risky))

    action = opts.action
    if action == "zip":
        jobs, skipped = plan_zip(chosen, opts)
    else:
        jobs, skipped = plan_unzip(chosen)
    log(f"{len(jobs):,} file(s) to {action}; {len(skipped):,} skipped.")

    rows = []
    for p, sysname, why in skipped:
        rows.append(["Skipped", action, sysname, p.name, why, str(p.parent.relative_to(root)), ""])
        summary["skipped"] += 1

    total = len(jobs)
    if dry:
        for n, j in enumerate(jobs, 1):
            detail = f"would become {j.target.name}" if action == "zip" else peek_zip(j)
            rows.append(["Preview", action, j.system, j.path.name, detail,
                         str(j.path.parent.relative_to(root)), j.target.name if j.target else ""])
            if n % 200 == 0 or n == total:
                progress(n, total)
        summary["ok"] = total
    else:
        def work(j):
            return zip_one(j, opts, stop) if action == "zip" else unzip_one(j, opts, stop)

        done = 0
        with ThreadPoolExecutor(max_workers=opts.workers) as ex:
            futs = {ex.submit(work, j): j for j in jobs}
            for fut in as_completed(futs):
                j = futs[fut]
                try:
                    status, detail, extra = fut.result()
                except Exception as e:                       # should not happen; never lose track
                    status, detail, extra = "FAILED", f"{type(e).__name__}: {e}", None
                done += 1
                if status == "OK":
                    summary["ok"] += 1
                    if extra:
                        summary["saved"] += extra[0] - extra[1]
                elif status == "FAILED":
                    summary["failed"] += 1
                    log(f"FAILED: {j.path.name}: {detail}")
                else:
                    summary["skipped"] += 1
                rows.append([status.title(), action, j.system, j.path.name, detail,
                             str(j.path.parent.relative_to(root)), j.target.name if j.target else ""])
                if done % 25 == 0 or done == total:
                    progress(done, total)

    if getattr(opts, "write_csv", True):
        summary["report"] = write_report(root, rows)
    if dry:
        log(f"Preview complete: {summary['ok']:,} would be processed, nothing was changed.")
    else:
        line = f"Done: {summary['ok']:,} processed, {summary['failed']:,} failed, {summary['skipped']:,} skipped."
        if action == "zip" and summary["ok"]:
            line += f" Space {'saved' if summary['saved'] >= 0 else 'added'}: {human(abs(summary['saved']))}."
        log(line)
        if summary["failed"]:
            log("Files that failed were left exactly as they were.")
    if summary["report"]:
        log(f"Report written: {summary['report'].name}")
    else:
        log("CSV report skipped (turned off).")
    if opts.build_library:
        if dry:
            log("Library not built during a preview - it is made after a real run, or any time with 'Build library now'.")
        else:
            write_library(root, opts.eng_dir, opts.other_dir, opts.library_filtered, log)
    return summary


# --------------------------------------------------------------------------- #
# GUI
# --------------------------------------------------------------------------- #

# >>> ROM LIBRARY (identical in tosec_sorter.py and rom_archiver.py) >>>
# --------------------------------------------------------------------------- #
# HTML library: one self-contained page (inline CSS/JS/data, no other files)
# --------------------------------------------------------------------------- #

LIB_FILENAME = "ROM Library.html"
LIB_REASONS = {"other languages", "duplicates", "hacks and modified", "bad dumps",
               "alternates", "pre-release", "demos"}
LIB_SKIP_EXT = {".txt", ".nfo", ".dat", ".xml", ".jpg", ".jpeg", ".png", ".gif", ".bmp",
                ".htm", ".html", ".url", ".diz", ".py", ".pyw", ".pyc", ".exe",
                ".log", ".csv", ".ini", ".db", ".json", ".pdf", ".sfv", ".md5", ".sha1",
                ".part"}
LIB_HACK = {"cr", "f", "h", "m", "p", "t", "tr"}
LIB_DEFECT = {"b", "o", "u", "v"}
LIB_DEV = {"alpha", "beta", "preview", "pre-release", "proto"}
LIB_COPYRIGHT = {"CW", "FW", "GW", "LW", "PD", "SW"}
LIB_DATE_RE = re.compile(r"^[0-9x]{4}(-[0-9x]{2}(-[0-9x]{2})?)?$", re.I)
LIB_COUNTRY_RE = re.compile(r"^[A-Z]{2}(-[A-Z]{2})*$")
LIB_LANG_RE = re.compile(r"^[a-z]{2}(-[a-z]{2})*$")
LIB_MEDIA_RE = re.compile(r"^(disk|disc|side|tape|part|cart\w*|cassette)\s+\w+", re.I)
LIB_FLAG_RE = re.compile(r"\[([^\]]*)\]")
LIB_PAREN_RE = re.compile(r"\(([^)]*)\)")


def lib_split_name(filename):
    """'Game (1990)(Pub).adf.zip' -> ('Game (1990)(Pub)', 'adf', True)."""
    n, zipped = filename, False
    if n.lower().endswith(".zip"):
        n, zipped = n[:-4], True
    m = re.search(r"\.([A-Za-z][A-Za-z0-9]{0,3})$", n)
    if m and (zipped or len(m.group(1)) <= 4):
        return n[:m.start()], m.group(1).lower(), zipped
    return n, ("zip" if zipped else ""), zipped


def lib_parse(filename):
    """Pull the human-readable facts out of a TOSEC file name."""
    stem, ext, zipped = lib_split_name(filename)
    flags = [f.strip().lower() for f in LIB_FLAG_RE.findall(stem)]
    bases = [re.sub(r"\d+$", "", f.split()[0]) for f in flags if f.split() and f.split()[0] != "!"]
    verified = any(f.split() and f.split()[0] == "!" for f in flags)
    clean = LIB_FLAG_RE.sub("", stem).strip()
    idx = clean.find("(")
    title = (clean[:idx] if idx >= 0 else clean).strip() or stem
    groups = [g.strip() for g in LIB_PAREN_RE.findall(clean)]

    year, publisher, rest = 0, "", groups
    for i, g in enumerate(groups):
        if LIB_DATE_RE.match(g):
            ytxt = g[:4].lower().replace("x", "0")
            year = int(ytxt) if ytxt.isdigit() and int(ytxt) >= 1950 else 0
            if i + 1 < len(groups):
                pub = groups[i + 1]
                if pub != "-":
                    publisher = pub.replace(" - ", " / ")
            rest = groups[i + 2:]
            break

    countries, langs, multi, dev, demo, media = [], [], False, [], False, []
    for g in rest:
        low = g.lower()
        if not countries and LIB_COUNTRY_RE.match(g) and g not in LIB_COPYRIGHT:
            countries = g.split("-")
        elif not langs and LIB_LANG_RE.match(g):
            langs = g.split("-")
        elif re.match(r"^M\d+$", g):
            multi = True
        elif low in LIB_DEV:
            dev.append(low)
        elif low.startswith("demo"):
            demo = True
        elif LIB_MEDIA_RE.match(g):
            media.append(g)

    version = ""
    m = re.search(r"\s[vV](\d+(?:[.\-]\d+)*[a-zA-Z]?)(?=\s|$)", title)
    if m:
        version = "v" + m.group(1)
        title = (title[:m.start()] + title[m.end():]).strip()
    else:
        m = re.search(r"\sRev\s?(\w+)(?=\s|$)", title, re.I)
        if m:
            version = "Rev " + m.group(1)
            title = (title[:m.start()] + title[m.end():]).strip()
    m = re.match(r"^(.*),\s*(The|A|An)$", title)
    display = f"{m.group(2)} {m.group(1)}" if m else title
    m = re.match(r"^(.*?),\s*(The|A|An)(\s+-\s+.*)$", title)       # 'Title, The - Subtitle'
    if m:
        display = f"{m.group(2)} {m.group(1)}{m.group(3)}"

    tags = []
    if verified:
        tags.append("Verified")
    if any(b in LIB_HACK for b in bases):
        tags.append("Modified")
    else:
        tags.append("Unmodified")
    if any(b in LIB_DEFECT for b in bases):
        tags.append("Bad dump")
    if "a" in bases:
        tags.append("Alternate")
    if dev:
        tags.append("Pre-release")
    if demo:
        tags.append("Demo")
    unflagged = re.sub(r"\([^)]*\)", lambda mm: "" if LIB_MEDIA_RE.match(mm.group(0)[1:-1].strip()) else mm.group(0), stem)
    return {
        "title": display, "version": version, "year": year, "publisher": publisher,
        "countries": countries, "langs": langs, "multi": multi, "tags": tags,
        "ext": ext, "group": re.sub(r"\s+", " ", unflagged).strip().lower(),
    }


def scan_library(root, eng_dir, other_dir, include_filtered, log=print):
    """Walk the sorted folders and return one record per game."""
    root = Path(root)
    games, files_seen = {}, 0
    for setno, dname in ((0, eng_dir), (1, other_dir)):
        if setno and not include_filtered:
            continue
        base = root / dname
        if not base.is_dir():
            continue
        for dp, dns, fns in os.walk(base):
            dns[:] = sorted(d for d in dns if not d.startswith("."))
            rel = list(Path(dp).relative_to(base).parts)
            reason = ""
            if setno:
                reason = "Filtered out"
                if rel and rel[0].lower() in LIB_REASONS:
                    reason = rel.pop(0)
            system = rel[0] if rel else "Loose files"
            for fn in sorted(fns):
                p = Path(dp) / fn
                if fn.startswith(".") or p.suffix.lower() in LIB_SKIP_EXT or fn.lower().startswith("readme"):
                    continue
                try:
                    sz = p.stat().st_size
                except OSError:
                    continue
                info = lib_parse(fn)
                key = (setno, system, info["group"])
                g = games.get(key)
                if g is None:
                    t = info["title"]
                    sk = re.sub(r"^(the|a|an)\s+", "", t.lower())
                    games[key] = g = {
                        "id": format(zlib.crc32(repr(key).encode("utf-8", "replace")) & 0xffffffff, "08x"),
                        "t": t, "k": sk, "s": system, "y": info["year"], "v": info["version"],
                        "p": info["publisher"], "c": info["countries"], "l": info["langs"],
                        "m": info["multi"], "a": info["tags"], "q": setno, "r": reason,
                        "z": 0, "f": [],
                    }
                g["z"] += sz
                g["f"].append([fn, sz])
                files_seen += 1
                if files_seen % 5000 == 0:
                    log(f"   library scan: {files_seen:,} files...")
    out = sorted(games.values(), key=lambda g: (g["k"], g["s"]))
    log(f"Library: {len(out):,} games from {files_seen:,} files.")
    return out


def render_library(games, title, source):
    """Return the finished HTML text."""
    stamp = datetime.datetime.now().strftime("%d %b %Y, %H:%M")
    ident = format(zlib.crc32((title + source).encode("utf-8", "replace")) & 0xffffffff, "08x")
    data = {"meta": {"title": title, "generated": stamp, "source": source, "id": ident}, "games": games}
    blob = json.dumps(data, ensure_ascii=True, separators=(",", ":"))
    blob = blob.replace("</", "<\\/").replace("<!--", "<\\u0021--")
    page = LIB_TEMPLATE.replace("__TITLE__", _html_escape(title))
    return page.replace("__DATA__", blob)       # data goes in last so it can't be re-scanned


def _html_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def write_library(root, eng_dir, other_dir, include_filtered=False, log=print, title="ROM Library"):
    """Scan the sorted folders and write ROM Library.html next to the script."""
    root = Path(root).resolve()
    games = scan_library(root, eng_dir, other_dir, include_filtered, log)
    if not games:
        log("Library not written: no ROM files were found in the sorted folders.")
        return None
    html = render_library(games, title, root.name or str(root))
    path = root / LIB_FILENAME
    tmp = path.with_name(path.name + ".part")
    tmp.write_text(html, encoding="utf-8")
    os.replace(tmp, path)
    log(f"Library written: {path.name}  ({len(games):,} games, {path.stat().st_size / 1048576:.1f} MB)")
    return path


LIB_TEMPLATE = r"""
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="dark light">
<meta name="author" content="normanlove">
<title>__TITLE__</title>
<style>
:root{
  --bg:#0c0f14;--bg2:#10151c;--surf:#151b25;--surf2:#1c2431;--line:#27303f;--line2:#334057;
  --text:#ece7da;--muted:#8d95a6;--faint:#5c6577;--acc:#ffb347;--acc-ink:#1a1204;--acc2:#58d3c6;
  --shadow:0 18px 50px -18px rgba(0,0,0,.7);--glow:rgba(255,179,71,.14);
  --serif:"Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;
  --sans:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,"Liberation Mono",monospace;
  --r:12px;
}
:root[data-theme="light"]{
  --bg:#f3eee2;--bg2:#ede6d6;--surf:#fffaf0;--surf2:#f7f0df;--line:#ddd2ba;--line2:#c9bb9c;
  --text:#1f1b13;--muted:#6d6652;--faint:#9b937c;--acc:#b45309;--acc-ink:#fff8ec;--acc2:#0f766e;
  --shadow:0 16px 40px -20px rgba(70,50,10,.45);--glow:rgba(180,83,9,.10);
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--text);font:15px/1.5 var(--sans);-webkit-font-smoothing:antialiased;
  background-image:radial-gradient(1200px 500px at 85% -10%,var(--glow),transparent 60%),radial-gradient(900px 400px at -10% 10%,rgba(88,211,198,.06),transparent 60%);
  background-attachment:fixed}
button{font:inherit;color:inherit;cursor:pointer}
button:focus-visible,input:focus-visible,select:focus-visible,.card:focus-visible,.row:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
.mono{font-family:var(--mono)}

/* top bar */
.top{position:sticky;top:0;z-index:20;display:flex;gap:12px;align-items:center;padding:12px clamp(16px,3vw,32px);
  background:color-mix(in srgb,var(--bg) 82%,transparent);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.brand{display:flex;align-items:center;gap:10px;font-family:var(--serif);font-weight:700;font-size:19px;letter-spacing:.2px;white-space:nowrap}
.mark{width:28px;height:28px;border-radius:8px;background:conic-gradient(from 210deg,var(--acc),#ff6b6b,var(--acc2),var(--acc));display:grid;place-items:center;box-shadow:0 0 0 1px rgba(255,255,255,.08) inset}
.mark::after{content:"";width:12px;height:12px;border-radius:3px;background:var(--bg);transform:rotate(45deg)}
.search{flex:1;max-width:620px;margin-inline:auto;position:relative}
.search input{width:100%;height:42px;border-radius:999px;border:1px solid var(--line2);background:var(--surf);color:var(--text);padding:0 44px 0 42px;font-size:15px;transition:border-color .15s,box-shadow .15s}
.search input::placeholder{color:var(--faint)}
.search input:focus{outline:none;border-color:var(--acc);box-shadow:0 0 0 4px var(--glow)}
.search svg{position:absolute;left:14px;top:11px;width:20px;height:20px;color:var(--faint)}
.search kbd{position:absolute;right:12px;top:10px;font:12px var(--mono);color:var(--faint);border:1px solid var(--line2);border-radius:6px;padding:1px 7px}
.iconbtn{height:42px;min-width:42px;padding:0 12px;border-radius:999px;border:1px solid var(--line2);background:var(--surf);display:inline-flex;align-items:center;justify-content:center;gap:8px;transition:transform .12s,border-color .15s,background .15s}
.iconbtn:hover{border-color:var(--acc);transform:translateY(-1px)}
.iconbtn svg{width:18px;height:18px}
.iconbtn.on{background:var(--acc);color:var(--acc-ink);border-color:var(--acc)}
.only-m{display:none}

/* layout */
.shell{display:grid;grid-template-columns:288px minmax(0,1fr);gap:0;max-width:1700px;margin:0 auto}
aside{position:sticky;top:67px;align-self:start;height:calc(100vh - 67px);overflow:auto;padding:18px 14px 40px clamp(16px,3vw,32px);scrollbar-width:thin;scrollbar-color:var(--line2) transparent}
main{padding:22px clamp(16px,3vw,32px) 80px 18px;min-width:0}

/* facets */
.facet{margin-bottom:6px;border-bottom:1px solid var(--line);padding-bottom:10px}
.facet summary{list-style:none;cursor:pointer;display:flex;justify-content:space-between;align-items:center;padding:8px 4px;font:600 11.5px var(--mono);text-transform:uppercase;letter-spacing:.14em;color:var(--muted)}
.facet summary::-webkit-details-marker{display:none}
.facet summary::after{content:"+";font-size:15px;color:var(--faint)}
.facet[open] summary::after{content:"–"}
.opts{display:flex;flex-direction:column;gap:2px;max-height:330px;overflow:auto;scrollbar-width:thin;scrollbar-color:var(--line2) transparent}
.opt{position:relative;display:flex;justify-content:space-between;gap:8px;align-items:center;text-align:left;border:0;background:transparent;padding:6px 10px;border-radius:8px;color:var(--text);overflow:hidden;font-size:14px}
.opt::before{content:"";position:absolute;inset:0;width:var(--w,0%);background:var(--surf2);z-index:0;border-radius:8px;transition:width .3s}
.opt>*{position:relative;z-index:1}
.opt span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.opt i{font:12px var(--mono);color:var(--muted);font-style:normal}
.opt:hover{background:var(--surf)}
.opt.on{outline:1px solid var(--acc);color:var(--text)}
.opt.on::before{background:var(--glow);width:100%}
.opt.on i{color:var(--acc)}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{border:1px solid var(--line2);background:var(--surf);border-radius:999px;padding:4px 11px;font-size:13px;display:inline-flex;gap:6px;align-items:center}
.chip i{font:11px var(--mono);color:var(--muted);font-style:normal}
.chip:hover{border-color:var(--acc)}
.chip.on{background:var(--acc);color:var(--acc-ink);border-color:var(--acc)}
.chip.on i{color:inherit;opacity:.75}
.chip.x::after{content:"×";margin-left:2px;font-size:15px;line-height:1}

/* hero */
.hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(220px,380px);gap:28px;align-items:end;padding:14px 0 22px;border-bottom:1px solid var(--line)}
.kicker{font:600 11.5px var(--mono);text-transform:uppercase;letter-spacing:.2em;color:var(--acc)}
h1{font:700 clamp(34px,5vw,60px)/1.02 var(--serif);margin:8px 0 6px;letter-spacing:-.01em}
.sub{color:var(--muted);margin:0}
.stats{display:flex;flex-wrap:wrap;gap:12px 34px;margin-top:20px}
.stat b{display:block;font:700 clamp(26px,3vw,38px)/1 var(--serif);color:var(--text);font-variant-numeric:tabular-nums}
.stat span{font:11.5px var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:.12em}
.tl{display:flex;align-items:flex-end;gap:5px;height:118px;padding-bottom:20px;position:relative}
.tl button{flex:1;border:0;background:transparent;padding:0;height:100%;display:flex;align-items:flex-end;position:relative}
.tl button i{display:block;width:100%;min-height:3px;border-radius:5px 5px 2px 2px;background:linear-gradient(180deg,var(--acc),color-mix(in srgb,var(--acc) 30%,transparent));height:var(--h);transition:height .35s,opacity .2s;opacity:.85}
.tl button:hover i,.tl button.on i{opacity:1;filter:brightness(1.15)}
.tl button.dim i{opacity:.28}
.tl button em{position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font:10.5px var(--mono);color:var(--faint);font-style:normal;white-space:nowrap}
.tl-t{font:600 11px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--faint);margin-bottom:8px}

/* toolbar */
.bar{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center;padding:16px 0 10px}
.bar .grow{flex:1}
.seg{display:inline-flex;border:1px solid var(--line2);border-radius:999px;overflow:hidden;background:var(--surf)}
.seg button{border:0;background:transparent;height:38px;width:42px;display:grid;place-items:center}
.seg button.on{background:var(--acc);color:var(--acc-ink)}
.seg svg{width:17px;height:17px}
select{height:38px;border-radius:999px;border:1px solid var(--line2);background:var(--surf);color:var(--text);padding:0 14px;font:inherit}
.count{font:13px var(--mono);color:var(--muted)}
.active{display:flex;flex-wrap:wrap;gap:6px;padding-bottom:6px}
.rail{display:flex;flex-wrap:wrap;gap:2px;padding:4px 0 14px}
.rail button{border:0;background:transparent;width:28px;height:28px;border-radius:7px;font:600 12.5px var(--mono);color:var(--muted)}
.rail button:hover:not(:disabled){background:var(--surf2);color:var(--text)}
.rail button.on{background:var(--acc);color:var(--acc-ink)}
.rail button:disabled{opacity:.25;cursor:default}

/* grid */
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:22px 18px}
.card{position:relative;display:flex;flex-direction:column;gap:9px;cursor:pointer;animation:rise .45s both;border-radius:var(--r)}
@keyframes rise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.cover{position:relative;aspect-ratio:3/4;border-radius:10px;overflow:hidden;color:#fff;isolation:isolate;
  background:linear-gradient(150deg,hsl(var(--h) 58% 42%),hsl(calc(var(--h) + 48) 62% 20%));
  box-shadow:0 1px 0 rgba(255,255,255,.12) inset,0 10px 24px -12px rgba(0,0,0,.65);transition:transform .22s cubic-bezier(.2,.8,.2,1),box-shadow .22s}
.cover::before{content:"";position:absolute;inset:0;z-index:-1;opacity:.5;
  background:repeating-linear-gradient(135deg,rgba(255,255,255,.07) 0 2px,transparent 2px 14px),radial-gradient(120% 70% at 20% 0%,rgba(255,255,255,.28),transparent 55%)}
.cover::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(255,255,255,.22),rgba(255,255,255,0) 7%,rgba(0,0,0,0) 90%,rgba(0,0,0,.25));pointer-events:none}
.cover b{position:absolute;left:0;right:0;top:50%;transform:translateY(-54%);text-align:center;font:700 clamp(40px,5.2vw,62px)/1 var(--serif);letter-spacing:-.02em;text-shadow:0 3px 18px rgba(0,0,0,.35)}
.cover .sys{position:absolute;left:9px;top:9px;right:40px;font:600 10px var(--mono);letter-spacing:.08em;text-transform:uppercase;background:rgba(0,0,0,.38);backdrop-filter:blur(4px);padding:3px 8px;border-radius:999px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:max-content;max-width:calc(100% - 50px)}
.cover em{position:absolute;right:10px;bottom:8px;font:600 12px var(--mono);font-style:normal;opacity:.85}
.fav{position:absolute;right:7px;top:6px;width:28px;height:28px;border:0;border-radius:50%;background:rgba(0,0,0,.32);color:rgba(255,255,255,.7);font-size:15px;line-height:1;display:grid;place-items:center;transition:transform .15s,background .15s}
.fav:hover{transform:scale(1.15)}
.fav.on{color:#ff5d73;background:rgba(0,0,0,.5)}
.card:hover .cover{transform:translateY(-5px) rotate(-.4deg);box-shadow:0 1px 0 rgba(255,255,255,.14) inset,0 22px 34px -14px rgba(0,0,0,.75)}
.card h3{margin:0;font:600 15px/1.25 var(--serif);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.card p{margin:-5px 0 0;color:var(--muted);font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tag{display:inline-block;font:600 10.5px var(--mono);text-transform:uppercase;letter-spacing:.06em;border:1px solid var(--line2);border-radius:5px;padding:1px 6px;color:var(--muted)}
.tag.v{color:var(--acc2);border-color:color-mix(in srgb,var(--acc2) 50%,transparent)}
.tag.w{color:var(--acc);border-color:color-mix(in srgb,var(--acc) 50%,transparent)}

/* list view */
.list{display:flex;flex-direction:column}
.row{display:grid;grid-template-columns:44px minmax(0,2.2fr) minmax(0,1.2fr) 56px minmax(0,1.2fr) minmax(0,.8fr) 76px;gap:14px;align-items:center;padding:8px 10px;border-bottom:1px solid var(--line);cursor:pointer;border-radius:8px}
.row:hover{background:var(--surf)}
.row .cover{width:44px;aspect-ratio:1;border-radius:7px;box-shadow:none}
.row .cover b{font-size:19px}
.row .cover .sys,.row .cover em,.row .cover .fav{display:none}
.row strong{font:600 15px var(--serif);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row span{color:var(--muted);font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row .num{font-family:var(--mono);text-align:right}
.head{font:600 11px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--faint);cursor:default}
.head:hover{background:none}
.empty{text-align:center;padding:90px 20px;color:var(--muted)}
.empty h2{font:700 28px var(--serif);color:var(--text);margin:0 0 6px}
.sentinel{height:1px}

/* modal */
dialog{border:0;padding:0;background:transparent;color:var(--text);max-width:min(940px,calc(100vw - 24px));width:100%;max-height:calc(100vh - 24px)}
dialog::backdrop{background:rgba(5,7,10,.66);backdrop-filter:blur(6px)}
.sheet{display:grid;grid-template-columns:260px minmax(0,1fr);gap:28px;background:var(--surf);border:1px solid var(--line2);border-radius:18px;padding:26px;box-shadow:var(--shadow);max-height:calc(100vh - 24px);overflow:auto;animation:pop .28s cubic-bezier(.2,.9,.3,1.1)}
@keyframes pop{from{opacity:0;transform:scale(.96) translateY(12px)}to{opacity:1;transform:none}}
.sheet .cover{box-shadow:0 24px 44px -18px rgba(0,0,0,.8)}
.sheet .cover b{font-size:84px}
.sheet h2{font:700 clamp(26px,3.4vw,38px)/1.08 var(--serif);margin:0 0 10px;padding-right:40px}
.tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px}
.close{position:absolute;right:18px;top:16px;width:38px;height:38px;border-radius:50%;border:1px solid var(--line2);background:var(--surf2);font-size:20px;line-height:1}
.sheetwrap{position:relative}
dl{display:grid;grid-template-columns:116px minmax(0,1fr);gap:9px 14px;margin:0 0 18px}
dt{font:600 11px var(--mono);text-transform:uppercase;letter-spacing:.12em;color:var(--faint);padding-top:3px}
dd{margin:0;overflow-wrap:anywhere}
.files{display:flex;flex-direction:column;gap:6px}
.file{display:flex;gap:10px;align-items:center;background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:8px 10px}
.file code{flex:1;font:12.5px/1.4 var(--mono);overflow-wrap:anywhere;color:var(--text)}
.file small{font:12px var(--mono);color:var(--muted);white-space:nowrap}
.file button{border:1px solid var(--line2);background:var(--surf);border-radius:8px;padding:4px 10px;font-size:12.5px}
.file button:hover{border-color:var(--acc)}
.actions{display:flex;gap:8px;margin-top:16px}
.btn{height:40px;padding:0 18px;border-radius:999px;border:1px solid var(--line2);background:var(--surf2)}
.btn.p{background:var(--acc);color:var(--acc-ink);border-color:var(--acc);font-weight:600}
.btn:hover{filter:brightness(1.08)}
footer{max-width:1700px;margin:0 auto;padding:0 clamp(16px,3vw,32px) 40px;color:var(--faint);font:12px var(--mono)}
.toast{position:fixed;left:50%;bottom:26px;transform:translate(-50%,20px);background:var(--text);color:var(--bg);padding:9px 18px;border-radius:999px;font-size:13.5px;opacity:0;pointer-events:none;transition:.25s;z-index:60}
.toast.show{opacity:1;transform:translate(-50%,0)}
.scrim{display:none}

@media (max-width:980px){
  .shell{grid-template-columns:1fr}
  aside{position:fixed;z-index:40;left:0;top:0;bottom:0;height:auto;width:min(86vw,340px);background:var(--bg);border-right:1px solid var(--line2);padding-top:20px;transform:translateX(-102%);transition:transform .28s;box-shadow:var(--shadow)}
  body.drawer aside{transform:none}
  body.drawer .scrim{display:block;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:30}
  main{padding-left:clamp(16px,3vw,32px)}
  .only-m{display:inline-flex}
  .hero{grid-template-columns:1fr}
  .brand span{display:none}
}
@media (max-width:720px){
  .sheet{grid-template-columns:1fr;padding:18px}
  .sheet .cover{max-width:200px}
  dl{grid-template-columns:96px 1fr}
  .row{grid-template-columns:40px minmax(0,1fr) 52px}
  .row .c3,.row .c5,.row .c6,.row .c7{display:none}
  .search kbd{display:none}
  .top{flex-wrap:wrap;row-gap:10px}
  .search{order:9;flex:1 0 100%;max-width:none;margin:0}
  .brand{flex:1}
  .grid{grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:18px 12px}
}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<header class="top">
  <button class="iconbtn only-m" id="openDrawer" aria-label="Filters"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M7 12h10M10 18h4"/></svg></button>
  <div class="brand"><div class="mark"></div><span id="brandName"></span></div>
  <label class="search">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
    <input id="q" type="search" placeholder="Search titles, publishers, systems, filenames…" autocomplete="off" spellcheck="false" aria-label="Search the library">
    <kbd>/</kbd>
  </label>
  <button class="iconbtn" id="favOnly" title="Show favourites only" aria-pressed="false"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7.5-4.6-9.5-9.2C1.2 8.6 3 5 6.4 5c2 0 3.6 1.1 5.6 3.2C14 6.1 15.600 5 17.600 5 21 5 22.800 8.600 21.500 11.800 19.500 16.400 12 21 12 21z"/></svg><b id="favN" class="mono" style="font-weight:600;font-size:13px">0</b></button>
  <button class="iconbtn" id="rand" title="Surprise me"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/></svg></button>
  <button class="iconbtn" id="theme" title="Toggle light / dark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 12.800A9 9 0 1 1 11.200 3a7 7 0 0 0 9.800 9.800z"/></svg></button>
</header>
<div class="scrim" id="scrim"></div>
<div class="shell">
  <aside id="side">
    <details class="facet" open><summary>Systems</summary><div class="opts" id="f-sys"></div></details>
    <details class="facet" open><summary>Decade</summary><div class="chips" id="f-dec"></div></details>
    <details class="facet" open><summary>Region</summary><div class="opts" id="f-reg"></div></details>
    <details class="facet"><summary>Language</summary><div class="opts" id="f-lang"></div></details>
    <details class="facet" open><summary>Status</summary><div class="chips" id="f-tag"></div></details>
    <details class="facet" id="setFacet"><summary>Collection</summary><div class="chips" id="f-set"></div></details>
  </aside>
  <main>
    <section class="hero">
      <div>
        <div class="kicker" id="kicker"></div>
        <h1 id="h1"></h1>
        <p class="sub" id="sub"></p>
        <div class="stats">
          <div class="stat"><b id="s-games">0</b><span>Games</span></div>
          <div class="stat"><b id="s-sys">0</b><span>Systems</span></div>
          <div class="stat"><b id="s-years">–</b><span>Years</span></div>
          <div class="stat"><b id="s-size">0</b><span>On disk</span></div>
        </div>
      </div>
      <div><div class="tl-t">Releases by decade</div><div class="tl" id="tl"></div></div>
    </section>
    <div class="bar">
      <span class="count" id="count"></span>
      <span class="grow"></span>
      <select id="sort" aria-label="Sort by">
        <option value="az">Title A → Z</option><option value="za">Title Z → A</option>
        <option value="new">Newest first</option><option value="old">Oldest first</option>
        <option value="sys">System, then title</option><option value="big">Largest first</option><option value="small">Smallest first</option>
      </select>
      <div class="seg" role="group" aria-label="View">
        <button id="vGrid" title="Cover view" class="on"><svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/></svg></button>
        <button id="vList" title="List view"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>
      </div>
    </div>
    <div class="active" id="active"></div>
    <nav class="rail" id="rail" aria-label="Jump to letter"></nav>
    <div id="out"></div>
    <div class="sentinel" id="sentinel"></div>
  </main>
</div>
<footer id="foot"></footer>
<dialog id="dlg"><div class="sheetwrap"><div class="sheet" id="sheet"></div><button class="close" id="dclose" aria-label="Close">×</button></div></dialog>
<div class="toast" id="toast"></div>
<script type="application/json" id="data">__DATA__</script>
<script>
(()=>{
"use strict";
const D=JSON.parse(document.getElementById("data").textContent);
const META=D.meta, games=D.games;
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const REGION={US:"USA",GB:"United Kingdom",EU:"Europe",JP:"Japan",DE:"Germany",FR:"France",ES:"Spain",IT:"Italy",NL:"Netherlands",SE:"Sweden",AU:"Australia",CA:"Canada",BR:"Brazil",KR:"Korea",CN:"China",TW:"Taiwan",HK:"Hong Kong",AT:"Austria",CH:"Switzerland",BE:"Belgium",DK:"Denmark",NO:"Norway",FI:"Finland",PT:"Portugal",PL:"Poland",RU:"Russia",MX:"Mexico",AR:"Argentina",NZ:"New Zealand",IE:"Ireland",ZA:"South Africa",GR:"Greece",CZ:"Czechia",HU:"Hungary",TR:"Türkiye",IL:"Israel",IN:"India",YU:"Yugoslavia",SK:"Slovakia",HR:"Croatia",SI:"Slovenia",RO:"Romania",BG:"Bulgaria",UA:"Ukraine",ZZ:"Unknown","—":"Not stated"};
const LANG={en:"English",ja:"Japanese",de:"German",fr:"French",es:"Spanish",it:"Italian",nl:"Dutch",sv:"Swedish",da:"Danish",no:"Norwegian",fi:"Finnish",pt:"Portuguese",pl:"Polish",ru:"Russian",ko:"Korean",zh:"Chinese",el:"Greek",cs:"Czech",hu:"Hungarian",tr:"Turkish",he:"Hebrew",hr:"Croatian",sk:"Slovak",ca:"Catalan",multi:"Multi-language"};
const rn=c=>REGION[c]||c, ln=c=>LANG[c]||c.toUpperCase();
const fmt=n=>n.toLocaleString();
const size=b=>{if(!b)return"0 B";const u=["B","KB","MB","GB","TB"];let i=Math.min(4,Math.floor(Math.log(b)/Math.log(1024)));const v=b/Math.pow(1024,i);return(v>=100||i===0?v.toFixed(0):v.toFixed(1))+" "+u[i]};
const hash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
const col=new Intl.Collator(undefined,{numeric:true,sensitivity:"base"});
const ART=/^(the|a|an)\s+/i;
const initials=t=>{const w=t.replace(ART,"").replace(/[^\p{L}\p{N}\s]/gu," ").split(/\s+/).filter(Boolean);if(!w.length)return"?";if(/^\d/.test(w[0]))return w[0].slice(0,3);return(w[0][0]+(w[1]?w[1][0]:w[0][1]||"")).toUpperCase()};
const letterOf=k=>{const c=(k[0]||"#").toUpperCase();return/[A-Z]/.test(c)?c:"#"};

/* ---- store ---- */
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
const FK="romlib:fav:"+META.id;
let fav=new Set();try{fav=new Set(JSON.parse(store.get(FK)||"[]"))}catch(e){}
const saveFav=()=>store.set(FK,JSON.stringify([...fav]));

games.forEach((g,i)=>{
  g.i=i;g.rg=g.c.length?g.c:["—"];g.lg=g.l.length?g.l:(g.m?["multi"]:[]);
  g.dc=g.y?Math.floor(g.y/10)*10+"s":"Unknown";g.sn=g.q?"Filtered out":"Kept";
  g.hay=[g.t,g.p,g.s,g.v,g.f.map(f=>f[0]).join(" ")].join(" ").toLowerCase();
  g.L=letterOf(g.k);g.hue=hash(g.t+g.s)%360;g.ini=initials(g.t);
});
const FAC={sys:g=>[g.s],reg:g=>g.rg,lang:g=>g.lg,dec:g=>[g.dc],tag:g=>g.a,set:g=>[g.sn]};
const LABEL={sys:v=>v,reg:rn,lang:ln,dec:v=>v,tag:v=>v,set:v=>v};
const F={sys:new Set,reg:new Set,lang:new Set,dec:new Set,tag:new Set,set:new Set,fav:false,letter:null,q:""};
let qw=[],res=[],view="grid",shown=0;
const BATCH=96;

function pass(g,except){
  for(const k in FAC){if(k===except)continue;const s=F[k];if(s.size&&!FAC[k](g).some(v=>s.has(v)))return false}
  if(F.fav&&!fav.has(g.id))return false;
  if(except!=="letter"&&F.letter&&g.L!==F.letter)return false;
  for(const w of qw)if(!g.hay.includes(w))return false;
  return true;
}
const SORTS={
  az:(a,b)=>col.compare(a.k,b.k),za:(a,b)=>col.compare(b.k,a.k),
  new:(a,b)=>(b.y||-1)-(a.y||-1)||col.compare(a.k,b.k),
  old:(a,b)=>(a.y||1e9)-(b.y||1e9)||col.compare(a.k,b.k),
  sys:(a,b)=>col.compare(a.s,b.s)||col.compare(a.k,b.k),
  big:(a,b)=>b.z-a.z||col.compare(a.k,b.k),small:(a,b)=>a.z-b.z||col.compare(a.k,b.k)
};

/* ---- facets ---- */
function facetCounts(k){
  const m=new Map();
  for(const g of games){if(!pass(g,k))continue;for(const v of FAC[k](g))m.set(v,(m.get(v)||0)+1)}
  for(const v of F[k])if(!m.has(v))m.set(v,0);
  return m;
}
function renderFacet(k,mode){
  const el=$("#f-"+k),m=facetCounts(k);
  let ents=[...m.entries()];
  if(k==="sys"||k==="reg"||k==="lang")ents.sort((a,b)=>k==="sys"?col.compare(a[0],b[0]):(b[1]-a[1])||col.compare(a[0],b[0]));
  else if(k==="dec")ents.sort((a,b)=>col.compare(a[0],b[0]));
  else ents.sort((a,b)=>b[1]-a[1]);
  const max=Math.max(1,...ents.map(e=>e[1]));
  el.innerHTML=ents.filter(([v,n])=>n>0||F[k].has(v)).map(([v,n])=>{
    const on=F[k].has(v);
    return mode==="chip"
      ?`<button class="chip${on?" on":""}" data-k="${k}" data-v="${esc(v)}">${esc(LABEL[k](v))}<i>${fmt(n)}</i></button>`
      :`<button class="opt${on?" on":""}" data-k="${k}" data-v="${esc(v)}" style="--w:${(n/max*100).toFixed(1)}%"><span>${esc(LABEL[k](v))}</span><i>${fmt(n)}</i></button>`;
  }).join("")||'<span class="count" style="padding:6px 10px">Nothing here</span>';
}
function renderTimeline(){
  const m=new Map();
  for(const g of games){if(!pass(g,"dec"))continue;m.set(g.dc,(m.get(g.dc)||0)+1)}
  const decs=[...new Set(games.map(g=>g.dc))].filter(d=>d!=="Unknown").sort();
  if(games.some(g=>g.dc==="Unknown"))decs.push("Unknown");
  const max=Math.max(1,...decs.map(d=>m.get(d)||0));
  $("#tl").innerHTML=decs.map(d=>{const n=m.get(d)||0,on=F.dec.has(d);
    return`<button data-k="dec" data-v="${d}" class="${on?"on":""}${F.dec.size&&!on?" dim":""}" title="${d}: ${fmt(n)} games"><i style="--h:${(n/max*100).toFixed(1)}%"></i><em>${d==="Unknown"?"?":d.replace("s","")}</em></button>`}).join("");
}
function renderRail(){
  const have=new Set();
  for(const g of games)if(pass(g,"letter"))have.add(g.L);
  $("#rail").innerHTML=["#",..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"].map(l=>`<button data-l="${l}" class="${F.letter===l?"on":""}" ${have.has(l)||F.letter===l?"":"disabled"}>${l}</button>`).join("");
}
function renderActive(){
  const out=[];
  for(const k of ["sys","dec","reg","lang","tag","set"])for(const v of F[k])out.push(`<button class="chip on x" data-k="${k}" data-v="${esc(v)}">${esc(LABEL[k](v))}</button>`);
  if(F.letter)out.push(`<button class="chip on x" data-l="${F.letter}">Starts with ${F.letter}</button>`);
  if(F.fav)out.push(`<button class="chip on x" id="clrFav">Favourites</button>`);
  if(out.length>1)out.push(`<button class="chip" id="clrAll">Clear all</button>`);
  $("#active").innerHTML=out.join("");
}

/* ---- results ---- */
function meta(g){const a=[];if(g.p)a.push(g.p);if(g.c.length)a.push(g.c.map(rn).join(", "));return a.join(" · ")||"—"}
function cover(g,big){
  return`<div class="cover" style="--h:${g.hue}"><span class="sys">${esc(g.s)}</span><b>${esc(g.ini)}</b>${g.y?`<em>${g.y}</em>`:""}${big?"":`<button class="fav${fav.has(g.id)?" on":""}" data-fav="${g.i}" aria-label="Favourite" title="Favourite">♥</button>`}</div>`;
}
function card(g,d){
  const tags=[];if(g.v)tags.push(`<span class="tag v">${esc(g.v)}</span>`);
  return`<article class="card" tabindex="0" data-i="${g.i}" style="animation-delay:${d}ms">${cover(g)}<h3 title="${esc(g.t)}">${esc(g.t)}</h3><p>${esc(g.s)}${g.y?" · "+g.y:""}</p></article>`;
}
function row(g){
  return`<article class="row" tabindex="0" data-i="${g.i}">${cover(g)}<strong title="${esc(g.t)}">${esc(g.t)}${g.v?` <small class="tag v">${esc(g.v)}</small>`:""}</strong><span class="c3">${esc(g.s)}</span><span class="num">${g.y||"–"}</span><span class="c5">${esc(g.p||"—")}</span><span class="c6">${esc(g.c.map(rn).join(", ")||"—")}</span><span class="num c7">${size(g.z)}</span></article>`;
}
function more(){
  const out=$("#out>div");if(!out||shown>=res.length)return;
  const end=Math.min(res.length,shown+BATCH);let h="";
  for(let i=shown;i<end;i++)h+=view==="grid"?card(res[i],Math.min((i-shown)*8,300)):row(res[i]);
  out.insertAdjacentHTML("beforeend",h);shown=end;
  if(shown<res.length&&$("#sentinel").getBoundingClientRect().top<innerHeight+600)more();
}
function renderOut(){
  shown=0;const o=$("#out");
  if(!res.length){o.innerHTML=`<div class="empty"><h2>Nothing on the shelf</h2><p>No games match these filters.</p><button class="btn p" id="clrAll2">Clear filters</button></div>`;return}
  o.innerHTML=view==="grid"?'<div class="grid"></div>':'<div class="list"><div class="row head"><i></i><span>Title</span><span class="c3">System</span><span class="num">Year</span><span class="c5">Publisher</span><span class="c6">Region</span><span class="num c7">Size</span></div></div>';
  more();
}
function stats(){
  const sy=new Set();let mn=1e9,mx=0,z=0;
  for(const g of res){sy.add(g.s);z+=g.z;if(g.y){mn=Math.min(mn,g.y);mx=Math.max(mx,g.y)}}
  $("#s-games").textContent=fmt(res.length);$("#s-sys").textContent=fmt(sy.size);
  $("#s-years").textContent=mx?(mn===mx?mn:mn+"–"+String(mx).slice(2)):"–";
  $("#s-size").textContent=size(z);
  $("#count").textContent=res.length===games.length?`${fmt(games.length)} games`:`${fmt(res.length)} of ${fmt(games.length)} games`;
}
let tm=0;
function update(){
  qw=F.q.toLowerCase().split(/\s+/).filter(Boolean);
  res=games.filter(g=>pass(g)).sort(SORTS[$("#sort").value]);
  renderFacet("sys");renderFacet("reg");renderFacet("lang");renderFacet("dec","chip");renderFacet("tag","chip");renderFacet("set","chip");
  renderTimeline();renderRail();renderActive();stats();renderOut();
  $("#favN").textContent=fav.size;$("#favOnly").classList.toggle("on",F.fav);$("#favOnly").setAttribute("aria-pressed",F.fav);
}

/* ---- detail ---- */
function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");clearTimeout(tm);tm=setTimeout(()=>e.classList.remove("show"),1500)}
function copy(t){
  const done=()=>toast("Copied to clipboard");
  if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(done,fallback);else fallback();
  function fallback(){const a=document.createElement("textarea");a.value=t;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{document.execCommand("copy");done()}catch(e){toast("Copy failed")}a.remove()}
}
function open(g){
  const tags=[];
  g.a.forEach(t=>tags.push(`<span class="tag ${t==="Verified"||t==="Unmodified"?"v":(t==="Modified"||t==="Bad dump"||t==="Pre-release"?"w":"")}">${esc(t)}</span>`));
  if(g.v)tags.unshift(`<span class="tag v">${esc(g.v)}</span>`);
  const dl=[["System",g.s],["Year",g.y||"Unknown"],["Publisher",g.p||"Unknown"],["Region",g.c.map(rn).join(", ")||"Not stated"],["Language",g.l.map(ln).join(", ")||(g.m?"Multi-language":"Not stated")],["Version",g.v||"—"],["Size",size(g.z)+(g.f.length>1?` across ${g.f.length} files`:"")],["Collection",g.q?("Filtered out"+(g.r?" – "+g.r:"")):"Kept"]];
  $("#sheet").innerHTML=`<div>${cover(g,true)}</div><div><h2>${esc(g.t)}</h2><div class="tags">${tags.join("")}</div><dl>${dl.map(([a,b])=>`<dt>${a}</dt><dd>${esc(b)}</dd>`).join("")}</dl><div class="files">${g.f.map((f,i)=>`<div class="file"><code>${esc(f[0])}</code><small>${size(f[1])}</small><button data-copy="${i}">Copy</button></div>`).join("")}</div><div class="actions"><button class="btn p" data-fav="${g.i}" id="dfav">${fav.has(g.id)?"♥ In favourites":"♡ Add to favourites"}</button><button class="btn" id="dcopy">Copy title</button></div></div>`;
  $("#sheet").dataset.i=g.i;
  const d=$("#dlg");if(!d.open)d.showModal();
}

/* ---- events ---- */
function toggle(k,v){const s=F[k];s.has(v)?s.delete(v):s.add(v);update()}
document.addEventListener("click",e=>{
  const t=e.target;
  let b=t.closest("[data-fav]");
  if(b){e.stopPropagation();const g=games[+b.dataset.fav];fav.has(g.id)?fav.delete(g.id):fav.add(g.id);saveFav();
    if(b.id==="dfav")b.textContent=fav.has(g.id)?"♥ In favourites":"♡ Add to favourites";
    document.querySelectorAll(`.fav[data-fav="${g.i}"]`).forEach(x=>x.classList.toggle("on",fav.has(g.id)));
    $("#favN").textContent=fav.size;if(F.fav)update();return}
  b=t.closest("[data-copy]");
  if(b){const g=games[+$("#sheet").dataset.i];copy(g.f[+b.dataset.copy][0]);return}
  b=t.closest("[data-k]");if(b){toggle(b.dataset.k,b.dataset.v);return}
  b=t.closest("[data-l]");if(b&&!b.disabled){F.letter=F.letter===b.dataset.l?null:b.dataset.l;update();return}
  b=t.closest("[data-i]");if(b){open(games[+b.dataset.i]);return}
  if(t.closest("#clrAll,#clrAll2")){for(const k of["sys","reg","lang","dec","tag","set"])F[k].clear();F.fav=false;F.letter=null;F.q="";$("#q").value="";update();return}
  if(t.closest("#clrFav")){F.fav=false;update();return}
  if(t.closest("#dcopy")){copy(games[+$("#sheet").dataset.i].t);return}
  if(t.closest("#dclose")||t.id==="dlg"){$("#dlg").close();return}
});
document.addEventListener("keydown",e=>{
  if((e.key==="Enter"||e.key===" ")&&e.target.matches&&e.target.matches(".card,.row")){e.preventDefault();open(games[+e.target.dataset.i]);return}
  if(e.key==="/"&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)){e.preventDefault();$("#q").focus()}
  if(e.key==="Escape"&&document.activeElement===$("#q")){$("#q").blur()}
});
let qt=0;
$("#q").addEventListener("input",e=>{clearTimeout(qt);qt=setTimeout(()=>{F.q=e.target.value;update()},120)});
$("#sort").addEventListener("change",update);
$("#favOnly").addEventListener("click",()=>{F.fav=!F.fav;update()});
$("#vGrid").addEventListener("click",()=>setView("grid"));
$("#vList").addEventListener("click",()=>setView("list"));
function setView(v){view=v;$("#vGrid").classList.toggle("on",v==="grid");$("#vList").classList.toggle("on",v==="list");store.set("romlib:view",v);renderOut()}
$("#rand").addEventListener("click",()=>{const p=res.length?res:games;if(p.length)open(p[Math.floor(Math.random()*p.length)])});
$("#openDrawer").addEventListener("click",()=>document.body.classList.add("drawer"));
$("#scrim").addEventListener("click",()=>document.body.classList.remove("drawer"));
function setTheme(t){document.documentElement.dataset.theme=t;store.set("romlib:theme",t)}
$("#theme").addEventListener("click",()=>setTheme(document.documentElement.dataset.theme==="dark"?"light":"dark"));
new IntersectionObserver(es=>{if(es[0].isIntersecting)more()},{rootMargin:"700px"}).observe($("#sentinel"));

/* ---- boot ---- */
(function(){
  const saved=store.get("romlib:theme");
  setTheme(saved||(matchMedia("(prefers-color-scheme: light)").matches?"light":"dark"));
  const sv=store.get("romlib:view");if(sv==="list"){view="list";$("#vGrid").classList.remove("on");$("#vList").classList.add("on")}
  $("#brandName").textContent=META.title;$("#h1").textContent=META.title;
  $("#kicker").textContent="Collection catalogue";
  $("#sub").textContent=`Generated ${META.generated} from ${META.source}. Everything on this page is in this one file – it works offline.`;
  $("#foot").textContent=`${META.title} · ${fmt(games.length)} games · built ${META.generated} · created by normanlove · single-file page, no network access needed`;
  if(!games.some(g=>g.q))$("#setFacet").style.display="none";
  document.title=META.title;
  update();
})();
})();
</script>
</body>
</html>
"""
# <<< ROM LIBRARY <<<


class App:
    CHECKED, UNCHECKED = "☑", "☐"

    def __init__(self, win):
        self.win = win
        self.q = queue.Queue()
        self.busy = False
        self.stop = threading.Event()
        self.scan_id = 0
        self.systems = {}              # iid -> SystemInfo
        self.ticked = {}               # iid -> bool
        win.title("ROM Archiver - created by normanlove")
        win.geometry("980x900")
        frm = ttk.Frame(win, padding=10)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="ROM folder (the one that holds the English / Filtered folders):",
                  font=("TkDefaultFont", 10, "bold")).pack(anchor="w")
        rf = ttk.Frame(frm)
        rf.pack(fill="x", pady=(0, 4))
        self.v_root = tk.StringVar()
        e_root = ttk.Entry(rf, textvariable=self.v_root)
        e_root.pack(side="left", fill="x", expand=True)
        e_root.bind("<FocusOut>", lambda ev: self.refresh())
        e_root.bind("<Return>", lambda ev: self.refresh())
        ttk.Button(rf, text="Browse...", command=self.pick_root).pack(side="left", padx=(6, 0))

        self.v_action = tk.StringVar()
        self.v_scope = tk.StringVar()
        self.v_eng = tk.StringVar()
        self.v_oth = tk.StringVar()
        self.v_delete = tk.BooleanVar()
        self.v_comp = tk.StringVar()
        self.v_style = tk.StringVar()
        self.v_skiparch = tk.BooleanVar()
        self.v_container = tk.BooleanVar()
        self.v_csv = tk.BooleanVar()
        self.v_lib = tk.BooleanVar()
        self.v_lib_f = tk.BooleanVar()
        self.v_workers = tk.IntVar()

        # 1. action
        lf = ttk.LabelFrame(frm, text="1. What do you want to do?", padding=6)
        lf.pack(fill="x")
        ttk.Radiobutton(lf, variable=self.v_action, value="zip", command=self.apply_default_ticks,
                        text="Zip  -  each file gets its own .zip, then the original is removed").pack(anchor="w")
        ttk.Radiobutton(lf, variable=self.v_action, value="unzip", command=self.apply_default_ticks,
                        text="Unzip  -  take every file out of its .zip, then remove the .zip").pack(anchor="w")

        # 2. folders
        lf = ttk.LabelFrame(frm, text="2. Which folders?", padding=6)
        lf.pack(fill="x", pady=4)
        row = ttk.Frame(lf)
        row.pack(anchor="w")
        for val, text in (("english", "English folder only"), ("filtered", "Filtered folder only"), ("both", "Both")):
            ttk.Radiobutton(row, variable=self.v_scope, value=val, text=text,
                            command=self.refresh).pack(side="left", padx=(0, 14))
        row = ttk.Frame(lf)
        row.pack(anchor="w", pady=2)
        for label, var in (("English folder:", self.v_eng), ("Filtered folder:", self.v_oth)):
            ttk.Label(row, text=label).pack(side="left")
            e = ttk.Entry(row, textvariable=var, width=24)
            e.pack(side="left", padx=(4, 14))
            e.bind("<FocusOut>", lambda ev: self.refresh())
            e.bind("<Return>", lambda ev: self.refresh())

        # 3. systems
        lf = ttk.LabelFrame(frm, text="3. Which systems?  (click a row to tick / untick it)", padding=6)
        lf.pack(fill="both", expand=True)
        btns = ttk.Frame(lf)
        btns.pack(fill="x", pady=(0, 4))
        for text, cmd in (("Zip-friendly systems", lambda: self.tick_where(lambda s: s.status == ZIP_OK)),
                          ("Systems that need unzipped files",
                           lambda: self.tick_where(lambda s: s.status in (ZIP_NO, ZIP_PARTIAL))),
                          ("Tick all", lambda: self.tick_where(lambda s: True)),
                          ("Tick none", lambda: self.tick_where(lambda s: False)),
                          ("Refresh list", self.refresh)):
            ttk.Button(btns, text=text, command=cmd).pack(side="left", padx=(0, 6))
        box = ttk.Frame(lf)
        box.pack(fill="both", expand=True)
        cols = ("use", "system", "files", "zips", "support", "note")
        self.tree = ttk.Treeview(box, columns=cols, show="headings", height=9, selectmode="none")
        for col, title, width, anchor in (("use", "", 34, "center"), ("system", "System folder", 190, "w"),
                                          ("files", "Files", 60, "e"), ("zips", "Zips", 60, "e"),
                                          ("support", "Emulator support", 150, "w"), ("note", "Note", 420, "w")):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor=anchor, stretch=(col == "note"))
        sb = ttk.Scrollbar(box, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.bind("<Button-1>", self.on_click)
        self.tree.tag_configure(ZIP_OK, foreground="#1a6b2a")
        self.tree.tag_configure(ZIP_NO, foreground="#a02020")
        self.tree.tag_configure(ZIP_PARTIAL, foreground="#a06000")
        self.tree.tag_configure(ZIP_UNKNOWN, foreground="#666666")
        self.sel_label = ttk.Label(lf, foreground="gray")
        self.sel_label.pack(anchor="w", pady=(4, 0))
        ttk.Label(lf, foreground="gray", wraplength=930, justify="left",
                  text="'Emulator support' is based on Batocera's per-system lists of accepted ROM formats. "
                       "Check it matches your own device (MiSTer in particular can differ).").pack(anchor="w")

        # 4. options
        lf = ttk.LabelFrame(frm, text="4. Options", padding=6)
        lf.pack(fill="x", pady=4)
        ttk.Checkbutton(lf, variable=self.v_delete,
                        text="Delete the original once the new files are written and verified (recommended)").pack(anchor="w")
        r = ttk.Frame(lf)
        r.pack(anchor="w", pady=2)
        ttk.Label(r, text="When zipping - compression:").pack(side="left")
        ttk.Combobox(r, textvariable=self.v_comp, state="readonly", width=32,
                     values=list(COMPRESSION_LABELS.values())).pack(side="left", padx=6)
        ttk.Label(r, text="name:").pack(side="left", padx=(10, 0))
        ttk.Radiobutton(r, variable=self.v_style, value="stem", text="Game.zip").pack(side="left", padx=6)
        ttk.Radiobutton(r, variable=self.v_style, value="full", text="Game.adf.zip").pack(side="left")
        ttk.Checkbutton(lf, variable=self.v_skiparch,
                        text="When zipping, leave files that are already archives (.zip .7z .rar .lha ...) alone").pack(anchor="w")
        ttk.Checkbutton(lf, variable=self.v_container,
                        text="When unzipping, put zips that hold several files into a folder named after the zip").pack(anchor="w")
        ttk.Separator(lf).pack(fill="x", pady=4)
        ttk.Checkbutton(lf, variable=self.v_csv,
                        text="Write a CSV report after each run").pack(anchor="w")
        ttk.Checkbutton(lf, variable=self.v_lib,
                        text=f"Build the HTML library ('{LIB_FILENAME}') after each real run - a single browsable page of your games"
                        ).pack(anchor="w")
        ttk.Checkbutton(lf, variable=self.v_lib_f,
                        text="Include the filtered-out games in the library too").pack(anchor="w", padx=(22, 0))
        r = ttk.Frame(lf)
        r.pack(anchor="w", pady=(2, 0))
        ttk.Label(r, text="Files processed at once:").pack(side="left")
        ttk.Spinbox(r, from_=1, to=16, width=3, textvariable=self.v_workers).pack(side="left", padx=6)
        ttk.Label(r, foreground="gray", text="2 is safe for hard drives; try 4+ on an SSD.").pack(side="left")

        bt = ttk.Frame(frm)
        bt.pack(fill="x", pady=6)
        self.b_preview = ttk.Button(bt, text="Preview (changes nothing)", command=lambda: self.start(True))
        self.b_run = ttk.Button(bt, text="Run", command=lambda: self.start(False))
        self.b_stop = ttk.Button(bt, text="Stop", command=self.request_stop)
        self.b_lib = ttk.Button(bt, text="Build library now", command=self.library_now)
        for b in (self.b_preview, self.b_run, self.b_stop, self.b_lib):
            b.pack(side="left", padx=(0, 8))
        self.b_stop.state(["disabled"])

        self.bar = ttk.Progressbar(frm, mode="determinate")
        self.bar.pack(fill="x")
        lb = ttk.Frame(frm)
        lb.pack(fill="both", expand=True, pady=(6, 0))
        sb2 = ttk.Scrollbar(lb)
        sb2.pack(side="right", fill="y")
        self.text = tk.Text(lb, height=7, wrap="word", state="disabled", yscrollcommand=sb2.set)
        self.text.pack(side="left", fill="both", expand=True)
        sb2.config(command=self.text.yview)

        self.apply(Options.load())
        self.log("ROM Archiver - created by normanlove.\nReady. Tick the systems you want, then run a Preview first - it writes a CSV report.")
        win.protocol("WM_DELETE_WINDOW", self.close)
        win.after(100, self.poll)
        self.refresh()

    # ---- options <-> widgets ----
    def pick_root(self):
        d = filedialog.askdirectory(title="Choose the ROM folder",
                                    initialdir=self.v_root.get() or str(Path.home()))
        if d:
            self.v_root.set(d)
            self.options().save()
            self.refresh()

    def root_path(self, quiet=False):
        r = self.v_root.get().strip()
        if not r or not Path(r).is_dir():
            if not quiet:
                messagebox.showinfo("ROM folder", "Choose the ROM folder first (Browse... at the top).")
            return None
        return Path(r).resolve()

    def apply(self, o):
        self.v_root.set(o.root or sorter_root())
        self.v_action.set(o.action)
        self.v_scope.set(o.scope)
        self.v_eng.set(o.eng_dir)
        self.v_oth.set(o.other_dir)
        self.v_delete.set(o.delete_source)
        self.v_comp.set(COMPRESSION_LABELS.get(o.compression, COMPRESSION_LABELS["max"]))
        self.v_style.set(o.name_style)
        self.v_skiparch.set(o.skip_archives)
        self.v_container.set(o.container_folder)
        self.v_csv.set(o.write_csv)
        self.v_lib.set(o.build_library)
        self.v_lib_f.set(o.library_filtered)
        self.v_workers.set(o.workers)

    def options(self):
        o = Options()
        o.root = self.v_root.get().strip()
        o.action = self.v_action.get()
        o.scope = self.v_scope.get()
        o.eng_dir = self.v_eng.get()
        o.other_dir = self.v_oth.get()
        o.delete_source = self.v_delete.get()
        o.compression = next((k for k, v in COMPRESSION_LABELS.items() if v == self.v_comp.get()), "max")
        o.name_style = self.v_style.get()
        o.skip_archives = self.v_skiparch.get()
        o.container_folder = self.v_container.get()
        o.write_csv = self.v_csv.get()
        o.build_library = self.v_lib.get()
        o.library_filtered = self.v_lib_f.get()
        try:
            o.workers = int(self.v_workers.get())
        except (ValueError, tk.TclError):
            o.workers = 2
        return o.normalise()

    def close(self):
        self.options().save()
        self.win.destroy()

    # ---- system list ----
    def refresh(self):
        if self.busy:
            return
        self.scan_id += 1
        sid = self.scan_id
        opts = self.options()
        root = self.root_path(quiet=True)
        if root is None:
            self.sel_label.config(text="Choose a ROM folder above.")
            self.populate([])
            return
        self.sel_label.config(text="Scanning folders...")

        def scan():
            try:
                systems = discover(root, opts)
            except Exception:
                systems = []
            self.q.put(("systems", sid, systems))
        threading.Thread(target=scan, daemon=True).start()

    def default_tick(self, info):
        return info.status == ZIP_OK if self.v_action.get() == "zip" else True

    def populate(self, systems):
        old = dict(self.ticked)
        self.systems, self.ticked = {}, {}
        self.tree.delete(*self.tree.get_children())
        for s in systems:
            iid = s.name.lower()
            self.systems[iid] = s
            self.ticked[iid] = old.get(iid, self.default_tick(s))
            self.tree.insert("", "end", iid=iid, tags=(s.status,),
                             values=self.row_values(iid))
        self.update_summary()

    def row_values(self, iid):
        s = self.systems[iid]
        return (self.CHECKED if self.ticked[iid] else self.UNCHECKED, s.name, f"{s.files:,}", f"{s.zips:,}",
                STATUS_TEXT[s.status], s.note)

    def update_summary(self):
        n = sum(1 for v in self.ticked.values() if v)
        if not self.systems:
            self.sel_label.config(text="No system folders found in the chosen folders.")
        else:
            self.sel_label.config(text=f"{n} of {len(self.systems)} system(s) ticked.")

    def on_click(self, event):
        iid = self.tree.identify_row(event.y)
        if iid and self.tree.identify_region(event.x, event.y) == "cell":
            self.ticked[iid] = not self.ticked[iid]
            self.tree.item(iid, values=self.row_values(iid))
            self.update_summary()
        return "break"

    def tick_where(self, pred):
        for iid, s in self.systems.items():
            self.ticked[iid] = bool(pred(s))
            self.tree.item(iid, values=self.row_values(iid))
        self.update_summary()

    def apply_default_ticks(self):
        self.tick_where(self.default_tick)

    # ---- logging / threads ----
    def log(self, msg):
        self.q.put(("log", msg))

    def progress(self, n, total):
        self.q.put(("progress", n, total))

    def poll(self):
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "log":
                    self.text.configure(state="normal")
                    self.text.insert("end", item[1] + "\n")
                    self.text.see("end")
                    self.text.configure(state="disabled")
                elif item[0] == "progress":
                    self.bar["maximum"], self.bar["value"] = item[2], item[1]
                elif item[0] == "systems":
                    if item[1] == self.scan_id:
                        self.populate(item[2])
                elif item[0] == "done":
                    self.busy = False
                    self.b_preview.state(["!disabled"])
                    self.b_run.state(["!disabled"])
                    self.b_lib.state(["!disabled"])
                    self.b_stop.state(["disabled"])
                    self.refresh()
        except queue.Empty:
            pass
        self.win.after(100, self.poll)

    def request_stop(self):
        self.stop.set()
        self.log("Stopping after the files currently in progress...")

    def start(self, dry):
        if self.busy:
            return
        self.run_root = self.root_path()
        if self.run_root is None:
            return
        opts = self.options()
        opts.save()
        picked = [iid for iid, t in self.ticked.items() if t]
        if not picked:
            messagebox.showinfo("ROM Archiver", "Tick at least one system first.")
            return
        opts.selected = picked
        if not dry:
            what = ("Every file in the ticked systems will be put into its own zip"
                    if opts.action == "zip" else "Every .zip in the ticked systems will be unpacked")
            after = ("and the original will be DELETED once the result has been verified."
                     if opts.delete_source else "and the originals will be kept.")
            msg = f"{what}, {after}\n"
            if opts.action == "zip":
                risky = [self.systems[i].name for i in picked if self.systems[i].status != ZIP_OK]
                if risky:
                    shown = ", ".join(risky[:8]) + (f" and {len(risky) - 8} more" if len(risky) > 8 else "")
                    msg += ("\nWarning: these ticked systems may not run zipped games, so you would need to "
                            f"unzip them before playing:\n{shown}\n")
            if not messagebox.askyesno("Run", msg + "\nContinue?"):
                return
        self.busy = True
        self.stop.clear()
        self.b_preview.state(["disabled"])
        self.b_run.state(["disabled"])
        self.b_lib.state(["disabled"])
        self.b_stop.state(["!disabled"])
        threading.Thread(target=self.worker, args=(dry, opts), daemon=True).start()

    def library_now(self):
        if self.busy:
            return
        root = self.root_path()
        if root is None:
            return
        opts = self.options()
        opts.save()
        self.busy = True
        for b in (self.b_preview, self.b_run, self.b_lib):
            b.state(["disabled"])

        def work():
            try:
                self.log("--- BUILDING LIBRARY ---")
                write_library(root, opts.eng_dir, opts.other_dir, opts.library_filtered, self.log)
            except Exception:
                self.log("ERROR:\n" + traceback.format_exc())
            self.q.put(("done",))
        threading.Thread(target=work, daemon=True).start()

    def worker(self, dry, opts):
        try:
            self.log("--- " + ("PREVIEW" if dry else "RUNNING") + f" ({opts.action}, {opts.scope}) ---")
            run_job(self.run_root, opts, dry, self.log, self.progress, self.stop)
        except Exception:
            self.log("ERROR:\n" + traceback.format_exc())
        self.q.put(("done",))


# --------------------------------------------------------------------------- #
# Command line
# --------------------------------------------------------------------------- #

def cli(argv):
    ap = argparse.ArgumentParser(description="ROM Archiver (created by normanlove) - zip and unzip ROM folders by system.")
    ap.add_argument("--action", choices=["zip", "unzip"])
    ap.add_argument("--list-systems", action="store_true", help="show the systems found and their zip support")
    ap.add_argument("--scope", choices=["english", "filtered", "both"], default="both")
    ap.add_argument("--root", default=None, help="ROM folder that holds the English/Filtered folders "
                    "(default: the one last used in the GUI)")
    ap.add_argument("--eng-dir")
    ap.add_argument("--other-dir")
    ap.add_argument("--systems", help="comma-separated system folder names to process (default: all)")
    ap.add_argument("--preset", choices=["zip-friendly", "needs-unzipped"],
                    help="pick systems by emulator support instead of --systems")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--keep-originals", action="store_true")
    ap.add_argument("--compression", choices=list(COMPRESSION_LABELS), default="max")
    ap.add_argument("--name-style", choices=["stem", "full"], default="stem")
    ap.add_argument("--include-archives", action="store_true", help="also zip files that are already archives")
    ap.add_argument("--container-folder", action="store_true")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--no-report", action="store_true", help="do not write the CSV report")
    ap.add_argument("--library", action="store_true", help="build the HTML library after the run")
    ap.add_argument("--library-only", action="store_true", help="just build the HTML library, change nothing")
    ap.add_argument("--library-include-filtered", action="store_true",
                    help="list the filtered-out games in the library too")
    a = ap.parse_args(argv)
    if not a.list_systems and not a.action and not a.library_only:
        ap.error("--action is required (or use --list-systems / --library-only)")
    o = Options()
    o.action = a.action or "zip"
    o.scope = a.scope
    if a.eng_dir:
        o.eng_dir = a.eng_dir
    if a.other_dir:
        o.other_dir = a.other_dir
    o.delete_source = not a.keep_originals
    o.compression, o.name_style = a.compression, a.name_style
    o.skip_archives = not a.include_archives
    o.container_folder, o.workers = a.container_folder, a.workers
    if a.systems:
        o.selected = [s.strip().lower() for s in a.systems.split(",") if s.strip()]
    o.preset = a.preset
    o.write_csv = not a.no_report
    o.build_library = a.library
    o.library_filtered = a.library_include_filtered
    if not (a.root or sorter_root() or Options.load().root):
        ap.error("--root is required: the ROM folder to work in")
    root = Path(a.root or Options.load().root or sorter_root()).resolve()
    o.normalise()
    if a.library_only:
        return 0 if write_library(root, o.eng_dir, o.other_dir, o.library_filtered, print) else 1
    if a.list_systems:
        for s in discover(root, o, print):
            print(f"{s.name:36s} {s.files:>7,} files {s.zips:>7,} zips  {STATUS_TEXT[s.status]:22s} {s.note}")
        return 0
    res = run_job(root, o, a.dry_run, print, lambda n, t: None, threading.Event())
    return 1 if res["failed"] else 0


def main():
    if len(sys.argv) > 1:
        sys.exit(cli(sys.argv[1:]))
    if tk is None:
        print("Tkinter is not available in this Python installation. "
              "Use the command line mode: python rom_archiver.py --help")
        sys.exit(1)
    win = tk.Tk()
    App(win)
    win.mainloop()


if __name__ == "__main__":
    main()
