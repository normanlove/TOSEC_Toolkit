"""
TOSEC Toolkit  -  launcher
created by normanlove

A small front end that starts the other tools with no console window.
Double-click it (the installer makes shortcuts to it). Needs Python 3.8+ with tkinter.
"""
import os
import subprocess
import sys
import time
import tkinter as tk
from tkinter import ttk, messagebox

HERE = os.path.dirname(os.path.abspath(__file__))
LOGS = os.path.join(HERE, "logs")
CREDIT = "created by normanlove"

TOOLS = [
    ("TOSEC Sorter", "tosec_sorter.py",
     "Sort a TOSEC set into English / Filtered Out folders per system, with frontend "
     "layouts (Batocera, MiSTer, RetroPie, ES-DE, Recalbox), alphabetical folders and an HTML library."),
    ("ROM Archiver", "rom_archiver.py",
     "Zip or unzip every ROM in your collection, with system selection, zip-support "
     "presets and an HTML library."),
    ("ROM Scraper", "rom_scraper.py",
     "Download metadata and artwork from many services. Pause / resume, speed limit, "
     "time-of-day schedule, and automatic frontend detection."),
    ("ROM Converter", "rom_converter.py",
     "PBP to BIN/CUE, BIN/CUE to CHD (needs chdman.exe in this folder), and multi-disc "
     "sorting with .m3u playlists."),
]

BG, CARD, FG, MUTED, ACCENT = "#14161c", "#1d2029", "#e8eaf0", "#8b91a3", "#6ea8fe"


def console_python():
    """python.exe (not pythonw) run with CREATE_NO_WINDOW: no console shows,
    yet errors can still be captured to a log file."""
    exe = sys.executable
    if os.name == "nt":
        d = os.path.dirname(exe)
        cand = os.path.join(d, "python.exe")
        if os.path.isfile(cand):
            return cand
    return exe


def open_path(p):
    try:
        if os.name == "nt":
            os.startfile(p)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", p])
        else:
            subprocess.Popen(["xdg-open", p])
    except Exception as ex:
        messagebox.showerror("TOSEC Toolkit", "Could not open %s\n%s" % (p, ex))


class Launcher:
    def __init__(self, root):
        self.root = root
        self.procs = {}
        self.buttons = {}
        root.title("TOSEC Toolkit  -  " + CREDIT)
        root.configure(bg=BG)
        try:
            ico = os.path.join(HERE, "tosec_toolkit.ico")
            if os.name == "nt" and os.path.isfile(ico):
                root.iconbitmap(ico)
        except Exception:
            pass
        root.geometry("640x560")
        root.minsize(560, 480)
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("TFrame", background=BG)
        st.configure("Card.TFrame", background=CARD)
        st.configure("TLabel", background=BG, foreground=FG)
        st.configure("Card.TLabel", background=CARD, foreground=FG)
        st.configure("Muted.TLabel", background=BG, foreground=MUTED)
        st.configure("CardMuted.TLabel", background=CARD, foreground=MUTED)
        st.configure("TButton", padding=(12, 6))
        st.configure("Accent.TButton", background=ACCENT, foreground="#0b1220", padding=(14, 7))
        st.map("Accent.TButton", background=[("active", "#8dbbff"), ("disabled", "#3a4256")])

        head = ttk.Frame(root)
        head.pack(fill="x", padx=22, pady=(20, 6))
        ttk.Label(head, text="TOSEC Toolkit", font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(head, text="Sort, archive, scrape and convert your ROM collection",
                  style="Muted.TLabel").pack(anchor="w")

        body = ttk.Frame(root)
        body.pack(fill="both", expand=True, padx=22, pady=8)
        for name, script, desc in TOOLS:
            self.card(body, name, script, desc)

        self.chd = ttk.Label(root, text="", style="Muted.TLabel")
        self.chd.pack(anchor="w", padx=24)
        foot = ttk.Frame(root)
        foot.pack(fill="x", padx=22, pady=(6, 16))
        ttk.Button(foot, text="Open tools folder", command=lambda: open_path(HERE)).pack(side="left")
        ttk.Button(foot, text="Open logs", command=self.open_logs).pack(side="left", padx=8)
        ttk.Button(foot, text="Read me", command=self.open_readme).pack(side="left")
        ttk.Label(foot, text=CREDIT, style="Muted.TLabel").pack(side="right")
        self.refresh_chd()
        self.tick()

    def card(self, parent, name, script, desc):
        f = ttk.Frame(parent, style="Card.TFrame")
        f.pack(fill="x", pady=6, ipadx=12, ipady=8)
        left = ttk.Frame(f, style="Card.TFrame")
        left.pack(side="left", fill="x", expand=True, padx=(14, 6))
        ttk.Label(left, text=name, style="Card.TLabel",
                  font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ttk.Label(left, text=desc, style="CardMuted.TLabel", wraplength=400,
                  justify="left").pack(anchor="w", pady=(2, 0))
        have = os.path.isfile(os.path.join(HERE, script))
        b = ttk.Button(f, text="Launch" if have else "Missing", style="Accent.TButton",
                       command=lambda s=script, n=name: self.launch(n, s))
        if not have:
            b.state(["disabled"])
        b.pack(side="right", padx=14)
        self.buttons[script] = b

    def refresh_chd(self):
        ok = any(os.path.isfile(os.path.join(HERE, n)) for n in ("chdman.exe", "chdman"))
        self.chd.config(text=("chdman found - CHD conversion is available." if ok else
                              "chdman.exe not found. Copy it into the tools folder to enable CHD conversion."))

    def open_readme(self):
        p = os.path.join(HERE, "TOSEC_Toolkit_README.txt")
        if os.path.isfile(p):
            open_path(p)
        else:
            messagebox.showinfo("TOSEC Toolkit", "The README file was not found in the tools folder.")

    def open_logs(self):
        os.makedirs(LOGS, exist_ok=True)
        open_path(LOGS)

    def launch(self, name, script):
        p = self.procs.get(script)
        if p and p.poll() is None:
            return
        os.makedirs(LOGS, exist_ok=True)
        log_path = os.path.join(LOGS, os.path.splitext(script)[0] + ".log")
        try:
            log = open(log_path, "w", encoding="utf-8", errors="replace")
            log.write("# %s started %s\n" % (script, time.strftime("%Y-%m-%d %H:%M:%S")))
            log.flush()
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
            env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
            p = subprocess.Popen([console_python(), os.path.join(HERE, script)],
                                 cwd=HERE, stdin=subprocess.DEVNULL, stdout=log,
                                 stderr=subprocess.STDOUT, env=env, **kw)
        except Exception as ex:
            messagebox.showerror("TOSEC Toolkit", "Could not start %s:\n%s" % (name, ex))
            return
        self.procs[script] = p
        self.started = getattr(self, "started", {})
        self.started[script] = (time.time(), log_path, name)

    def tick(self):
        for script, p in list(self.procs.items()):
            b = self.buttons[script]
            rc = p.poll()
            if rc is None:
                b.config(text="Running...")
                b.state(["disabled"])
            else:
                b.config(text="Launch")
                b.state(["!disabled"])
                t0, lp, name = self.started[script]
                del self.procs[script]
                if rc != 0:
                    if messagebox.askyesno("TOSEC Toolkit", "%s closed with an error (code %s).\n\n"
                                           "Open its log?" % (name, rc)):
                        open_path(lp)
        self.refresh_chd()
        self.root.after(1000, self.tick)


def main():
    root = tk.Tk()
    Launcher(root)
    root.mainloop()


if __name__ == "__main__":
    main()
