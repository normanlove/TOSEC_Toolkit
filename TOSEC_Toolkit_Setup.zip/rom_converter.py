#!/usr/bin/env python3
"""
ROM Converter  -  PBP -> BIN/CUE -> CHD, with multi-disc M3U playlists
created by normanlove

What it does
  1. PBP  -> BIN/CUE   (built-in reader for PlayStation 1 "PSone Classics"
                        EBOOT.PBP files; no external tool needed)
  2. BIN/CUE -> CHD    (uses chdman; put chdman.exe in the same folder as this
                        script, or have chdman on your PATH)
  3. Multi-disc games  are detected from "(Disc 1)", "(Disc 2 of 3)",
                        "(Disk 1)", "[CD2]" ... tags (and from multi-disc PBPs),
                        optionally put in a folder of their own, and given an
                        .m3u playlist.

Safe by default: sources are never touched unless you tick "delete sources",
and even then only after the new file was written and (for CHD) verified.

GUI:  python rom_converter.py
CLI:  python rom_converter.py /roms/psx -o /roms/out --pbp --chd
      python rom_converter.py --help

Needs Python 3.8+ (tkinter only for the GUI).
"""
import argparse
import csv
import datetime
import os
import queue
import re
import shutil
import struct
import subprocess
import sys
import threading
import zlib
from collections import OrderedDict

try:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
except Exception:  # headless / no Tk: CLI still works
    tk = None
    ttk = filedialog = messagebox = None

APP = "ROM Converter"
CREDIT = "created by normanlove"
SECTOR = 2352
BLOCK = 0x9300            # 16 raw sectors
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CANCEL = threading.Event()
_PROC = {"p": None}


class ConvError(Exception):
    pass


# ----------------------------------------------------------------------------
# chdman
# ----------------------------------------------------------------------------
def find_chdman(explicit=None):
    cands = []
    if explicit:
        cands.append(explicit)
    for n in ("chdman.exe", "chdman"):
        cands.append(os.path.join(SCRIPT_DIR, n))
        cands.append(os.path.join(os.getcwd(), n))
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return shutil.which("chdman") or shutil.which("chdman.exe")


def run_chdman(exe, args, log=None):
    """Run chdman, streaming its output. Returns (rc, text)."""
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
    p = subprocess.Popen([exe] + list(args), stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, **kw)
    _PROC["p"] = p
    out = []
    buf = b""
    last = ""
    try:
        while True:
            ch = p.stdout.read(1)
            if not ch:
                break
            if ch in (b"\r", b"\n"):
                if buf:
                    line = buf.decode("utf-8", "replace").strip()
                    buf = b""
                    out.append(line)
                    if log and line and "%" in line and line != last:
                        last = line
                        log(("progress", line))
            else:
                buf += ch
            if CANCEL.is_set():
                p.terminate()
                break
        p.wait()
    finally:
        _PROC["p"] = None
    if buf:
        out.append(buf.decode("utf-8", "replace").strip())
    return p.returncode, "\n".join(out)


def chdman_createcd(exe, cue, chd, log=None):
    tmp = chd[:-4] + ".tmp.chd"
    if os.path.exists(tmp):
        os.remove(tmp)
    rc, out = run_chdman(exe, ["createcd", "-i", cue, "-o", tmp], log)
    if CANCEL.is_set():
        _rm(tmp)
        raise ConvError("cancelled")
    if rc != 0 or not os.path.isfile(tmp):
        _rm(tmp)
        raise ConvError("chdman createcd failed: " + (out.strip().splitlines() or ["?"])[-1])
    return tmp


def chdman_verify(exe, chd, log=None):
    rc, out = run_chdman(exe, ["verify", "-i", chd], log)
    if CANCEL.is_set():
        raise ConvError("cancelled")
    if rc != 0:
        raise ConvError("chdman verify failed: " + (out.strip().splitlines() or ["?"])[-1])


def _rm(p):
    try:
        os.remove(p)
    except OSError:
        pass


# ----------------------------------------------------------------------------
# PBP reader (PlayStation 1 images)
# ----------------------------------------------------------------------------
def _bcd(b):
    return (b >> 4) * 10 + (b & 15)


def _msf_lba(m, s, f):
    return (_bcd(m) * 60 + _bcd(s)) * 75 + _bcd(f) - 150


def _lba_msf(lba):
    return "%02d:%02d:%02d" % (lba // 4500, (lba // 75) % 60, lba % 75)


def _find_all(f, magic, start, size):
    """Offsets of magic at/after start (fallback scan)."""
    res = []
    pos = start
    keep = len(magic) - 1
    tail = b""
    base = start
    f.seek(start)
    while True:
        chunk = f.read(1 << 24)
        if not chunk:
            break
        data = tail + chunk
        i = 0
        while True:
            j = data.find(magic, i)
            if j < 0:
                break
            res.append(base - len(tail) + j)
            i = j + 1
        tail = data[-keep:]
        base += len(chunk)
    return res


def pbp_disc_offsets(f, size):
    f.seek(0)
    h = f.read(0x28)
    if len(h) < 0x28 or h[:4] != b"\x00PBP":
        raise ConvError("not a PBP file")
    offs = struct.unpack("<8I", h[8:40])
    psar = offs[7]
    if psar <= 0x28 or psar >= size:
        raise ConvError("PBP has no DATA.PSAR section")
    f.seek(psar)
    m = f.read(16)
    if m[:4] == b"\x00PGD":
        raise ConvError("PBP is encrypted (PGD); it must be decrypted first")
    if m[:12] == b"PSISOIMG0000":
        return [psar]
    if m == b"PSTITLEIMG000000":
        f.seek(psar + 0x200)
        raw = struct.unpack("<5I", f.read(20))
        ds = [psar + o for o in raw if o]
        ok = []
        for d in ds:
            if d + 16 < size:
                f.seek(d)
                if f.read(12) == b"PSISOIMG0000":
                    ok.append(d)
        if len(ok) == len([o for o in raw if o]) and ok:
            return ok
        scan = _find_all(f, b"PSISOIMG0000", psar, size)
        if scan:
            return scan
        raise ConvError("multi-disc PBP: could not locate disc images")
    if m[:8] == b"NPUMDIMG":
        raise ConvError("this is a PSP (UMD) EBOOT, not a PS1 disc image")
    raise ConvError("unrecognised PBP data (not a PSone image)")


def pbp_disc_count(path):
    try:
        with open(path, "rb") as f:
            return len(pbp_disc_offsets(f, os.path.getsize(path)))
    except (OSError, ConvError):
        return 1


def _parse_disc(f, d, size):
    f.seek(d + 0x800)
    raw = f.read(10 * 110)
    tracks, leadout = [], None
    for i in range(0, len(raw) - 9, 10):
        e = raw[i:i + 10]
        if not any(e):
            break
        ctrl, point = e[0], e[2]
        lba = _msf_lba(e[7], e[8], e[9])
        if point == 0xA2:
            leadout = lba
        elif point < 0xA0 and 1 <= _bcd(point) <= 99:
            tracks.append((_bcd(point), bool(ctrl & 0x40), lba))
    if not tracks or leadout is None:
        raise ConvError("disc TOC not found / unreadable")
    tracks.sort()
    prev = -1
    for n, _, lba in tracks:
        if lba < prev:
            raise ConvError("disc TOC is inconsistent")
        prev = lba
    if leadout <= tracks[-1][2]:
        raise ConvError("disc TOC is inconsistent (leadout)")
    total = leadout
    nblocks = (total + 15) // 16
    # locate the compressed data (try the usual place first, then the header hint)
    f.seek(d + 0xBFC)
    hint = struct.unpack("<I", f.read(4))[0]
    bases = [d + 0x100000]
    if 0 < hint < size and d + hint not in bases:
        bases.append(d + hint)
    f.seek(d + 0x4000)
    ent0 = f.read(32)
    if len(ent0) < 32:
        raise ConvError("block index missing")
    off0, len0 = struct.unpack("<IH", ent0[:6])
    base = None
    for b in bases:
        try:
            f.seek(b + off0)
            blk = f.read(len0)
            if len0 == BLOCK:
                good = True
            else:
                good = len(zlib.decompressobj(-15).decompress(blk)) == BLOCK
        except Exception:
            good = False
        if good:
            base = b
            break
    if base is None:
        raise ConvError("could not find compressed disc data (unsupported PBP layout)")
    return {"tracks": tracks, "total": total, "nblocks": nblocks, "base": base,
            "index": d + 0x4000}


def pbp_extract_disc(f, d, size, bin_path, progress=None):
    info = _parse_disc(f, d, size)
    total, nblocks = info["total"], info["nblocks"]
    tmp = bin_path + ".part"
    written = 0
    try:
        with open(tmp, "wb") as out:
            for i in range(nblocks):
                if CANCEL.is_set():
                    raise ConvError("cancelled")
                f.seek(info["index"] + i * 32)
                ent = f.read(32)
                if len(ent) < 32:
                    raise ConvError("block index truncated")
                off, ln = struct.unpack("<IH", ent[:6])
                if ln == 0:
                    raise ConvError("empty block %d in index" % i)
                f.seek(info["base"] + off)
                blk = f.read(ln)
                if len(blk) != ln:
                    raise ConvError("data truncated at block %d" % i)
                data = blk if ln == BLOCK else zlib.decompressobj(-15).decompress(blk)
                if len(data) < BLOCK and i < nblocks - 1:
                    raise ConvError("block %d decompressed to %d bytes" % (i, len(data)))
                want = min(16, total - i * 16) * SECTOR
                data = data[:want]
                if len(data) != want:
                    raise ConvError("block %d is short" % i)
                out.write(data)
                written += want
                if progress and i % 256 == 0:
                    progress(i * 100 // nblocks)
        if written != total * SECTOR:
            raise ConvError("size mismatch after extraction")
        os.replace(tmp, bin_path)
    except Exception:
        _rm(tmp)
        raise
    return info


def write_cue(cue_path, bin_name, tracks):
    lines = ['FILE "%s" BINARY' % bin_name]
    for n, data, lba in tracks:
        lines.append("  TRACK %02d %s" % (n, "MODE2/2352" if data else "AUDIO"))
        lines.append("    INDEX 01 %s" % _lba_msf(max(0, lba) if n > 1 else 0))
    with open(cue_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(lines) + "\n")


# ----------------------------------------------------------------------------
# names / multi-disc detection
# ----------------------------------------------------------------------------
DISC_RE = re.compile(r"\s*[\(\[]\s*(?:disc|disk|cd)\s*0*(\d+)(?:\s*(?:of|/)\s*(\d+))?\s*[\)\]]",
                     re.I)
DISC_BARE = re.compile(r"[\s_-]+(?:disc|disk|cd)\s*0*(\d+)\s*$", re.I)


def split_disc(stem):
    """-> (title without disc tag, disc number or None)."""
    m = DISC_RE.search(stem)
    if m:
        return (stem[:m.start()] + stem[m.end():]).strip(), int(m.group(1))
    m = DISC_BARE.search(stem)
    if m:
        return stem[:m.start()].strip(), int(m.group(1))
    return stem.strip(), None


def tag_name(title, n):
    """Insert '(Disc n)' after the title, before other tags."""
    m = re.search(r"\s[\(\[]", title)
    if m:
        return "%s (Disc %d)%s" % (title[:m.start()], n, title[m.start():])
    return "%s (Disc %d)" % (title, n)


def safe_name(s):
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", s).strip(" .")
    return s or "game"


# ----------------------------------------------------------------------------
# options / planning
# ----------------------------------------------------------------------------
class Options:
    def __init__(self, **kw):
        self.sources = []
        self.out_dir = ""          # "" = next to the source
        self.do_pbp = True
        self.do_chd = True
        self.keep_bincue = False   # keep BIN/CUE once a CHD exists
        self.delete_source = False
        self.verify = True
        self.multidisc_m3u = True
        self.m3u_all = False       # playlist for single-disc games too
        self.group_folder = True   # put multi-disc games in their own folder
        self.include_chd = True    # existing .chd files take part in m3u/sorting
        self.overwrite = False
        self.write_csv = True
        self.dry_run = False
        self.chdman = None
        for k, v in kw.items():
            setattr(self, k, v)


class Entry:
    """One disc to be produced."""
    def __init__(self, kind, src, rel, disc_idx, ndiscs, title, disc_no, outstem):
        self.kind, self.src, self.rel = kind, src, rel
        self.disc_idx, self.ndiscs = disc_idx, ndiscs
        self.title, self.disc_no, self.outstem = title, disc_no, outstem
        self.final = None
        self.status = ""
        self.note = ""


def scan_sources(opts):
    entries = []
    for root in opts.sources:
        root = os.path.abspath(root)
        if os.path.isfile(root):
            walk = [(os.path.dirname(root), [], [os.path.basename(root)])]
            base = os.path.dirname(root)
        else:
            walk = os.walk(root)
            base = root
        for dp, dn, fn in walk:
            dn.sort()
            rel = os.path.relpath(dp, base)
            rel = "" if rel == "." else rel
            have_cue = {x.lower() for x in fn if x.lower().endswith(".cue")}
            for name in sorted(fn):
                low = name.lower()
                stem, ext = os.path.splitext(name)
                path = os.path.join(dp, name)
                if ext.lower() == ".pbp" and opts.do_pbp:
                    n = pbp_disc_count(path)
                    title, dno = split_disc(stem)
                    for i in range(n):
                        if n > 1:
                            no = i + 1
                            ostem = tag_name(title, no)
                        else:
                            no = dno
                            ostem = stem
                        entries.append(Entry("pbp", path, rel, i, n, title, no, ostem))
                elif ext.lower() == ".cue" and opts.do_chd:
                    title, dno = split_disc(stem)
                    entries.append(Entry("cue", path, rel, 0, 1, title, dno, stem))
                elif ext.lower() == ".chd" and opts.include_chd and ".tmp." not in low:
                    title, dno = split_disc(stem)
                    entries.append(Entry("chd", path, rel, 0, 1, title, dno, stem))
    return entries


def group_entries(entries):
    groups = OrderedDict()
    for e in entries:
        groups.setdefault((e.rel.lower(), e.title.lower()), []).append(e)
    return groups


def dest_dir(opts, e, multi):
    base = os.path.join(opts.out_dir, e.rel) if opts.out_dir else os.path.dirname(e.src)
    if multi and opts.group_folder:
        # if the source already sits in a folder with the title's name, reuse it
        if os.path.basename(base).lower() != safe_name(e.title).lower():
            base = os.path.join(base, safe_name(e.title))
    return base


# ----------------------------------------------------------------------------
# job
# ----------------------------------------------------------------------------
def run_job(opts, log=print, progress=None):
    """Returns list of result dicts."""
    CANCEL.clear()
    results = []
    exe = None
    if opts.do_chd:
        exe = find_chdman(opts.chdman)
        if not exe:
            raise ConvError("chdman not found. Put chdman.exe next to this script "
                            "(or install chdman and add it to PATH).")
        log("Using chdman: " + exe)
    entries = scan_sources(opts)
    if not entries:
        log("Nothing to do: no matching files found.")
        return results
    groups = group_entries(entries)
    log("Found %d disc(s) in %d game(s)." % (len(entries), len(groups)))
    done_n = 0
    total_n = len(entries)
    pbp_cache = {}

    def res(e, status, note="", out=""):
        e.status, e.note = status, note
        results.append({"game": e.title, "disc": e.disc_no or "", "source": e.src,
                        "kind": e.kind, "output": out, "status": status, "note": note})
        log("  [%s] %s%s" % (status, os.path.basename(e.src),
                             (" - " + note) if note else ""))

    for (rel, tkey), grp in groups.items():
        if CANCEL.is_set():
            break
        multi = len(grp) > 1
        for e in grp:
            if CANCEL.is_set():
                break
            done_n += 1
            if progress:
                progress(("item", done_n, total_n))
            dd = dest_dir(opts, e, multi)
            log("(%d/%d) %s" % (done_n, total_n,
                                os.path.basename(e.src) +
                                (" [disc %d/%d]" % (e.disc_idx + 1, e.ndiscs) if e.ndiscs > 1 else "")))
            try:
                if opts.dry_run:
                    ext = ".chd" if (opts.do_chd and e.kind != "chd") else \
                        (".cue" if e.kind == "pbp" else os.path.splitext(e.src)[1])
                    e.final = os.path.join(dd, e.outstem + ext)
                    res(e, "dry-run", "-> " + e.final, e.final)
                    continue
                os.makedirs(dd, exist_ok=True)
                e.final = process_entry(opts, e, dd, exe, log, progress)
                res(e, "ok", "", e.final)
            except ConvError as ex:
                res(e, "cancelled" if str(ex) == "cancelled" else "error", str(ex))
            except Exception as ex:  # noqa
                res(e, "error", "%s: %s" % (type(ex).__name__, ex))

        # playlist
        ok = [e for e in grp if e.status == "ok" and e.final]
        if opts.multidisc_m3u and not CANCEL.is_set() and \
                (len(grp) > 1 or opts.m3u_all) and ok and len(ok) == len(grp) \
                and not opts.dry_run:
            try:
                p = write_m3u(grp, ok, opts, multi)
                if p:
                    log("  playlist: " + p)
                    results.append({"game": grp[0].title, "disc": "", "source": "",
                                    "kind": "m3u", "output": p, "status": "ok", "note": ""})
            except OSError as ex:
                log("  playlist failed: %s" % ex)
        elif opts.multidisc_m3u and multi and len(ok) != len(grp) and not opts.dry_run:
            log("  playlist skipped: not every disc converted")

    if opts.delete_source and not opts.dry_run and not CANCEL.is_set():
        by = {}
        for e in entries:
            if e.kind == "pbp":
                by.setdefault(e.src, []).append(e.status == "ok")
        for src, oks in by.items():
            if all(oks):
                _rm(src)
                log("  removed source: " + os.path.basename(src))
    return results


def write_m3u(grp, ok, opts, multi):
    # discs must live in one folder for relative paths; otherwise use the first
    folder = os.path.dirname(ok[0].final)
    if any(os.path.dirname(e.final) != folder for e in ok):
        return None
    order = sorted(ok, key=lambda e: (e.disc_no if e.disc_no is not None else 999,
                                      e.disc_idx, e.outstem.lower()))
    p = os.path.join(folder, safe_name(grp[0].title) + ".m3u")
    with open(p, "w", encoding="utf-8", newline="\n") as fh:
        for e in order:
            fh.write(os.path.basename(e.final) + "\n")
    return p


def process_entry(opts, e, dd, exe, log, progress):
    """Do the work for one disc; return the final artefact path."""
    cue = None
    made = []          # bin/cue files created by us (removable)
    if e.kind == "chd":
        # already a CHD: only sort/move when it is not where it belongs
        tgt = os.path.join(dd, os.path.basename(e.src))
        if os.path.abspath(tgt) == os.path.abspath(e.src):
            return e.src
        if os.path.exists(tgt) and not opts.overwrite:
            raise ConvError("target exists: " + tgt)
        if opts.delete_source or not opts.out_dir:
            shutil.move(e.src, tgt)       # sorting in place = move
        else:
            shutil.copy2(e.src, tgt)
        return tgt

    if e.kind == "pbp":
        cue = os.path.join(dd, e.outstem + ".cue")
        binp = os.path.join(dd, e.outstem + ".bin")
        chd = os.path.join(dd, e.outstem + ".chd")
        if opts.do_chd and os.path.exists(chd) and not opts.overwrite:
            raise ConvError("CHD already exists (enable overwrite)")
        if (not opts.do_chd) and os.path.exists(cue) and not opts.overwrite:
            raise ConvError("CUE already exists (enable overwrite)")
        with open(e.src, "rb") as f:
            size = os.path.getsize(e.src)
            offs = pbp_disc_offsets(f, size)
            if e.disc_idx >= len(offs):
                raise ConvError("disc index out of range")
            log("  extracting BIN/CUE ...")
            info = pbp_extract_disc(f, offs[e.disc_idx], size, binp,
                                    lambda p: progress and progress(("pct", p)))
        write_cue(cue, os.path.basename(binp), info["tracks"])
        made = [cue, binp]
    else:  # cue
        cue = e.src
        chd = os.path.join(dd, e.outstem + ".chd")
        check_cue(cue)

    final = cue
    if opts.do_chd:
        if os.path.exists(chd) and not opts.overwrite:
            raise ConvError("CHD already exists (enable overwrite)")
        log("  creating CHD ...")
        tmp = chdman_createcd(exe, cue, chd, lambda m: progress and progress(m))
        try:
            if opts.verify:
                log("  verifying CHD ...")
                chdman_verify(exe, tmp, lambda m: progress and progress(m))
            os.replace(tmp, chd)
        except Exception:
            _rm(tmp)
            raise
        final = chd
        if e.kind == "pbp" and not opts.keep_bincue:
            for p in made:
                _rm(p)
        if opts.delete_source and e.kind == "cue":
            remove_cue_set(cue)
    return final


def check_cue(cue):
    base = os.path.dirname(cue)
    try:
        txt = open(cue, "r", encoding="utf-8", errors="replace").read()
    except OSError as ex:
        raise ConvError("cannot read cue: %s" % ex)
    files = re.findall(r'^\s*FILE\s+(?:"([^"]+)"|(\S+))', txt, re.M | re.I)
    if not files:
        raise ConvError("cue has no FILE entries")
    for a, b in files:
        n = a or b
        if not os.path.isfile(os.path.join(base, n)):
            raise ConvError("missing file referenced by cue: " + n)
    return [a or b for a, b in files]


def remove_cue_set(cue):
    base = os.path.dirname(cue)
    for n in set(check_cue(cue)):
        _rm(os.path.join(base, n))
    _rm(cue)


def write_report(results, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["game", "disc", "kind", "status", "source", "output", "note"])
        for r in results:
            w.writerow([r["game"], r["disc"], r["kind"], r["status"], r["source"],
                        r["output"], r["note"]])


def finish(opts, results, log):
    ok = sum(1 for r in results if r["status"] == "ok" and r["kind"] != "m3u")
    bad = sum(1 for r in results if r["status"] == "error")
    m3u = sum(1 for r in results if r["kind"] == "m3u")
    log("Done: %d converted, %d playlist(s), %d error(s)." % (ok, m3u, bad))
    if opts.write_csv and results and not opts.dry_run:
        src0 = os.path.abspath(opts.sources[0]) if opts.sources else os.getcwd()
        folder = opts.out_dir or (src0 if os.path.isdir(src0) else os.path.dirname(src0))
        p = os.path.join(folder, "rom_converter_report_%s.csv" %
                         datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
        try:
            write_report(results, p)
            log("Report: " + p)
        except OSError as ex:
            log("Could not write report: %s" % ex)


# ----------------------------------------------------------------------------
# GUI
# ----------------------------------------------------------------------------
class App:
    def __init__(self, root):
        self.root = root
        root.title("%s  -  %s" % (APP, CREDIT))
        root.geometry("820x700")
        self.q = queue.Queue()
        self.worker = None
        self.srcs = []
        v = lambda x: tk.BooleanVar(value=x)  # noqa
        self.v = {k: v(d) for k, d in [
            ("do_pbp", True), ("do_chd", True), ("keep_bincue", False),
            ("delete_source", False), ("verify", True), ("multidisc_m3u", True),
            ("m3u_all", False), ("group_folder", True), ("include_chd", True),
            ("overwrite", False), ("write_csv", True), ("dry_run", False)]}
        self.out = tk.StringVar()
        self.chd = tk.StringVar(value=find_chdman() or "")
        pad = {"padx": 8, "pady": 3}
        f = ttk.LabelFrame(root, text="Folders to scan")
        f.pack(fill="x", **pad)
        self.lb = tk.Listbox(f, height=4)
        self.lb.pack(side="left", fill="x", expand=True, padx=4, pady=4)
        b = ttk.Frame(f)
        b.pack(side="right", padx=4)
        ttk.Button(b, text="Add folder...", command=self.add).pack(fill="x", pady=1)
        ttk.Button(b, text="Remove", command=self.rem).pack(fill="x", pady=1)
        g = ttk.LabelFrame(root, text="Output folder (empty = next to each source)")
        g.pack(fill="x", **pad)
        ttk.Entry(g, textvariable=self.out).pack(side="left", fill="x", expand=True, padx=4, pady=4)
        ttk.Button(g, text="Browse...", command=self.pick_out).pack(side="right", padx=4)
        h = ttk.LabelFrame(root, text="chdman (put chdman.exe next to this script)")
        h.pack(fill="x", **pad)
        ttk.Entry(h, textvariable=self.chd).pack(side="left", fill="x", expand=True, padx=4, pady=4)
        ttk.Button(h, text="Browse...", command=self.pick_chd).pack(side="right", padx=4)
        self.chd_lbl = ttk.Label(root, text="")
        self.chd_lbl.pack(anchor="w", padx=12)
        o = ttk.LabelFrame(root, text="Steps and options")
        o.pack(fill="x", **pad)
        opts = [
            ("do_pbp", "Convert PBP  ->  BIN/CUE"),
            ("do_chd", "Convert BIN/CUE  ->  CHD (needs chdman)"),
            ("keep_bincue", "Keep BIN/CUE made from PBPs after the CHD exists"),
            ("verify", "Verify each CHD after creating it"),
            ("multidisc_m3u", "Create .m3u playlists for multi-disc games"),
            ("group_folder", "Put multi-disc games in a folder of their own"),
            ("m3u_all", "Also create a playlist for single-disc games"),
            ("include_chd", "Include existing .chd files when sorting multi-disc games"),
            ("overwrite", "Overwrite existing output files"),
            ("delete_source", "Delete source files after a verified conversion"),
            ("write_csv", "Write a CSV report"),
            ("dry_run", "Dry run (show what would happen, change nothing)"),
        ]
        for i, (k, t) in enumerate(opts):
            ttk.Checkbutton(o, text=t, variable=self.v[k]).grid(
                row=i // 2, column=i % 2, sticky="w", padx=8, pady=1)
        c = ttk.Frame(root)
        c.pack(fill="x", **pad)
        self.go = ttk.Button(c, text="Start", command=self.start)
        self.go.pack(side="left")
        self.stop = ttk.Button(c, text="Stop", command=self.cancel, state="disabled")
        self.stop.pack(side="left", padx=6)
        self.bar = ttk.Progressbar(c, maximum=100)
        self.bar.pack(side="left", fill="x", expand=True, padx=8)
        self.status = ttk.Label(root, text="")
        self.status.pack(anchor="w", padx=12)
        self.txt = tk.Text(root, height=14, wrap="none")
        self.txt.pack(fill="both", expand=True, **pad)
        ttk.Label(root, text=CREDIT).pack(anchor="e", padx=10)
        self.refresh_chd()
        self.chd.trace_add("write", lambda *a: self.refresh_chd())
        root.after(100, self.poll)

    def refresh_chd(self):
        exe = find_chdman(self.chd.get() or None)
        self.chd_lbl.config(text=("chdman found: " + exe) if exe else
                            "chdman NOT found - CHD conversion unavailable")

    def add(self):
        d = filedialog.askdirectory()
        if d and d not in self.srcs:
            self.srcs.append(d)
            self.lb.insert("end", d)

    def rem(self):
        for i in reversed(self.lb.curselection()):
            self.lb.delete(i)
            del self.srcs[i]

    def pick_out(self):
        d = filedialog.askdirectory()
        if d:
            self.out.set(d)

    def pick_chd(self):
        d = filedialog.askopenfilename(title="Select chdman")
        if d:
            self.chd.set(d)

    def log(self, m):
        self.q.put(m)

    def poll(self):
        try:
            while True:
                m = self.q.get_nowait()
                if isinstance(m, tuple):
                    if m[0] == "item":
                        self.status.config(text="Disc %d of %d" % (m[1], m[2]))
                        self.bar["value"] = 0
                    elif m[0] == "pct":
                        self.bar["value"] = m[1]
                    elif m[0] == "progress":
                        mm = re.search(r"(\d+(?:\.\d+)?)%", m[1])
                        if mm:
                            self.bar["value"] = float(mm.group(1))
                    elif m[0] == "end":
                        self.go.config(state="normal")
                        self.stop.config(state="disabled")
                else:
                    self.txt.insert("end", m + "\n")
                    self.txt.see("end")
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def start(self):
        if not self.srcs:
            messagebox.showinfo(APP, "Add at least one folder first.")
            return
        o = Options(sources=list(self.srcs), out_dir=self.out.get().strip(),
                    chdman=self.chd.get().strip() or None,
                    **{k: x.get() for k, x in self.v.items()})
        if o.delete_source and not o.dry_run:
            if not messagebox.askyesno(APP, "Source files will be deleted after each "
                                       "verified conversion. Continue?"):
                return
        self.go.config(state="disabled")
        self.stop.config(state="normal")
        self.txt.delete("1.0", "end")
        self.worker = threading.Thread(target=self.work, args=(o,), daemon=True)
        self.worker.start()

    def work(self, o):
        try:
            r = run_job(o, self.log, self.q.put)
            finish(o, r, self.log)
        except ConvError as ex:
            self.log("ERROR: %s" % ex)
        except Exception as ex:  # noqa
            self.log("ERROR: %s: %s" % (type(ex).__name__, ex))
        self.q.put(("end",))

    def cancel(self):
        CANCEL.set()
        p = _PROC.get("p")
        if p:
            try:
                p.terminate()
            except Exception:
                pass


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="PBP -> BIN/CUE -> CHD converter with "
                                 "multi-disc M3U support (%s)" % CREDIT)
    ap.add_argument("sources", nargs="*", help="folders (or files) to scan")
    ap.add_argument("-o", "--out", default="", help="output folder (default: beside sources)")
    ap.add_argument("--pbp", action="store_true", help="convert PBP -> BIN/CUE")
    ap.add_argument("--chd", action="store_true", help="convert BIN/CUE -> CHD")
    ap.add_argument("--keep-bincue", action="store_true")
    ap.add_argument("--delete-source", action="store_true")
    ap.add_argument("--no-verify", action="store_true")
    ap.add_argument("--no-m3u", action="store_true")
    ap.add_argument("--m3u-all", action="store_true")
    ap.add_argument("--no-folder", action="store_true", help="don't make folders for multi-disc games")
    ap.add_argument("--no-existing-chd", action="store_true")
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--no-report", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--chdman", help="path to chdman")
    ap.add_argument("--gui", action="store_true")
    a = ap.parse_args(argv)

    if (a.gui or not a.sources) and tk is not None:
        try:
            root = tk.Tk()
        except Exception as ex:
            print("No display available (%s); use the command line." % ex)
            return 2
        App(root)
        root.mainloop()
        return 0
    if not a.sources:
        ap.print_help()
        return 2
    both = not (a.pbp or a.chd)
    o = Options(sources=a.sources, out_dir=a.out, do_pbp=a.pbp or both,
                do_chd=a.chd or both, keep_bincue=a.keep_bincue,
                delete_source=a.delete_source, verify=not a.no_verify,
                multidisc_m3u=not a.no_m3u, m3u_all=a.m3u_all,
                group_folder=not a.no_folder, include_chd=not a.no_existing_chd,
                overwrite=a.overwrite, write_csv=not a.no_report,
                dry_run=a.dry_run, chdman=a.chdman)
    try:
        r = run_job(o, print)
    except ConvError as ex:
        print("ERROR:", ex)
        return 1
    finish(o, r, print)
    return 1 if any(x["status"] == "error" for x in r) else 0


if __name__ == "__main__":
    sys.exit(main())
