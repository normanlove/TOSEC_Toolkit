@echo off
rem TOSEC Toolkit installer - created by normanlove
rem Keep this file in the same folder as the .py scripts and tosec_toolkit.pyw.
set "SELF=%~f0"
set "SRC=%~dp0"
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$s=[IO.File]::ReadAllText($env:SELF); $i=$s.IndexOf('#PS'+'#START'); & ([scriptblock]::Create($s.Substring($i))) $env:SRC"
exit /b
#PS#START
param([string]$Src)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$PyVer    = '3.12.10'
$Files    = @('tosec_sorter.py','rom_archiver.py','rom_scraper.py','rom_converter.py','tosec_toolkit.pyw','tosec_toolkit.ico','TOSEC_Toolkit_README.txt')
$DefDir   = Join-Path $env:LOCALAPPDATA 'TOSEC Toolkit'
$Src      = $Src.TrimEnd('\')
$UninstKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TOSECToolkit'

# ---------- UI ----------
$form = New-Object Windows.Forms.Form
$form.Text = 'TOSEC Toolkit Setup  -  created by normanlove'
$form.Size = New-Object Drawing.Size(620,520)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object Drawing.Font('Segoe UI',9)

function Add-Ctl($c,$x,$y,$w,$h){ $c.Location=New-Object Drawing.Point($x,$y); $c.Size=New-Object Drawing.Size($w,$h); $form.Controls.Add($c); $c }

$t = New-Object Windows.Forms.Label; $t.Text='TOSEC Toolkit'; $t.Font=New-Object Drawing.Font('Segoe UI',16,[Drawing.FontStyle]::Bold)
Add-Ctl $t 16 12 560 32 | Out-Null
$d = New-Object Windows.Forms.Label
$d.Text="Installs a private copy of Python $PyVer (with Tk) just for these tools - it does not change your system Python - plus the four tools and a launcher with shortcuts."
Add-Ctl $d 16 48 570 40 | Out-Null

$l1 = New-Object Windows.Forms.Label; $l1.Text='Install folder:'
Add-Ctl $l1 16 98 200 18 | Out-Null
$tbDir = New-Object Windows.Forms.TextBox; $tbDir.Text=$DefDir
Add-Ctl $tbDir 16 118 480 24 | Out-Null
$bBrowse = New-Object Windows.Forms.Button; $bBrowse.Text='Browse...'
Add-Ctl $bBrowse 504 116 84 27 | Out-Null
$bBrowse.Add_Click({ $fb=New-Object Windows.Forms.FolderBrowserDialog; if($fb.ShowDialog() -eq 'OK'){ $tbDir.Text=(Join-Path $fb.SelectedPath 'TOSEC Toolkit') } })

$cbDesk = New-Object Windows.Forms.CheckBox; $cbDesk.Text='Desktop shortcut'; $cbDesk.Checked=$true
Add-Ctl $cbDesk 16 152 200 22 | Out-Null
$cbMenu = New-Object Windows.Forms.CheckBox; $cbMenu.Text='Start menu shortcut'; $cbMenu.Checked=$true
Add-Ctl $cbMenu 220 152 200 22 | Out-Null
$cbRun = New-Object Windows.Forms.CheckBox; $cbRun.Text='Launch TOSEC Toolkit when finished'; $cbRun.Checked=$true
Add-Ctl $cbRun 16 176 280 22 | Out-Null
$cbRead = New-Object Windows.Forms.CheckBox; $cbRead.Text='Open the README when finished'; $cbRead.Checked=$true
Add-Ctl $cbRead 300 176 280 22 | Out-Null

$bar = New-Object Windows.Forms.ProgressBar; $bar.Minimum=0; $bar.Maximum=100
Add-Ctl $bar 16 208 572 20 | Out-Null
$log = New-Object Windows.Forms.TextBox; $log.Multiline=$true; $log.ReadOnly=$true; $log.ScrollBars='Vertical'
Add-Ctl $log 16 236 572 190 | Out-Null
$bGo = New-Object Windows.Forms.Button; $bGo.Text='Install'
Add-Ctl $bGo 396 440 90 30 | Out-Null
$bClose = New-Object Windows.Forms.Button; $bClose.Text='Close'
Add-Ctl $bClose 498 440 90 30 | Out-Null
$bFolder = New-Object Windows.Forms.Button; $bFolder.Text='Open install folder'; $bFolder.Enabled=$false
Add-Ctl $bFolder 16 440 140 30 | Out-Null
$bClose.Add_Click({ $form.Close() })

function Say($m){ $log.AppendText($m + "`r`n"); [Windows.Forms.Application]::DoEvents() }
function Pump(){ [Windows.Forms.Application]::DoEvents() }

function Download($url,$dest){
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $req = [Net.HttpWebRequest]::Create($url)
    $resp = $req.GetResponse()
    $len = $resp.ContentLength
    $in = $resp.GetResponseStream()
    $out = [IO.File]::Create($dest)
    $buf = New-Object byte[] 81920
    $got = 0
    while(($n = $in.Read($buf,0,$buf.Length)) -gt 0){
        $out.Write($buf,0,$n); $got += $n
        if($len -gt 0){ $bar.Value = [int](100*$got/$len) }
        Pump
    }
    $out.Close(); $in.Close(); $resp.Close()
}

function MkLink($path,$target,$arguments,$wd,$icon){
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($path)
    $s.TargetPath = $target; $s.Arguments = $arguments; $s.WorkingDirectory = $wd
    $s.Description = 'TOSEC Toolkit - created by normanlove'
    $s.IconLocation = $icon
    $s.Save()
}

function Do-Install(){
    $dir = $tbDir.Text.Trim().TrimEnd('\')
    if(-not $dir){ throw 'Choose an install folder.' }
    if(-not (Test-Path (Join-Path $Src 'tosec_toolkit.pyw'))){
        throw "tosec_toolkit.pyw was not found next to this installer ($Src). Keep all the files together."
    }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $py   = Join-Path $dir 'python'
    $setup= Join-Path $dir 'setup'
    New-Item -ItemType Directory -Force -Path $setup | Out-Null
    $pyexe = Join-Path $py 'python.exe'
    $pywexe = Join-Path $py 'pythonw.exe'

    # --- Python ---
    $haveTk = $false
    if(Test-Path $pyexe){
        $p = Start-Process $pyexe -ArgumentList '-c','"import tkinter"' -WindowStyle Hidden -Wait -PassThru
        $haveTk = ($p.ExitCode -eq 0)
    }
    if($haveTk){
        Say 'Python is already installed in the install folder - skipping.'
    } else {
        $arch = if($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64'){ 'arm64' } else { 'amd64' }
        $name = "python-$PyVer-$arch.exe"
        $inst = Join-Path $setup 'python-installer.exe'
        $local = Join-Path $Src $name
        if(Test-Path $local){
            Say "Using $name found next to the installer (offline mode)."
            Copy-Item $local $inst -Force
        } else {
            Say "Downloading Python $PyVer ($arch) from python.org ..."
            Download "https://www.python.org/ftp/python/$PyVer/$name" $inst
        }
        $bar.Value = 0
        Say 'Checking the download is signed by the Python Software Foundation ...'
        $sig = Get-AuthenticodeSignature $inst
        if($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation'){
            Remove-Item $inst -Force
            throw 'The Python installer signature could not be verified. Aborting.'
        }
        Say 'Installing Python (this takes a minute or two) ...'
        $bar.Style = 'Marquee'
        $pyArgs = @('/quiet','InstallAllUsers=0','PrependPath=0','Include_launcher=0','Include_test=0',
                  'Include_doc=0','Include_pip=1','Include_tcltk=1','Shortcuts=0','AssociateFiles=0',
                  "TargetDir=`"$py`"")
        $proc = Start-Process $inst -ArgumentList $pyArgs -PassThru
        while(-not $proc.HasExited){ Pump; Start-Sleep -Milliseconds 100 }
        $bar.Style = 'Blocks'
        if(($proc.ExitCode -ne 0 -and $proc.ExitCode -ne 3010) -or -not (Test-Path $pywexe)){
            throw "Python setup failed (exit code $($proc.ExitCode))."
        }
        $p = Start-Process $pyexe -ArgumentList '-c','"import tkinter"' -WindowStyle Hidden -Wait -PassThru
        if($p.ExitCode -ne 0){ throw 'Python installed, but Tk is missing.' }
        Say 'Python installed.'
    }
    $bar.Value = 60

    # --- tools ---
    foreach($f in $Files){
        $s = Join-Path $Src $f
        if(Test-Path $s){ Copy-Item $s (Join-Path $dir $f) -Force; Say "Installed $f" }
        else { Say "WARNING: $f not found next to the installer - skipped." }
    }
    New-Item -ItemType Directory -Force -Path (Join-Path $dir 'logs') | Out-Null
    $bar.Value = 80

    # --- shortcuts ---
    $launcher = Join-Path $dir 'tosec_toolkit.pyw'
    $ico = Join-Path $dir 'tosec_toolkit.ico'
    $iconLoc = if(Test-Path $ico){ $ico } else { "$pywexe,0" }
    $lnkDesk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'TOSEC Toolkit.lnk'
    $menuDir = Join-Path ([Environment]::GetFolderPath('Programs')) 'TOSEC Toolkit'
    $lnkMenu = Join-Path $menuDir 'TOSEC Toolkit.lnk'
    $lnkUn   = Join-Path $menuDir 'Uninstall TOSEC Toolkit.lnk'
    if($cbDesk.Checked){ MkLink $lnkDesk $pywexe "`"$launcher`"" $dir $iconLoc; Say 'Desktop shortcut created.' }
    if($cbMenu.Checked){
        New-Item -ItemType Directory -Force -Path $menuDir | Out-Null
        MkLink $lnkMenu $pywexe "`"$launcher`"" $dir $iconLoc
        $readme = Join-Path $dir 'TOSEC_Toolkit_README.txt'
        if(Test-Path $readme){ MkLink (Join-Path $menuDir 'Read me.lnk') $readme '' $dir "$env:SystemRoot\System32\shell32.dll,1" }
        MkLink $lnkUn (Join-Path $env:SystemRoot 'System32\cmd.exe') "/c `"`"$dir\uninstall.cmd`"`"" $dir "$env:SystemRoot\System32\shell32.dll,131"
        Say 'Start menu shortcuts created (TOSEC Toolkit, Read me, Uninstall).'
    }

    # --- uninstaller ---
    $un = @"
@echo off
rem TOSEC Toolkit uninstaller - created by normanlove
set "D=%~dp0"
set "D=%D:~0,-1%"
echo This removes TOSEC Toolkit, its private Python and any files in:
echo   %D%
echo (including chdman.exe if you put it there).
choice /m "Continue"
if errorlevel 2 exit /b
"%D%\setup\python-installer.exe" /uninstall /quiet >nul 2>&1
del "$lnkDesk" >nul 2>&1
rd /s /q "$menuDir" >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\TOSECToolkit" /f >nul 2>&1
cd /d "%TEMP%"
start "" /min cmd /c ping -n 4 127.0.0.1 ^>nul ^& rd /s /q "%D%"
"@
    Set-Content -Path (Join-Path $dir 'uninstall.cmd') -Value $un -Encoding ASCII

    New-Item -Path $UninstKey -Force | Out-Null
    Set-ItemProperty $UninstKey DisplayName 'TOSEC Toolkit'
    Set-ItemProperty $UninstKey Publisher 'normanlove'
    Set-ItemProperty $UninstKey DisplayIcon $iconLoc
    Set-ItemProperty $UninstKey InstallLocation $dir
    Set-ItemProperty $UninstKey UninstallString ("cmd.exe /c `"" + (Join-Path $dir 'uninstall.cmd') + "`"")
    Set-ItemProperty $UninstKey NoModify 1
    $bar.Value = 100

    Say ''
    Say 'Done.'
    Say 'To enable CHD conversion, copy chdman.exe into the install folder:'
    Say "  $dir"
    $script:InstDir = $dir
    $script:Pywexe = $pywexe
    $script:Launcher = $launcher
    $script:Readme = Join-Path $dir 'TOSEC_Toolkit_README.txt'
}

$script:InstDir = ''
$bGo.Add_Click({
    $bGo.Enabled = $false; $bBrowse.Enabled = $false; $tbDir.Enabled = $false
    try {
        Do-Install
        $bFolder.Enabled = $true
        $bGo.Text = 'Installed'
        if($cbRead.Checked -and (Test-Path $script:Readme)){ Start-Process $script:Readme }
        if($cbRun.Checked){ Start-Process $script:Pywexe -ArgumentList "`"$($script:Launcher)`"" -WorkingDirectory $script:InstDir }
    } catch {
        Say ('ERROR: ' + $_.Exception.Message)
        $bGo.Enabled = $true; $bBrowse.Enabled = $true; $tbDir.Enabled = $true
        $bar.Style = 'Blocks'
    }
})
$bFolder.Add_Click({ if($script:InstDir){ Start-Process explorer.exe $script:InstDir } })

[void]$form.ShowDialog()
