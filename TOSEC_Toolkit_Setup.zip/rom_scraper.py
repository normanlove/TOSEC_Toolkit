#!/usr/bin/env python3
"""
ROM Scraper
===========
Created by normanlove.

Looks up every game in the folders you choose on the online scraper services, then
saves descriptions, release dates, box art, screenshots and more next to your ROMs
in a format your frontend understands (Batocera / EmulationStation / RetroPie /
Recalbox gamelist.xml, ES-DE downloaded_media, or a plain JSON file).

Services (tick any number, drag them into priority order - the first one that has
a field or picture wins, later ones only fill the gaps):

    ScreenScraper    login needed   hash + name lookup, best coverage for retro systems
    TheGamesDB       API key        free key from thegamesdb.net
    IGDB             Twitch login   free client id / secret from dev.twitch.tv
    MobyGames        API key        key from mobygames.com
    RAWG             API key        free key from rawg.io
    Libretro         no login       box art / screenshots / titles from thumbnails.libretro.com
    LaunchBox        no login       LaunchBox Games Database (downloads its metadata file once)

If a service you selected needs a login or key, the program asks for it before
scraping starts, tests it, and (only if you tick the box) remembers it in
rom_scraper_credentials.json next to the script. Nothing is ever deleted or moved:
ROMs are never touched. Resumable - games already scraped are skipped next time.

Speed control: watch the live download speed, set a limit (it changes mid-run), and set a
time-of-day schedule (e.g. full speed overnight, 300 KB/s by day, or pause at certain
hours). Pause and Resume at any time - progress is saved the moment you pause.
The output layout is detected from your folders (Batocera, RetroPie, Recalbox, ES-DE...).

Needs only Python 3.8+ (Tkinter for the window). Command line (no window):
  python rom_scraper.py --list-services
  python rom_scraper.py --folders "English ROMs" --services libretro,launchbox
  python rom_scraper.py --folders "English ROMs" --services screenscraper,thegamesdb --format emulationstation
  python rom_scraper.py --services libretro --limit 500 --schedule 00:00-07:00=full --schedule 07:00-24:00=300
  (Ctrl+C in the terminal pauses; Enter resumes, s stops)
"""

import argparse
import copy
import csv
import datetime
import getpass
import hashlib
import json
import os
import queue
import re
import shutil
import sys
import threading
import time
import traceback
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
import zlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from difflib import SequenceMatcher
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
except ImportError:  # the engine and command line work without a GUI
    tk = None

__author__ = "normanlove"

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #

if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent

SETTINGS = APP_DIR / "rom_scraper_settings.json"
CREDENTIALS = APP_DIR / "rom_scraper_credentials.json"
MANIFEST = APP_DIR / "rom_scraper_data.json"
SOFTNAME = "RomScraper"
USER_AGENT = "RomScraper/1.0 (created by normanlove)"

JUNK_EXT = {
    ".txt", ".nfo", ".dat", ".xml", ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp",
    ".htm", ".html", ".url", ".diz", ".py", ".pyw", ".pyc", ".exe", ".log", ".csv",
    ".ini", ".db", ".json", ".pdf", ".sfv", ".md5", ".sha1", ".mp4", ".avi", ".mkv",
    ".part", ".bak", ".cfg", ".srm", ".sav", ".state", ".mp3", ".ogg", ".wav",
}
def sorter_rom_folder():
    """The 'English ROMs' folder of the ROM folder last used in the sorter, if there is one."""
    try:
        d = json.loads((APP_DIR / "tosec_sorter_settings.json").read_text(encoding="utf-8"))
        root = d.get("root") or ""
        if root and Path(root).is_dir():
            eng = Path(root) / (d.get("eng_dir") or "English ROMs")
            return str(eng if eng.is_dir() else root)
    except (OSError, ValueError, AttributeError):
        pass
    return ""


MEDIA_DIRS = {"images", "videos", "media", "downloaded_media", "manuals", "snaps", "boxart",
              "covers", "screenshots", "titlescreens", "marquees", "gamelists",
              "rom_scraper_media", "es-de", "__pycache__"}
REASON_DIRS = {"other languages", "duplicates", "hacks and modified", "bad dumps",
               "alternates", "pre-release", "demos"}
ALPHA_DIR_RE = re.compile(r"^(0-9|#|[A-Z](-[A-Z])?)$")

# What can be saved. (key, label)
FIELDS = [
    ("desc", "Description"), ("year", "Release date"), ("developer", "Developer"),
    ("publisher", "Publisher"), ("genre", "Genre"), ("players", "Players"), ("rating", "Rating"),
]
MEDIA = [
    ("boxart", "Box art"), ("screenshot", "Screenshot"), ("titlescreen", "Title screen"),
    ("logo", "Logo / marquee"), ("video", "Video (large files)"),
]
FORMATS = {
    "auto": "Detect from my folders (recommended) - Batocera, RetroPie, Recalbox, ES-DE...",
    "emulationstation": "Batocera / EmulationStation / RetroPie: gamelist.xml + images and videos folders",
    "recalbox": "Recalbox: gamelist.xml + media/images, media/thumbnails, media/videos",
    "esde": "ES-DE: downloaded_media folders + gamelists folder",
    "json": "Just rom_scraper_data.json and a rom_scraper_media folder (e.g. for MiSTer)",
}

# --------------------------------------------------------------------------- #
# Systems (same table the TOSEC sorter uses, so its folders are recognised)
# --------------------------------------------------------------------------- #

# >>> SYSTEMS TABLE >>>
SYSTEM_RULES = [
    ("camplynx", "Camputers Lynx", r"camputers"),
    ("amiga_cd32", "Commodore Amiga CD32", r"cd32"),
    ("amiga_cdtv", "Commodore CDTV", r"cdtv"),
    ("amiga", "Commodore Amiga", r"amiga"),
    ("c128", "Commodore 128", r"commodore 128|\bc128\b"),
    ("c64", "Commodore 64", r"commodore 64|\bc64\b"),
    ("vic20", "Commodore VIC-20", r"vic-?20"),
    ("plus4", "Commodore 16/116/Plus-4", r"plus-?4|commodore 16\b|commodore 116\b|\bc16\b"),
    ("pet", "Commodore PET", r"commodore pet|\bpet\b"),
    ("atari2600", "Atari 2600", r"2600"),
    ("atari5200", "Atari 5200", r"5200"),
    ("atari7800", "Atari 7800", r"7800"),
    ("jaguar", "Atari Jaguar", r"jaguar"),
    ("lynx", "Atari Lynx", r"atari lynx"),
    ("xegs", "Atari XEGS", r"xegs"),
    ("atari800", "Atari 8-bit", r"atari (8-?bit|800|400|xl|xe)"),
    ("atarist", "Atari ST / Falcon", r"atari (st|falcon|tt)"),
    ("zx81", "Sinclair ZX81/ZX80", r"zx ?(81|80)"),
    ("zxspectrum", "Sinclair ZX Spectrum", r"spectrum"),
    ("ql", "Sinclair QL", r"sinclair ql"),
    ("gx4000", "Amstrad GX4000", r"gx4000"),
    ("pcw", "Amstrad PCW", r"pcw"),
    ("amstradcpc", "Amstrad CPC", r"amstrad cpc|\bcpc\b"),
    ("msx2plus", "MSX2+", r"msx2\+|msx2plus"),
    ("msxturbor", "MSX turboR", r"turbo ?r"),
    ("msx2", "MSX2", r"msx2"),
    ("msx1", "MSX", r"msx"),
    ("apple2gs", "Apple IIGS", r"iigs|2gs"),
    ("apple2", "Apple II", r"apple ii"),
    ("macintosh", "Apple Macintosh", r"macintosh"),
    ("archimedes", "Acorn Archimedes", r"archimedes"),
    ("bbcmicro", "Acorn BBC Micro", r"\bbbc\b"),
    ("electron", "Acorn Electron", r"electron"),
    ("atom", "Acorn Atom", r"acorn atom"),
    ("adam", "Coleco Adam", r"coleco adam"),
    ("colecovision", "ColecoVision", r"coleco"),
    ("intellivision", "Mattel Intellivision", r"intellivision"),
    ("vectrex", "GCE Vectrex", r"vectrex"),
    ("channelf", "Fairchild Channel F", r"channel f"),
    ("odyssey2", "Magnavox Odyssey 2 / Videopac", r"odyssey|videopac"),
    ("astrocade", "Bally Astrocade", r"astrocade"),
    ("arcadia", "Emerson Arcadia 2001", r"arcadia"),
    ("fds", "Famicom Disk System", r"famicom disk|\bfds\b"),
    ("snes", "Super Nintendo / Super Famicom", r"super (nintendo|famicom|nes)|snes"),
    ("nes", "Nintendo NES / Famicom", r"entertainment system|famicom|\bnes\b"),
    ("n64", "Nintendo 64", r"nintendo 64|\bn64\b"),
    ("gba", "Game Boy Advance", r"advance"),
    ("gbc", "Game Boy Color", r"game ?boy color"),
    ("gb", "Game Boy", r"game ?boy"),
    ("gamegear", "Sega Game Gear", r"game gear"),
    ("mastersystem", "Sega Master System", r"master system"),
    ("segacd", "Sega Mega CD / Sega CD", r"mega cd|sega cd"),
    ("sega32x", "Sega 32X", r"32x"),
    ("sg1000", "Sega SG-1000", r"sg-?1000"),
    ("megadrive", "Sega Mega Drive / Genesis", r"mega ?drive|genesis"),
    ("saturn", "Sega Saturn", r"saturn"),
    ("dreamcast", "Sega Dreamcast", r"dreamcast"),
    ("pcenginecd", "PC Engine CD", r"(pc engine|turbo ?grafx).*cd"),
    ("pcengine", "PC Engine / TurboGrafx-16", r"pc engine|turbo ?grafx|supergrafx"),
    ("neogeocd", "Neo Geo CD", r"neo ?geo cd"),
    ("ngpc", "Neo Geo Pocket Color", r"pocket color"),
    ("ngp", "Neo Geo Pocket", r"neo ?geo pocket"),
    ("neogeo", "Neo Geo", r"neo ?geo"),
    ("wswanc", "WonderSwan Color", r"wonderswan color"),
    ("wswan", "WonderSwan", r"wonderswan"),
    ("ps2", "Sony PlayStation 2", r"playstation 2"),
    ("psx", "Sony PlayStation", r"playstation"),
    ("3do", "3DO", r"\b3do\b"),
    ("cdi", "Philips CD-i", r"\bcd-?i\b"),
    ("coco", "Tandy Color Computer", r"color computer|coco|trs-?80 color"),
    ("trs80", "Tandy TRS-80", r"trs-?80"),
    ("ti99", "Texas Instruments TI-99", r"ti-?99"),
    ("thomson", "Thomson MO/TO", r"thomson"),
    ("oric", "Oric", r"oric"),
    ("dragon", "Dragon 32/64", r"dragon"),
    ("samcoupe", "SAM Coupe", r"sam coup|mgt sam"),
    ("x68000", "Sharp X68000", r"x68000"),
    ("pc88", "NEC PC-8801", r"pc-?88"),
    ("pc98", "NEC PC-9801", r"pc-?98"),
    ("fm7", "Fujitsu FM-7", r"fm-?7"),
    ("fmtowns", "Fujitsu FM Towns", r"fm towns"),
    ("enterprise", "Enterprise", r"enterprise"),
]
_RULES = [(c, re.compile(rx, re.I)) for c, _l, rx in SYSTEM_RULES]


def canonical_system(name):
    low = name.lower()
    for canon, rx in _RULES:
        if rx.search(low):
            return canon
    return None


def _table(text):
    return {k.strip(): v.strip() for k, v in
            (p.split("=", 1) for p in text.replace("\n", ";").split(";") if "=" in p)}


# Batocera: folder names checked against the Batocera wiki system list.
BATOCERA = _table("""
amiga=amiga500; amiga_cd32=amigacd32; amiga_cdtv=amigacdtv; c64=c64; c128=c128; vic20=c20;
plus4=cplus4; pet=pet; atari2600=atari2600; atari5200=atari5200; atari7800=atari7800;
jaguar=jaguar; lynx=lynx; atari800=atari800; xegs=xegs; atarist=atarist;
zxspectrum=zxspectrum; zx81=zx81; amstradcpc=amstradcpc; gx4000=gx4000; pcw=pcw;
msx1=msx1; msx2=msx2; msx2plus=msx2+; msxturbor=msxturbor; apple2=apple2; apple2gs=apple2gs;
macintosh=macintosh; archimedes=archimedes; bbcmicro=bbcmicro; electron=electron; atom=atom;
colecovision=colecovision; adam=adam; intellivision=intellivision; vectrex=vectrex;
channelf=channelf; odyssey2=odyssey2; astrocade=astrocade; arcadia=arcadia; nes=nes; fds=fds;
snes=snes; n64=n64; gb=gb; gbc=gbc; gba=gba; mastersystem=mastersystem; gamegear=gamegear;
megadrive=megadrive; segacd=megacd; sega32x=sega32x; sg1000=sg1000; saturn=saturn;
dreamcast=dreamcast; pcengine=pcengine; pcenginecd=pcenginecd; neogeo=neogeo;
neogeocd=neogeocd; ngp=ngp; ngpc=ngpc; wswan=wswan; wswanc=wswanc; psx=psx; ps2=ps2;
3do=3do; cdi=cdi; trs80=trs80; coco=coco; ti99=ti99; thomson=thomson; oric=oricatmos;
dragon=dragon64; samcoupe=samcoupe; x68000=x68000; pc88=pc88; pc98=pc98; fm7=fm7;
fmtowns=fmtowns; camplynx=camplynx; enterprise=enterprise
""")

# MiSTer: the /media/fat/games/<folder> names (case-insensitive on the device).
MISTER = _table("""
amiga=Amiga; amiga_cd32=Amiga; amiga_cdtv=Amiga; c64=C64; c128=C128; vic20=VIC20; plus4=C16;
pet=PET2001; atari2600=ATARI2600; atari5200=ATARI5200; atari7800=ATARI7800; lynx=AtariLynx;
atari800=ATARI800; atarist=AtariST; zxspectrum=Spectrum; zx81=ZX81; ql=QL;
amstradcpc=Amstrad; pcw=Amstrad PCW; msx1=MSX; msx2=MSX; msx2plus=MSX; msxturbor=MSX;
apple2=Apple-II; macintosh=MACPLUS; archimedes=ARCHIE; bbcmicro=BBCMicro;
electron=AcornElectron; atom=AcornAtom; colecovision=Coleco; intellivision=Intellivision;
vectrex=VECTREX; channelf=ChannelF; odyssey2=ODYSSEY2; astrocade=Astrocade; arcadia=Arcadia;
nes=NES; fds=NES; snes=SNES; n64=N64; gb=GAMEBOY; gbc=GAMEBOY; gba=GBA; mastersystem=SMS;
gamegear=SMS; megadrive=Genesis; segacd=MegaCD; sega32x=S32X; sg1000=SG1000; saturn=Saturn;
pcengine=TGFX16; pcenginecd=TGFX16-CD; neogeo=NeoGeo; neogeocd=NeoGeo; wswan=WonderSwan;
wswanc=WonderSwan; psx=PSX; cdi=CD-i; trs80=TRS-80; ti99=TI-99_4A; oric=Oric;
samcoupe=SAMCOUPE; x68000=X68000; pc88=PC8801
""")

# RetroPie: /home/pi/RetroPie/roms/<folder>
RETROPIE = _table("""
amiga=amiga; amiga_cd32=amiga; amiga_cdtv=amiga; c64=c64; c128=c128; vic20=vic20; plus4=plus4;
pet=pet; atari2600=atari2600; atari5200=atari5200; atari7800=atari7800; jaguar=atarijaguar;
lynx=atarilynx; atari800=atari800; xegs=atari800; atarist=atarist; zxspectrum=zxspectrum;
zx81=zx81; amstradcpc=amstradcpc; msx1=msx; msx2=msx; msx2plus=msx; msxturbor=msx;
apple2=apple2; macintosh=macintosh; bbcmicro=bbcmicro; colecovision=coleco;
intellivision=intellivision; vectrex=vectrex; channelf=channelf; odyssey2=videopac;
astrocade=astrocade; nes=nes; fds=fds; snes=snes; n64=n64; gb=gb; gbc=gbc; gba=gba;
mastersystem=mastersystem; gamegear=gamegear; megadrive=megadrive; segacd=segacd;
sega32x=sega32x; sg1000=sg-1000; saturn=saturn; dreamcast=dreamcast; pcengine=pcengine;
pcenginecd=pcenginecd; neogeo=neogeo; ngp=ngp; ngpc=ngpc; wswan=wonderswan;
wswanc=wonderswancolor; psx=psx; 3do=3do; trs80=trs-80; coco=coco; ti99=ti99; oric=oric;
dragon=dragon32; x68000=x68000
""")

# ES-DE (EmulationStation Desktop Edition) ROM folder names.
ESDE = _table("""
amiga=amiga; amiga_cd32=amigacd32; amiga_cdtv=cdtv; c64=c64; c128=c128; vic20=vic20;
atari2600=atari2600; atari5200=atari5200; atari7800=atari7800; jaguar=atarijaguar;
lynx=atarilynx; atari800=atari800; xegs=atarixe; atarist=atarist; zxspectrum=zxspectrum;
zx81=zx81; amstradcpc=amstradcpc; gx4000=gx4000; msx1=msx; msx2=msx2; msx2plus=msx2;
msxturbor=msxturbor; apple2=apple2; apple2gs=apple2gs; macintosh=macintosh;
archimedes=archimedes; bbcmicro=bbcmicro; electron=electron; colecovision=colecovision;
intellivision=intellivision; vectrex=vectrex; channelf=channelf; odyssey2=videopac;
astrocade=astrocade; arcadia=arcadia; nes=nes; fds=fds; snes=snes; n64=n64; gb=gb; gbc=gbc;
gba=gba; mastersystem=mastersystem; gamegear=gamegear; megadrive=megadrive; segacd=segacd;
sega32x=sega32x; sg1000=sg-1000; saturn=saturn; dreamcast=dreamcast; pcengine=pcengine;
pcenginecd=pcenginecd; neogeo=neogeo; neogeocd=neogeocd; ngp=ngp; ngpc=ngpc;
wswan=wonderswan; wswanc=wonderswancolor; psx=psx; ps2=ps2; 3do=3do; cdi=cdimono1;
trs80=trs-80; coco=coco; ti99=ti99; oric=oric; dragon=dragon32; samcoupe=samcoupe;
x68000=x68000; pc88=pc88; pc98=pc98; fm7=fm7; fmtowns=fmtowns
""")

# Recalbox (best effort - use the mapping file to correct anything you need).
RECALBOX = _table("""
amiga=amiga600; amiga_cd32=amigacd32; c64=c64; vic20=vic20; atari2600=atari2600;
atari5200=atari5200; atari7800=atari7800; jaguar=jaguar; lynx=lynx; atari800=atari800;
atarist=atarist; zxspectrum=zxspectrum; zx81=zx81; amstradcpc=amstradcpc; gx4000=amstradgx4000;
msx1=msx1; msx2=msx2; msxturbor=msxturbor; apple2=apple2; apple2gs=apple2gs;
colecovision=colecovision; intellivision=intellivision; vectrex=vectrex; channelf=channelf;
odyssey2=o2em; nes=nes; fds=fds; snes=snes; n64=n64; gb=gb; gbc=gbc; gba=gba;
mastersystem=mastersystem; gamegear=gamegear; megadrive=megadrive; segacd=segacd;
sega32x=sega32x; sg1000=sg1000; saturn=saturn; dreamcast=dreamcast; pcengine=pcengine;
pcenginecd=pcenginecd; neogeo=neogeo; neogeocd=neogeocd; ngp=ngp; ngpc=ngpc; wswan=wswan;
wswanc=wswanc; psx=psx; 3do=3do; oric=oricatmos; samcoupe=samcoupe; x68000=x68000; pc88=pc88;
pc98=pc98
""")

TOSEC_LAYOUT = "TOSEC names"
CUSTOM_LAYOUT = "Custom"
LAYOUTS = {
    TOSEC_LAYOUT: {},
    "Batocera": BATOCERA,
    "MiSTer": MISTER,
    "RetroPie": RETROPIE,
    "ES-DE": ESDE,
    "Recalbox": RECALBOX,
    CUSTOM_LAYOUT: {},
}
LAYOUT_HINTS = {
    TOSEC_LAYOUT: "System folders keep their TOSEC names (e.g. Commodore Amiga).",
    "Batocera": "Copy the contents of the kept folder into /userdata/roms/ (the 'share/roms' network folder).",
    "MiSTer": "Copy the contents of the kept folder into /media/fat/games/ (the 'games' folder on the SD card).",
    "RetroPie": "Copy the contents of the kept folder into ~/RetroPie/roms/ (the 'roms' network share).",
    "ES-DE": "Copy the contents of the kept folder into your ES-DE ROMs directory.",
    "Recalbox": "Copy the contents of the kept folder into /recalbox/share/roms/. (Best-effort names - check them.)",
    CUSTOM_LAYOUT: "Folder names come entirely from tosec_sorter_systems.json (use 'Export mapping file' below).",
}

# Folder name -> canonical id, used to recognise already-sorted folders on re-runs.
REVERSE = {}
for _name, _tbl in LAYOUTS.items():
    for _canon, _folder in _tbl.items():
        REVERSE.setdefault(_folder.lower(), _canon)
# <<< SYSTEMS TABLE <<<

LABELS = {c: l for c, l, _ in SYSTEM_RULES}

# Other names the scraper sites use for the same machine. Used when matching a
# system to each site's own platform list.
ALIASES = {
    "amiga": ["Amiga", "Commodore Amiga", "Amiga 500"],
    "amiga_cd32": ["Amiga CD32", "Commodore CD32", "CD32"],
    "amiga_cdtv": ["Amiga CDTV", "Commodore CDTV", "CDTV"],
    "c64": ["Commodore 64", "C64"], "c128": ["Commodore 128", "C128"],
    "vic20": ["VIC-20", "Commodore VIC-20", "Vic 20"], "plus4": ["Commodore Plus/4", "Plus/4", "C16"],
    "pet": ["Commodore PET", "PET"],
    "atari2600": ["Atari 2600", "Atari VCS"], "atari5200": ["Atari 5200"], "atari7800": ["Atari 7800"],
    "jaguar": ["Atari Jaguar", "Jaguar"], "lynx": ["Atari Lynx", "Lynx"],
    "atari800": ["Atari 8-bit", "Atari 800", "Atari 400/800", "Atari 8 bit"], "xegs": ["Atari XEGS", "Atari 8-bit"],
    "atarist": ["Atari ST", "Atari ST/STE"],
    "zxspectrum": ["ZX Spectrum", "Sinclair ZX Spectrum", "Spectrum"], "zx81": ["ZX81", "Sinclair ZX81", "Sinclair ZX-81"],
    "ql": ["Sinclair QL", "QL"],
    "amstradcpc": ["Amstrad CPC", "CPC"], "gx4000": ["Amstrad GX4000", "GX4000"], "pcw": ["Amstrad PCW", "PCW"],
    "msx1": ["MSX", "Microsoft MSX"], "msx2": ["MSX2", "MSX 2"], "msx2plus": ["MSX2+", "MSX2 plus"],
    "msxturbor": ["MSX turbo R", "MSX Turbo-R"],
    "apple2": ["Apple II", "Apple 2"], "apple2gs": ["Apple IIGS", "Apple II GS"], "macintosh": ["Macintosh", "Mac OS", "Apple Macintosh", "Mac"],
    "archimedes": ["Acorn Archimedes", "Archimedes"], "bbcmicro": ["BBC Micro", "Acorn BBC Micro", "BBC Microcomputer"],
    "electron": ["Acorn Electron", "Electron"], "atom": ["Acorn Atom", "Atom"],
    "colecovision": ["ColecoVision", "Coleco"], "adam": ["Coleco Adam", "Adam"],
    "intellivision": ["Intellivision", "Mattel Intellivision"], "vectrex": ["Vectrex", "GCE Vectrex"],
    "channelf": ["Fairchild Channel F", "Channel F"], "odyssey2": ["Magnavox Odyssey 2", "Odyssey 2", "Videopac", "Philips Videopac"],
    "astrocade": ["Bally Astrocade", "Astrocade"], "arcadia": ["Emerson Arcadia 2001", "Arcadia 2001", "Arcadia"],
    "nes": ["Nintendo Entertainment System", "NES", "Famicom", "Nintendo NES"], "fds": ["Famicom Disk System", "Nintendo Famicom Disk System"],
    "snes": ["Super Nintendo Entertainment System", "SNES", "Super Famicom", "Super Nintendo"],
    "n64": ["Nintendo 64", "N64"], "gb": ["Game Boy", "Nintendo Game Boy", "GameBoy"],
    "gbc": ["Game Boy Color", "Nintendo Game Boy Color"], "gba": ["Game Boy Advance", "Nintendo Game Boy Advance"],
    "mastersystem": ["Sega Master System", "Master System", "Sega Mark III"], "gamegear": ["Sega Game Gear", "Game Gear"],
    "megadrive": ["Sega Mega Drive", "Sega Genesis", "Mega Drive", "Genesis", "Sega Mega Drive/Genesis"],
    "segacd": ["Sega CD", "Mega-CD", "Sega Mega-CD", "Mega CD"], "sega32x": ["Sega 32X", "32X"], "sg1000": ["Sega SG-1000", "SG-1000"],
    "saturn": ["Sega Saturn", "Saturn"], "dreamcast": ["Sega Dreamcast", "Dreamcast"],
    "pcengine": ["PC Engine", "TurboGrafx-16", "TurboGrafx 16", "NEC PC Engine"], "pcenginecd": ["PC Engine CD", "TurboGrafx-CD", "TurboGrafx CD"],
    "neogeo": ["Neo Geo", "Neo Geo AES", "SNK Neo Geo", "Neo Geo MVS"], "neogeocd": ["Neo Geo CD"],
    "ngp": ["Neo Geo Pocket", "NGP"], "ngpc": ["Neo Geo Pocket Color", "NGPC"],
    "wswan": ["WonderSwan", "Bandai WonderSwan"], "wswanc": ["WonderSwan Color", "Bandai WonderSwan Color"],
    "psx": ["PlayStation", "Sony PlayStation", "PSX", "PS1"], "ps2": ["PlayStation 2", "Sony PlayStation 2", "PS2"],
    "3do": ["3DO", "3DO Interactive Multiplayer", "Panasonic 3DO"], "cdi": ["Philips CD-i", "CD-i"],
    "coco": ["Tandy Color Computer", "TRS-80 Color Computer", "Color Computer"], "trs80": ["TRS-80", "Tandy TRS-80"],
    "ti99": ["TI-99/4A", "Texas Instruments TI-99/4A", "TI 99/4A"], "thomson": ["Thomson MO/TO", "Thomson MO5", "Thomson TO7", "Thomson"],
    "oric": ["Oric", "Oric Atmos", "Tangerine Oric"], "dragon": ["Dragon 32/64", "Dragon 32", "Dragon 64"],
    "samcoupe": ["SAM Coupe", "MGT SAM Coupe"], "x68000": ["Sharp X68000", "X68000"], "pc88": ["NEC PC-8801", "PC-88", "PC-8801"],
    "pc98": ["NEC PC-9801", "PC-98", "PC-9801"], "fm7": ["Fujitsu FM-7", "FM-7"], "fmtowns": ["FM Towns", "Fujitsu FM Towns"],
    "enterprise": ["Enterprise", "Enterprise 64/128"], "camplynx": ["Camputers Lynx", "Lynx 48/96"],
}

# Folder names on thumbnails.libretro.com (checked against the live listing at run time).
LIBRETRO_GUESS = {
    "amiga": "Commodore - Amiga", "amiga_cd32": "Commodore - CD32", "amiga_cdtv": "Commodore - CDTV",
    "c64": "Commodore - 64", "c128": "Commodore - 128", "vic20": "Commodore - VIC-20", "plus4": "Commodore - Plus-4",
    "pet": "Commodore - PET", "atari2600": "Atari - 2600", "atari5200": "Atari - 5200", "atari7800": "Atari - 7800",
    "jaguar": "Atari - Jaguar", "lynx": "Atari - Lynx", "atari800": "Atari - 8-bit", "atarist": "Atari - ST",
    "zxspectrum": "Sinclair - ZX Spectrum", "zx81": "Sinclair - ZX 81", "amstradcpc": "Amstrad - CPC",
    "gx4000": "Amstrad - GX4000", "msx1": "Microsoft - MSX", "msx2": "Microsoft - MSX2", "apple2": "Apple - II",
    "macintosh": "Apple - Macintosh", "bbcmicro": "Acorn - BBC Micro", "electron": "Acorn - Electron",
    "colecovision": "Coleco - ColecoVision", "intellivision": "Mattel - Intellivision", "vectrex": "GCE - Vectrex",
    "channelf": "Fairchild - Channel F", "odyssey2": "Magnavox - Odyssey2", "nes": "Nintendo - Nintendo Entertainment System",
    "fds": "Nintendo - Family Computer Disk System", "snes": "Nintendo - Super Nintendo Entertainment System",
    "n64": "Nintendo - Nintendo 64", "gb": "Nintendo - Game Boy", "gbc": "Nintendo - Game Boy Color",
    "gba": "Nintendo - Game Boy Advance", "mastersystem": "Sega - Master System - Mark III", "gamegear": "Sega - Game Gear",
    "megadrive": "Sega - Mega Drive - Genesis", "segacd": "Sega - Mega-CD - Sega CD", "sega32x": "Sega - 32X",
    "sg1000": "Sega - SG-1000", "saturn": "Sega - Saturn", "dreamcast": "Sega - Dreamcast",
    "pcengine": "NEC - PC Engine - TurboGrafx 16", "pcenginecd": "NEC - PC Engine CD - TurboGrafx-CD",
    "neogeo": "SNK - Neo Geo", "neogeocd": "SNK - Neo Geo CD", "ngp": "SNK - Neo Geo Pocket",
    "ngpc": "SNK - Neo Geo Pocket Color", "wswan": "Bandai - WonderSwan", "wswanc": "Bandai - WonderSwan Color",
    "psx": "Sony - PlayStation", "ps2": "Sony - PlayStation 2", "3do": "The 3DO Company - 3DO", "cdi": "Philips - CD-i",
    "x68000": "Sharp - X68000", "pc88": "NEC - PC-88", "pc98": "NEC - PC-98", "fmtowns": "Fujitsu - FM Towns",
    "trs80": "Tandy - TRS-80", "oric": "Oric - Atmos", "dragon": "Dragon - 32/64", "samcoupe": "MGT - SAM Coupe",
}


class System:
    """A system folder found in the scan, and what the sites call it."""

    def __init__(self, canon, label, folder, path):
        self.canon, self.label, self.folder, self.path = canon, label, folder, path
        self.files = 0

    @property
    def names(self):
        return [self.label] + ALIASES.get(self.canon, [])


def resolve_system(folder_name):
    """Folder name (any layout, or a TOSEC name) -> (canonical id, label) or None."""
    low = re.sub(r"\s*\(TOSEC[^)]*\)", "", folder_name).strip().lower()
    canon = REVERSE.get(low) or canonical_system(low.split(" - ")[0]) or canonical_system(low)
    return (canon, LABELS.get(canon, canon)) if canon else None


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #

STOP = threading.Event()


def human(n):
    n = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:,.0f} {unit}" if unit == "B" else f"{n:,.1f} {unit}"
        n /= 1024
    return f"{n:,.1f} TB"


def safe_name(s):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", s).strip(" .") or "_"


def atomic_write(path, data, binary=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    if binary:
        tmp.write_bytes(data)
    else:
        tmp.write_text(data, encoding="utf-8")
    os.replace(tmp, path)


def strip_accents(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


ROMAN = {"ii": "2", "iii": "3", "iv": "4", "v": "5", "vi": "6", "vii": "7", "viii": "8", "ix": "9", "x": "10"}


def norm(s):
    """Loose form of a title used for comparing names from different sources."""
    s = strip_accents(s).lower().replace("&", " and ")
    s = re.sub(r"\([^)]*\)|\[[^\]]*\]", " ", s)
    m = re.match(r"^(.*?),\s*(the|a|an)\b(.*)$", s)
    if m:
        s = f"{m.group(2)} {m.group(1)}{m.group(3)}"
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    s = re.sub(r"^(the|a|an) ", "", s)
    return " ".join(ROMAN.get(w, w) for w in s.split())


def similarity(a, b):
    """0..1 - how alike two titles are."""
    na, nb = norm(a), norm(b)
    if not na or not nb:
        return 0.0
    if na == nb:
        return 1.0
    ratio = SequenceMatcher(None, na, nb).ratio()
    ta, tb = set(na.split()), set(nb.split())
    jac = len(ta & tb) / len(ta | tb)
    score = max(ratio, jac * 0.95)
    nums_a = {t for t in ta if t.isdigit()}
    nums_b = {t for t in tb if t.isdigit()}
    if nums_a != nums_b:                      # "Game 2" is not "Game"
        score *= 0.75
    return score


def best_platform(names, candidates, cutoff=0.74):
    """names: our names for a system. candidates: [(id, [their names])]. -> id or None"""
    best, best_id = 0.0, None
    for cid, cnames in candidates:
        for ours in names:
            for theirs in cnames:
                if not theirs:
                    continue
                s = similarity(ours, theirs)
                if s > best:
                    best, best_id = s, cid
    return best_id if best >= cutoff else None


class Game:
    """One ROM file to look up."""

    def __init__(self, path, system, root):
        self.path, self.system = path, system
        self.rel = path.relative_to(system.path).as_posix()
        self.key = f"{system.folder}/{self.rel}"
        stem = path.name
        if stem.lower().endswith(".zip"):
            stem = stem[:-4]
        m = re.search(r"\.([A-Za-z][A-Za-z0-9]{0,3})$", stem)
        if m:
            stem = stem[:m.start()]
        self.stem = stem
        flag_free = re.sub(r"\[[^\]]*\]", "", stem).strip()
        idx = flag_free.find("(")
        title = (flag_free[:idx] if idx >= 0 else flag_free).strip() or stem
        groups = re.findall(r"\(([^)]*)\)", flag_free)
        self.year = 0
        for g in groups:
            if re.match(r"^[0-9x]{4}(-[0-9x]{2}(-[0-9x]{2})?)?$", g, re.I):
                y = g[:4].replace("x", "0").replace("X", "0")
                self.year = int(y) if y.isdigit() and int(y) >= 1950 else 0
                break
        self.regions = []
        for g in groups:
            if re.match(r"^[A-Z]{2}(-[A-Z]{2})*$", g) and g not in {"CW", "FW", "GW", "LW", "PD", "SW"}:
                self.regions = g.split("-")
                break
        title = re.sub(r"\s[vV]\d+(?:[.\-]\d+)*[a-zA-Z]?(?=\s|$)", "", title)
        title = re.sub(r"\sRev\s?\w+(?=\s|$)", "", title, flags=re.I)
        m = re.match(r"^(.*?),\s*(The|A|An)(\s+-\s+.*)?$", title)
        if m:
            title = f"{m.group(2)} {m.group(1)}{m.group(3) or ''}"
        self.title = title.strip()
        self.size = 0
        try:
            self.size = path.stat().st_size
        except OSError:
            pass
        self._hashes = None

    @property
    def search_titles(self):
        """Queries to try, best first (full title, then without a subtitle)."""
        out = [self.title]
        base = re.split(r"\s+-\s+|\s*:\s+", self.title)[0].strip()
        if base and base != self.title and len(base) > 3:
            out.append(base)
        return out

    def hashes(self, max_bytes):
        """(crc32, md5, sha1, size, filename) of the ROM, looking inside a one-file zip."""
        if self._hashes is not None:
            return self._hashes
        crc = md5 = sha1 = ""
        size, name = self.size, self.path.name
        try:
            if self.path.suffix.lower() == ".zip" and zipfile.is_zipfile(self.path):
                with zipfile.ZipFile(self.path) as z:
                    members = [i for i in z.infolist() if not i.is_dir()]
                    if len(members) == 1:
                        info = members[0]
                        size, name = info.file_size, Path(info.filename).name
                        crc = f"{info.CRC:08X}"
                        if info.file_size <= max_bytes:
                            m5, s1 = hashlib.md5(), hashlib.sha1()
                            with z.open(info) as f:
                                for chunk in iter(lambda: f.read(1 << 20), b""):
                                    m5.update(chunk)
                                    s1.update(chunk)
                            md5, sha1 = m5.hexdigest().upper(), s1.hexdigest().upper()
            elif self.size <= max_bytes:
                c, m5, s1 = 0, hashlib.md5(), hashlib.sha1()
                with open(self.path, "rb") as f:
                    for chunk in iter(lambda: f.read(1 << 20), b""):
                        c = zlib.crc32(chunk, c)
                        m5.update(chunk)
                        s1.update(chunk)
                crc, md5, sha1 = f"{c & 0xffffffff:08X}", m5.hexdigest().upper(), s1.hexdigest().upper()
        except (OSError, zipfile.BadZipFile, RuntimeError):
            pass
        self._hashes = (crc, md5, sha1, size, name)
        return self._hashes


# --------------------------------------------------------------------------- #
# Speed meter, speed limit, time-of-day schedule, pause
# --------------------------------------------------------------------------- #

PAUSED = threading.Event()               # set = the user has paused the run
DAY_NAMES = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


class Rule:
    """One schedule line: between two times, on some days, run at a speed."""

    def __init__(self, start, end, days, action, text):
        self.start, self.end, self.days, self.action, self.text = start, end, days, action, text

    def matches(self, now):
        t = now.hour * 60 + now.minute
        wd = now.weekday()
        if self.start == self.end:                       # whole day
            return wd in self.days
        if self.start < self.end:
            return self.start <= t < self.end and wd in self.days
        if t >= self.start:                              # crosses midnight: evening part
            return wd in self.days
        return (wd - 1) % 7 in self.days and t < self.end   # ...and the morning after

    def describe(self):
        a = {None: "full speed", 0: "paused"}.get(self.action)
        if a is None:
            a = f"limited to {human(self.action)}/s"
        return f"{self.text.split('=')[0].strip()} - {a}"


def _days(text):
    text = (text or "all").lower().replace(" ", "")
    if text in ("all", "*", "daily", "every"):
        return set(range(7))
    if text == "weekdays":
        return set(range(5))
    if text == "weekends":
        return {5, 6}
    out = set()
    for part in text.split(","):
        if "-" in part:
            a, b = part.split("-", 1)
            if a[:3] not in DAY_NAMES or b[:3] not in DAY_NAMES:
                raise ValueError("bad day")
            i, j = DAY_NAMES.index(a[:3]), DAY_NAMES.index(b[:3])
            out |= {(i + k) % 7 for k in range(((j - i) % 7) + 1)}
        elif part[:3] in DAY_NAMES:
            out.add(DAY_NAMES.index(part[:3]))
        else:
            raise ValueError("bad day")
    return out


def parse_rule(text):
    """'22:00-07:00@mon-fri=full' / '07:00-23:00=500' / '12:00-13:00=pause' / '09:00-17:00=2mb'"""
    m = re.match(r"^\s*(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*(?:@\s*([A-Za-z,\- ]+?))?\s*=\s*"
                 r"(full|unlimited|pause|paused|\d+(?:\.\d+)?\s*(?:kb|mb|k|m)?(?:/s|ps)?)\s*$", text, re.I)
    if not m:
        raise ValueError(f"Cannot read the schedule rule '{text}'")
    h1, m1, h2, m2 = (int(m.group(i)) for i in range(1, 5))
    if h1 > 24 or h2 > 24 or m1 > 59 or m2 > 59:
        raise ValueError("Times must be HH:MM (24 hour)")
    spd = m.group(6).lower().replace(" ", "")
    if spd in ("full", "unlimited"):
        action = None
    elif spd in ("pause", "paused"):
        action = 0
    else:
        num = float(re.match(r"[\d.]+", spd).group(0))
        action = int(num * (1048576 if "m" in spd else 1024))
        if action <= 0:
            raise ValueError("Speed must be more than 0")
    return Rule((h1 % 24) * 60 + m1, (h2 % 24) * 60 + m2, _days(m.group(5)), action, text.strip())


def make_rule_text(start, end, days, speed):
    d = "" if not days or set(days) == set(range(7)) else "@" + ",".join(DAY_NAMES[i] for i in sorted(days))
    return f"{start}-{end}{d}={speed}"


class Bandwidth:
    """Counts downloaded bytes, shows the speed, and slows downloads to the limit in force."""

    def __init__(self):
        self.lock = threading.Lock()
        self.manual = 0                   # bytes per second, 0 = unlimited
        self.rules, self.use_schedule = [], False
        self.total, self.samples, self.next = 0, [], 0.0
        self.now = datetime.datetime.now  # replaceable for testing

    def configure(self, limit_kbps, rules, use_schedule):
        self.manual = int(limit_kbps or 0) * 1024
        self.rules = [parse_rule(r) for r in rules or []]
        self.use_schedule = bool(use_schedule)

    def current(self):
        """-> (bytes/s limit or None, paused by schedule?, description)"""
        if self.use_schedule:
            now = self.now()
            for r in self.rules:
                if r.matches(now):
                    return (None if r.action is None else r.action or None), r.action == 0, "schedule: " + r.describe()
        if self.manual:
            return self.manual, False, f"limit {human(self.manual)}/s"
        return None, False, "full speed"

    def scheduled_pause(self):
        return self.current()[1]

    def count(self, n):
        t = time.monotonic()
        with self.lock:
            self.total += n
            self.samples.append((t, n))
            while self.samples and t - self.samples[0][0] > 5:
                self.samples.pop(0)

    def speed(self):
        t = time.monotonic()
        with self.lock:
            recent = [(a, n) for a, n in self.samples if t - a <= 3]
        return sum(n for _, n in recent) / 3.0 if recent else 0.0

    def throttle(self, n):
        """Call after receiving n bytes: counts them, waits for pause, and sleeps to hold the limit."""
        wait_if_paused()
        lim, _, _ = self.current()
        if lim and n:
            with self.lock:
                now = time.monotonic()
                self.next = min(self.next, now + 2.0)
                start = max(now, self.next)
                self.next = start + n / float(lim)
            delay = start - now
            while delay > 0 and not STOP.is_set():
                time.sleep(min(delay, 0.2))
                delay -= 0.2
        self.count(n)

    def status(self):
        lim, paused, desc = self.current()
        if PAUSED.is_set():
            state = "paused"
        elif paused:
            state = "paused by schedule"
        else:
            state = ""
        return {"speed": self.speed(), "total": self.total, "limit": lim, "desc": desc, "state": state}


BW = Bandwidth()
PAUSE_HOOK = {"fn": None, "fired": False}


def wait_if_paused():
    """Blocks while the run is paused (by the user or by the schedule). Returns at once on Stop."""
    first = True
    while (PAUSED.is_set() or BW.scheduled_pause()) and not STOP.is_set():
        if first:
            first = False
            fn = PAUSE_HOOK["fn"]
            if fn and not PAUSE_HOOK["fired"]:
                PAUSE_HOOK["fired"] = True
                try:
                    fn()
                except Exception:
                    pass
        time.sleep(0.25)
    if not first:
        PAUSE_HOOK["fired"] = False


# --------------------------------------------------------------------------- #
# Network: polite, retrying, rate limited
# --------------------------------------------------------------------------- #

class HttpError(Exception):
    def __init__(self, status, body="", url=""):
        super().__init__(f"HTTP {status}")
        self.status, self.body, self.url = status, body, url


class RateLimiter:
    def __init__(self, interval):
        self.interval, self.next, self.lock = interval, 0.0, threading.Lock()

    def wait(self):
        wait_if_paused()
        with self.lock:
            now = time.monotonic()
            when = max(now, self.next)
            self.next = when + self.interval
        while True:
            left = when - time.monotonic()
            if left <= 0 or STOP.is_set():
                return
            time.sleep(min(left, 0.25))


def read_body(r, cap=None):
    """Read a response in pieces so the speed meter, limit and pause all work on it."""
    chunks, total = [], 0
    while True:
        c = r.read(1 << 16)
        if not c:
            break
        total += len(c)
        if cap and total > cap:
            raise HttpError(413, "file too large", "")
        chunks.append(c)
        BW.throttle(len(c))
        if STOP.is_set():
            raise HttpError(0, "stopped", "")
    return b"".join(chunks)


def http(url, params=None, data=None, headers=None, method=None, timeout=30, retries=3, raw=False,
         limiter=None):
    """GET/POST and return text (or bytes with raw=True). Raises HttpError."""
    if params:
        url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True, safe="[]")
    if isinstance(data, dict):
        data = urllib.parse.urlencode(data).encode()
    elif isinstance(data, str):
        data = data.encode("utf-8")
    hdrs = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    hdrs.update(headers or {})
    delay = 2.0
    for attempt in range(retries + 1):
        if STOP.is_set():
            raise HttpError(0, "stopped", url)
        if limiter:
            limiter.wait()
        req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                body = read_body(r)
                return body if raw else body.decode(r.headers.get_content_charset() or "utf-8", "replace")
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")
            except Exception:
                pass
            if e.code in (429, 500, 502, 503, 504) and attempt < retries:
                wait = delay
                try:
                    wait = max(wait, float(e.headers.get("Retry-After", 0)))
                except (TypeError, ValueError):
                    pass
                time.sleep(min(wait, 60))
                delay *= 2
                continue
            raise HttpError(e.code, body, url)
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            if attempt < retries:
                time.sleep(delay)
                delay *= 2
                continue
            raise HttpError(0, str(e), url)
    raise HttpError(0, "gave up", url)


def http_json(url, **kw):
    text = http(url, **kw)
    try:
        return json.loads(text)
    except ValueError:
        raise HttpError(200, text[:300], url)


# --------------------------------------------------------------------------- #
# Saved settings and logins
# --------------------------------------------------------------------------- #

class Options:
    SESSION_ONLY = ("systems", "dry_run")

    def __init__(self):
        self.folders = []
        self.services = ["libretro", "launchbox"]      # ordered = priority
        self.fields = [k for k, _ in FIELDS]
        self.media = ["boxart", "screenshot", "titlescreen", "logo"]
        self.format = "auto"
        self.output_dir = ""                           # "" = next to the ROMs
        self.overwrite_meta = False
        self.overwrite_media = False
        self.skip_done = True                          # resume
        self.retry_missing = False                     # look again for games not found last time
        self.min_score = 0.80
        self.regions = "us,wor,eu,uk,jp"
        self.language = "en"
        self.workers = 3
        self.hash_lookup = True
        self.hash_max_mb = 128
        self.video_max_mb = 60
        self.write_csv = True
        self.limit_kbps = 0                            # download speed limit, 0 = full speed
        self.schedule_on = False
        self.schedule = []                             # rules like "22:00-07:00@mon-fri=full"
        self.systems = None                            # list of folder names, None = all found
        self.dry_run = False

    def to_dict(self):
        return {k: v for k, v in self.__dict__.items() if k not in self.SESSION_ONLY}

    @classmethod
    def from_dict(cls, d):
        o = cls()
        for k, v in (d or {}).items():
            if k in o.__dict__ and k not in cls.SESSION_ONLY:
                setattr(o, k, v)
        return o

    def save(self):
        try:
            SETTINGS.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        except OSError:
            pass

    @classmethod
    def load(cls):
        try:
            return cls.from_dict(json.loads(SETTINGS.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            return cls()

    def region_list(self):
        return [r.strip().lower() for r in re.split(r"[,\s;]+", self.regions) if r.strip()] or ["us", "wor", "eu"]

    def normalise(self):
        try:
            self.min_score = min(1.0, max(0.3, float(self.min_score)))
        except (TypeError, ValueError):
            self.min_score = 0.8
        for attr, lo, hi, d in (("workers", 1, 16, 3), ("hash_max_mb", 1, 4096, 128), ("video_max_mb", 1, 2000, 60)):
            try:
                setattr(self, attr, min(hi, max(lo, int(getattr(self, attr)))))
            except (TypeError, ValueError):
                setattr(self, attr, d)
        if self.format not in FORMATS:
            self.format = "auto"
        try:
            self.limit_kbps = max(0, int(float(self.limit_kbps)))
        except (TypeError, ValueError):
            self.limit_kbps = 0
        good = []
        for r in self.schedule or []:
            try:
                parse_rule(r)
                good.append(r)
            except ValueError:
                pass
        self.schedule = good
        return self


class Credentials:
    """Logins held in memory; written to disk only for services the user chose to remember."""

    def __init__(self):
        self.values = {}          # service id -> {field: value}
        self.remember = set()
        self.lock = threading.Lock()
        try:
            saved = json.loads(CREDENTIALS.read_text(encoding="utf-8"))
            for sid, vals in saved.items():
                if isinstance(vals, dict):
                    self.values[sid] = {k: str(v) for k, v in vals.items()}
                    self.remember.add(sid)
        except (OSError, ValueError):
            pass
        for sid in list(SERVICE_FIELDS):                       # environment variables also work
            for key in SERVICE_FIELDS[sid]:
                env = os.environ.get(f"ROM_SCRAPER_{sid}_{key}".upper())
                if env:
                    self.values.setdefault(sid, {})[key] = env

    def get(self, sid):
        return dict(self.values.get(sid, {}))

    def set(self, sid, vals, remember):
        with self.lock:
            self.values[sid] = {k: v for k, v in vals.items() if v != ""}
            (self.remember.add if remember else self.remember.discard)(sid)
            self.flush()

    def flush(self):
        data = {sid: self.values[sid] for sid in self.remember if sid in self.values}
        try:
            if data:
                atomic_write(CREDENTIALS, json.dumps(data, indent=2))
                try:
                    os.chmod(CREDENTIALS, 0o600)
                except OSError:
                    pass
            elif CREDENTIALS.exists():
                CREDENTIALS.unlink()
        except OSError:
            pass


SERVICE_FIELDS = {}      # filled in below from the service classes


# --------------------------------------------------------------------------- #
# Scraper services
# --------------------------------------------------------------------------- #

class CredentialError(Exception):
    """The site refused the login / key."""


class QuotaError(Exception):
    """The site says today's allowance is used up."""


def new_match(source, ident, title, score):
    return {"source": source, "id": str(ident), "title": title, "desc": "", "year": 0, "released": "",
            "developer": "", "publisher": "", "genre": "", "players": "", "rating": None,
            "media": {}, "score": round(score, 3)}


def year_of(text):
    m = re.match(r"^(\d{4})", str(text or ""))
    return int(m.group(1)) if m and int(m.group(1)) >= 1950 else 0


def date_of(text):
    """'1991-05-01' / '1991' -> '1991-05-01' or '1991'."""
    m = re.match(r"^(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?", str(text or ""))
    if not m or int(m.group(1)) < 1950:
        return ""
    return "-".join(p for p in m.groups() if p)


def prefer(items, key, prefs, default_first=True):
    """Pick the item whose `key` (region / language) is earliest in the preference list."""
    for p in prefs:
        for it in items:
            if str(it.get(key, "")).lower() == p:
                return it
    return items[0] if (items and default_first) else None


class TitleIndex:
    """Fast fuzzy title lookup: exact match first, then compare only titles sharing a word."""

    def __init__(self):
        self.exact, self.tokens, self.keys = {}, {}, []

    def add(self, title, payload):
        k = norm(title)
        if not k:
            return
        if k not in self.exact:
            self.exact[k] = []
            self.keys.append(k)
            for t in set(k.split()):
                self.tokens.setdefault(t, []).append(k)
        self.exact[k].append(payload)

    def __len__(self):
        return len(self.keys)

    def find(self, queries, min_score):
        """-> (payload list, score, matched key) for the best title, or (None, best score, '')"""
        best, best_s = None, 0.0
        for q in queries:
            nq = norm(q)
            if not nq:
                continue
            if nq in self.exact:
                return self.exact[nq], 1.0, nq
            pool = set()
            toks = sorted(set(nq.split()), key=lambda t: len(self.tokens.get(t, ())))
            for t in toks[:4]:
                pool.update(self.tokens.get(t, ())[:600])
            for k in pool:
                s = similarity(nq, k)
                if s > best_s:
                    best, best_s = k, s
        if best and best_s >= min_score:
            return self.exact[best], best_s, best
        return None, best_s, ""


def choose(game, cands, min_score):
    """cands: dicts with 'title' and optional 'year'. -> (candidate, score) or (None, best)"""
    best, best_s = None, 0.0
    for c in cands:
        s = max(similarity(q, c["title"]) for q in game.search_titles)
        if game.year and c.get("year"):
            d = abs(game.year - c["year"])
            s += 0.04 if d == 0 else (0.02 if d <= 1 else (-0.06 if d > 3 else 0))
        if s > best_s:
            best, best_s = c, s
    return (best, min(best_s, 1.0)) if best and best_s >= min_score else (None, best_s)


class Service:
    id = ""
    name = ""
    site = ""
    blurb = ""
    login = "none"                # none | key | account
    fields = []                   # (key, label, secret, required, help)
    interval = 1.0                # seconds between requests
    threads = 4                   # simultaneous lookups
    supplies_media = ()
    supplies_meta = True

    def __init__(self, creds, opts, log):
        self.c, self.opts, self.log = creds.get(self.id), opts, log
        self.limiter = RateLimiter(self.interval)
        self.sem = threading.Semaphore(self.threads)
        self.platform = {}        # canonical id -> the site's platform id / folder
        self.dead = ""            # reason this service is switched off for the rest of the run
        self.regions = opts.region_list()
        self.langs = [opts.language.lower(), "en"]

    def set_credentials(self, creds):
        self.c = creds

    def missing(self):
        return [f for f in self.fields if f[3] and not self.c.get(f[0])]

    def check(self):
        """-> (ok, message). Verifies the login/key (and that the site answers)."""
        return True, "OK"

    def prepare(self, systems):
        """Work out the site's id for each of our systems."""

    def supports(self, system):
        return system.canon in self.platform

    def lookup(self, game):
        """-> match dict (see new_match) or None."""
        raise NotImplementedError

    def get(self, url, **kw):
        kw.setdefault("limiter", self.limiter)
        return http_json(url, **kw)

    @property
    def wants_media(self):
        return set(self.opts.media)


# ----- ScreenScraper -------------------------------------------------------- #

class ScreenScraper(Service):
    id, name, site = "screenscraper", "ScreenScraper", "https://www.screenscraper.fr"
    blurb = "Best coverage for retro systems. Looks games up by file hash, then by name."
    login = "account"
    base = "https://api.screenscraper.fr/api2"
    fields = [
        ("devid", "Developer ID", False, True, "API access id - free from the ScreenScraper forum (request 'API access')."),
        ("devpassword", "Developer password", True, True, "The matching API password from the same request."),
        ("ssid", "Your ScreenScraper user name", False, False, "Optional but recommended: gives you a bigger daily allowance."),
        ("sspassword", "Your ScreenScraper password", True, False, ""),
    ]
    interval = 1.3
    threads = 1
    supplies_media = ("boxart", "screenshot", "titlescreen", "logo", "video")
    MEDIA_TYPES = {"boxart": ["box-2D"], "screenshot": ["ss"], "titlescreen": ["sstitle"],
                   "logo": ["wheel", "wheel-hd", "marquee", "screenmarquee"], "video": ["video-normalized", "video"]}

    def _params(self, **extra):
        p = {"devid": self.c.get("devid", ""), "devpassword": self.c.get("devpassword", ""),
             "softname": SOFTNAME, "output": "json"}
        if self.c.get("ssid"):
            p["ssid"], p["sspassword"] = self.c["ssid"], self.c.get("sspassword", "")
        p.update({k: v for k, v in extra.items() if v not in ("", None)})
        return p

    def api(self, endpoint, **extra):
        """JSON 'response' dict, or None when the game is simply not there."""
        if self.dead:
            return None
        for attempt in range(3):
            try:
                data = self.get(f"{self.base}/{endpoint}", params=self._params(**extra), timeout=40)
                return data.get("response") if isinstance(data, dict) else None
            except HttpError as e:
                body = (e.body or "")[:200]
                if e.status in (401, 403) or "Erreur de login" in body:
                    raise CredentialError("ScreenScraper refused the developer or user login")
                if e.status == 430 or "quota" in body.lower():
                    self.dead = "daily allowance used up"
                    raise QuotaError("ScreenScraper daily allowance used up")
                if e.status == 429:
                    time.sleep(8 * (attempt + 1))
                    continue
                if e.status in (423, 426):
                    self.dead = "ScreenScraper is closed or has blocked this program version"
                    raise QuotaError(self.dead)
                if e.status == 200 and "Erreur de login" in body:
                    raise CredentialError("ScreenScraper refused the login")
                return None                       # 404 (not found), 431, odd replies
        return None

    def check(self):
        try:
            r = self.api("systemesListe.php")
        except CredentialError as e:
            return False, str(e)
        except QuotaError as e:
            return False, str(e)
        if not r or "systemes" not in r:
            return False, "No answer from ScreenScraper (check the developer ID/password and your connection)"
        self._systems = r["systemes"]
        if self.c.get("ssid"):
            try:
                u = (self.api("ssuserInfos.php") or {}).get("ssuser", {})
                threads = int(u.get("maxthreads") or 1)
                self.sem = threading.Semaphore(max(1, min(4, threads)))
                rpm = int(u.get("maxrequestspermin") or 0)
                if rpm:
                    self.limiter = RateLimiter(max(0.5, 60.0 / rpm * 1.15))
                today, cap = int(u.get("requeststoday") or 0), int(u.get("maxrequestsperday") or 0)
                if cap and today >= cap:
                    return False, f"Daily allowance already used ({today}/{cap}). Try again tomorrow."
            except (CredentialError, QuotaError) as e:
                return False, str(e)
            except (TypeError, ValueError):
                pass
        return True, "Logged in"

    def prepare(self, systems):
        systems_json = getattr(self, "_systems", None)
        if systems_json is None:
            r = self.api("systemesListe.php") or {}
            systems_json = r.get("systemes", [])
        cands = []
        for s in systems_json:
            n = s.get("noms") or {}
            names = [n.get(k, "") for k in ("nom_eu", "nom_us", "nom_launchbox", "nom_hyperspin")]
            names += [x.strip() for x in str(n.get("noms_commun", "")).split(",")]
            cands.append((s.get("id"), names, str(n.get("nom_recalbox", "")).lower(), str(n.get("nom_retropie", "")).lower()))
        for system in systems:
            folders = {t[system.canon].lower() for t in (BATOCERA, RECALBOX, RETROPIE, ESDE) if system.canon in t}
            hit = next((c[0] for c in cands if c[2] in folders or c[3] in folders and c[3]), None)
            if hit is None:
                hit = best_platform(system.names, [(c[0], c[1]) for c in cands])
            if hit is not None:
                self.platform[system.canon] = hit

    def parse(self, jeu, game, score):
        names = jeu.get("noms") or []
        pick = prefer(names, "region", self.regions)
        title = (pick or {}).get("text") or game.title
        m = new_match(self.id, jeu.get("id", ""), title, score)
        syn = prefer(jeu.get("synopsis") or [], "langue", self.langs, default_first=False)
        m["desc"] = (syn or {}).get("text", "")
        d = prefer(jeu.get("dates") or [], "region", self.regions)
        m["released"] = date_of((d or {}).get("text"))
        m["year"] = year_of(m["released"])
        genres = []
        for g in jeu.get("genres") or []:
            n = prefer(g.get("noms") or [], "langue", self.langs, default_first=False)
            if n and n.get("text"):
                genres.append(n["text"])
        m["genre"] = ", ".join(genres[:2])
        m["players"] = (jeu.get("joueurs") or {}).get("text", "")
        m["publisher"] = (jeu.get("editeur") or {}).get("text", "")
        m["developer"] = (jeu.get("developpeur") or {}).get("text", "")
        try:
            m["rating"] = round(float((jeu.get("note") or {}).get("text")) / 20.0, 3)
        except (TypeError, ValueError):
            pass
        medias = jeu.get("medias") or []
        for want in self.wants_media:
            for t in self.MEDIA_TYPES.get(want, []):
                cands = [x for x in medias if x.get("type") == t and x.get("url")]
                if cands:
                    best = prefer(cands, "region", self.regions)
                    m["media"][want] = best["url"]
                    break
        return m

    def lookup(self, game):
        sysid = self.platform.get(game.system.canon)
        if not sysid:
            return None
        crc, md5, sha1, size, fname = game.hashes(self.opts.hash_max_mb * 1048576) if self.opts.hash_lookup else ("", "", "", game.size, game.path.name)
        r = self.api("jeuInfos.php", systemeid=sysid, romtype="rom", romnom=fname, romtaille=size,
                     crc=crc, md5=md5, sha1=sha1)
        jeu = (r or {}).get("jeu")
        if isinstance(jeu, dict) and jeu.get("id"):
            return self.parse(jeu, game, 1.0)
        for q in game.search_titles:
            r = self.api("jeuRecherche.php", systemeid=sysid, recherche=q)
            found = [j for j in (r or {}).get("jeux", []) if isinstance(j, dict) and j.get("id")]
            cands = []
            for j in found:
                pick = prefer(j.get("noms") or [], "region", self.regions)
                d = prefer(j.get("dates") or [], "region", self.regions)
                cands.append({"title": (pick or {}).get("text", ""), "year": year_of((d or {}).get("text")), "jeu": j})
            cand, score = choose(game, [c for c in cands if c["title"]], self.opts.min_score)
            if cand:
                r = self.api("jeuInfos.php", systemeid=sysid, gameid=cand["jeu"]["id"])
                jeu = (r or {}).get("jeu")
                if isinstance(jeu, dict) and jeu.get("id"):
                    return self.parse(jeu, game, score)
        return None


# ----- TheGamesDB ----------------------------------------------------------- #

class TheGamesDB(Service):
    id, name, site = "thegamesdb", "TheGamesDB", "https://thegamesdb.net"
    blurb = "Community database with box art and screenshots. Free API key."
    login = "key"
    base = "https://api.thegamesdb.net/v1"
    fields = [("apikey", "API key", True, True, "Free from thegamesdb.net (forum > 'API access'). It has a monthly allowance.")]
    interval = 0.6
    supplies_media = ("boxart", "screenshot", "titlescreen", "logo")
    IMG = {"screenshot": "screenshot", "titlescreen": "titlescreen", "logo": "clearlogo"}

    def _lookup_table(self, kind):
        cache = self.__dict__.setdefault("_tables", {})
        if kind not in cache:
            try:
                d = self.get(f"{self.base}/{kind}", params={"apikey": self.c["apikey"]}).get("data", {}).get(kind.lower(), {})
            except HttpError:
                d = {}
            cache[kind] = {str(k): (v.get("name") if isinstance(v, dict) else str(v)) for k, v in d.items()}
        return cache[kind]

    def check(self):
        try:
            d = self.get(f"{self.base}/Platforms", params={"apikey": self.c["apikey"]})
        except HttpError as e:
            if e.status in (401, 403):
                return False, "TheGamesDB rejected the API key"
            return False, f"Could not reach TheGamesDB ({e})"
        self._platforms = (d.get("data") or {}).get("platforms") or {}
        if not self._platforms:
            return False, "TheGamesDB returned no platforms - check the API key"
        return True, "Key accepted"

    def prepare(self, systems):
        plats = getattr(self, "_platforms", None)
        if plats is None:
            try:
                plats = self.get(f"{self.base}/Platforms", params={"apikey": self.c["apikey"]}).get("data", {}).get("platforms", {})
            except HttpError:
                plats = {}
        cands = [(p.get("id"), [p.get("name"), p.get("alias")]) for p in plats.values()]
        for s in systems:
            pid = best_platform(s.names, cands)
            if pid:
                self.platform[s.canon] = pid

    def lookup(self, game):
        pid = self.platform.get(game.system.canon)
        if not pid:
            return None
        cand = score = data = None
        for q in game.search_titles:
            data = self.get(f"{self.base}/Games/ByGameName", params={
                "apikey": self.c["apikey"], "name": q, "filter[platform]": pid,
                "fields": "players,publishers,genres,overview,rating,developers", "include": "boxart"})
            games = (data.get("data") or {}).get("games") or []
            cand, score = choose(game, [{"title": g.get("game_name", ""), "year": year_of(g.get("release_date")), "g": g}
                                        for g in games], self.opts.min_score)
            if cand:
                break
        if not cand:
            return None
        g = cand["g"]
        m = new_match(self.id, g.get("id"), g.get("game_name", game.title), score)
        m["desc"] = g.get("overview") or ""
        m["released"] = date_of(g.get("release_date"))
        m["year"] = year_of(m["released"])
        m["players"] = str(g.get("players") or "")
        try:
            r = float(g.get("rating") or 0)
            m["rating"] = round(r / 10.0, 3) if r > 0 and r <= 10 else None
        except (TypeError, ValueError):
            pass
        if "genre" in self.opts.fields:
            tab = self._lookup_table("Genres")
            m["genre"] = ", ".join(tab[str(i)] for i in (g.get("genres") or [])[:2] if str(i) in tab)
        if "developer" in self.opts.fields and g.get("developers"):
            tab = self._lookup_table("Developers")
            m["developer"] = ", ".join(tab[str(i)] for i in g["developers"][:1] if str(i) in tab)
        if "publisher" in self.opts.fields and g.get("publishers"):
            tab = self._lookup_table("Publishers")
            m["publisher"] = ", ".join(tab[str(i)] for i in g["publishers"][:1] if str(i) in tab)
        gid = str(g.get("id"))
        inc = (data.get("include") or {}).get("boxart") or {}
        base_url = (inc.get("base_url") or {}).get("original", "https://cdn.thegamesdb.net/images/original/")
        if "boxart" in self.wants_media:
            arts = (inc.get("data") or {}).get(gid) or []
            front = next((a for a in arts if a.get("type") == "boxart" and a.get("side") == "front"), None)
            if front:
                m["media"]["boxart"] = base_url + front["filename"]
        extra = [t for k, t in self.IMG.items() if k in self.wants_media]
        if extra:
            try:
                im = self.get(f"{self.base}/Games/Images", params={"apikey": self.c["apikey"], "games_id": gid,
                                                                   "filter[type]": ",".join(extra)})
                base2 = ((im.get("data") or {}).get("base_url") or {}).get("original", base_url)
                imgs = ((im.get("data") or {}).get("images") or {}).get(gid) or []
                for k, t in self.IMG.items():
                    pick = next((i for i in imgs if i.get("type") == t), None)
                    if pick and k in self.wants_media:
                        m["media"][k] = base2 + pick["filename"]
            except HttpError:
                pass
        return m


# ----- IGDB ----------------------------------------------------------------- #

class IGDB(Service):
    id, name, site = "igdb", "IGDB", "https://www.igdb.com"
    blurb = "Large modern database (owned by Twitch). Free Twitch developer login."
    login = "account"
    base = "https://api.igdb.com/v4"
    token_url = "https://id.twitch.tv/oauth2/token"
    fields = [("client_id", "Twitch Client ID", False, True, "Create an application at dev.twitch.tv/console (free)."),
              ("client_secret", "Twitch Client Secret", True, True, "Shown on the same page after 'New Secret'.")]
    interval = 0.3
    supplies_media = ("boxart", "screenshot", "logo")

    def _token(self, force=False):
        if getattr(self, "_tok", None) and not force and time.time() < self._tok_exp:
            return self._tok
        try:
            r = http_json(self.token_url, method="POST", data={
                "client_id": self.c["client_id"], "client_secret": self.c["client_secret"],
                "grant_type": "client_credentials"})
        except HttpError as e:
            if e.status in (400, 401, 403):
                raise CredentialError("Twitch rejected the client id / secret")
            raise
        self._tok = r.get("access_token")
        self._tok_exp = time.time() + int(r.get("expires_in", 3600)) - 120
        if not self._tok:
            raise CredentialError("Twitch did not return a token")
        return self._tok

    def api(self, endpoint, body):
        for attempt in (0, 1):
            tok = self._token(force=bool(attempt))
            try:
                return self.get(f"{self.base}/{endpoint}", method="POST", data=body,
                                headers={"Client-ID": self.c["client_id"], "Authorization": f"Bearer {tok}",
                                         "Accept": "application/json"})
            except HttpError as e:
                if e.status == 401 and not attempt:
                    continue
                if e.status in (401, 403):
                    raise CredentialError("IGDB rejected the login")
                raise
        return []

    def check(self):
        try:
            self._token(force=True)
            self.api("platforms", "fields name; limit 1;")
        except CredentialError as e:
            return False, str(e)
        except HttpError as e:
            return False, f"Could not reach IGDB ({e})"
        return True, "Logged in"

    def prepare(self, systems):
        plats, offset = [], 0
        while offset < 2000:
            chunk = self.api("platforms", f"fields name,abbreviation,alternative_name; limit 500; offset {offset};")
            if not chunk:
                break
            plats += chunk
            if len(chunk) < 500:
                break
            offset += 500
        cands = [(p["id"], [p.get("name"), p.get("alternative_name")]) for p in plats if "id" in p]
        for s in systems:
            pid = best_platform(s.names, cands)
            if pid:
                self.platform[s.canon] = pid

    @staticmethod
    def img(image_id, size):
        return f"https://images.igdb.com/igdb/image/upload/{size}/{image_id}.jpg"

    def lookup(self, game):
        pid = self.platform.get(game.system.canon)
        if not pid:
            return None
        cand = score = None
        for q in game.search_titles:
            esc = q.replace("\\", " ").replace('"', " ")
            rows = self.api("games", f'search "{esc}"; fields name,summary,first_release_date,genres.name,'
                                     'involved_companies.company.name,involved_companies.developer,'
                                     'involved_companies.publisher,cover.image_id,screenshots.image_id,'
                                     'artworks.image_id,total_rating,game_modes.name;'
                                     f' where platforms = ({pid}); limit 10;')
            cands = []
            for g in rows or []:
                ts = g.get("first_release_date")
                y = datetime.datetime.utcfromtimestamp(ts).year if ts else 0
                cands.append({"title": g.get("name", ""), "year": y, "g": g})
            cand, score = choose(game, cands, self.opts.min_score)
            if cand:
                break
        if not cand:
            return None
        g = cand["g"]
        m = new_match(self.id, g.get("id"), g.get("name", game.title), score)
        m["desc"] = g.get("summary") or ""
        if g.get("first_release_date"):
            m["released"] = datetime.datetime.utcfromtimestamp(g["first_release_date"]).strftime("%Y-%m-%d")
            m["year"] = year_of(m["released"])
        m["genre"] = ", ".join(x.get("name", "") for x in (g.get("genres") or [])[:2])
        for ic in g.get("involved_companies") or []:
            name = (ic.get("company") or {}).get("name", "")
            if ic.get("developer") and not m["developer"]:
                m["developer"] = name
            if ic.get("publisher") and not m["publisher"]:
                m["publisher"] = name
        if g.get("total_rating"):
            m["rating"] = round(float(g["total_rating"]) / 100.0, 3)
        modes = [x.get("name", "") for x in g.get("game_modes") or []]
        if modes:
            m["players"] = "1" if modes == ["Single player"] else ", ".join(modes[:2])
        if g.get("cover", {}).get("image_id") and "boxart" in self.wants_media:
            m["media"]["boxart"] = self.img(g["cover"]["image_id"], "t_cover_big_2x")
        if g.get("screenshots") and "screenshot" in self.wants_media:
            m["media"]["screenshot"] = self.img(g["screenshots"][0]["image_id"], "t_1080p")
        if g.get("artworks") and "logo" in self.wants_media:
            m["media"]["logo"] = self.img(g["artworks"][0]["image_id"], "t_720p")
        return m


# ----- MobyGames ------------------------------------------------------------ #

class MobyGames(Service):
    id, name, site = "mobygames", "MobyGames", "https://www.mobygames.com"
    blurb = "Well-researched retro database. Needs an API key (its free tier is slow)."
    login = "key"
    base = "https://api.mobygames.com/v1"
    fields = [("api_key", "API key", True, True, "From your MobyGames profile > API.")]
    interval = 5.0                      # the free plan allows roughly one request every few seconds
    threads = 1
    supplies_media = ("boxart", "screenshot")

    def check(self):
        try:
            d = self.get(f"{self.base}/platforms", params={"api_key": self.c["api_key"]})
        except HttpError as e:
            if e.status in (401, 403):
                return False, "MobyGames rejected the API key"
            return False, f"Could not reach MobyGames ({e})"
        self._platforms = d.get("platforms") or []
        return (True, "Key accepted") if self._platforms else (False, "MobyGames returned no platforms")

    def prepare(self, systems):
        plats = getattr(self, "_platforms", None)
        if plats is None:
            try:
                plats = self.get(f"{self.base}/platforms", params={"api_key": self.c["api_key"]}).get("platforms", [])
            except HttpError:
                plats = []
        cands = [(p["platform_id"], [p.get("platform_name")]) for p in plats if "platform_id" in p]
        for s in systems:
            pid = best_platform(s.names, cands)
            if pid:
                self.platform[s.canon] = pid

    def lookup(self, game):
        pid = self.platform.get(game.system.canon)
        if not pid:
            return None
        cand = score = None
        for q in game.search_titles:
            d = self.get(f"{self.base}/games", params={"api_key": self.c["api_key"], "title": q,
                                                       "platform": pid, "format": "normal", "limit": 10})
            cands = []
            for g in d.get("games") or []:
                rel = next((p.get("first_release_date") for p in g.get("platforms", []) if p.get("platform_id") == pid), "")
                cands.append({"title": g.get("title", ""), "year": year_of(rel), "g": g, "rel": rel})
            cand, score = choose(game, cands, self.opts.min_score)
            if cand:
                break
        if not cand:
            return None
        g = cand["g"]
        m = new_match(self.id, g.get("game_id"), g.get("title", game.title), score)
        desc = re.sub(r"<[^>]+>", " ", g.get("description") or "")
        m["desc"] = re.sub(r"\s+", " ", desc.replace("&quot;", '"').replace("&amp;", "&")).strip()
        m["released"] = date_of(cand["rel"])
        m["year"] = year_of(m["released"])
        m["genre"] = ", ".join(x.get("genre_name", "") for x in (g.get("genres") or [])[:2])
        if g.get("moby_score"):
            m["rating"] = round(float(g["moby_score"]) / 5.0, 3)
        sc = g.get("sample_cover") or {}
        if sc.get("image") and "boxart" in self.wants_media:
            m["media"]["boxart"] = sc["image"]
        shots = g.get("sample_screenshots") or []
        if shots and shots[0].get("image") and "screenshot" in self.wants_media:
            m["media"]["screenshot"] = shots[0]["image"]
        return m


# ----- RAWG ----------------------------------------------------------------- #

class RAWG(Service):
    id, name, site = "rawg", "RAWG", "https://rawg.io"
    blurb = "Mostly modern games, thin on 8/16-bit. Free API key."
    login = "key"
    base = "https://api.rawg.io/api"
    fields = [("key", "API key", True, True, "Free from rawg.io/apidocs.")]
    interval = 0.3
    supplies_media = ("screenshot",)

    def check(self):
        try:
            d = self.get(f"{self.base}/platforms", params={"key": self.c["key"], "page_size": 100})
        except HttpError as e:
            if e.status in (401, 403):
                return False, "RAWG rejected the API key"
            return False, f"Could not reach RAWG ({e})"
        self._platforms = d.get("results") or []
        return (True, "Key accepted") if self._platforms else (False, "RAWG returned no platforms")

    def prepare(self, systems):
        plats = getattr(self, "_platforms", None) or []
        cands = [(p["id"], [p.get("name")]) for p in plats if "id" in p]
        for s in systems:
            pid = best_platform(s.names, cands)
            if pid:
                self.platform[s.canon] = pid

    def lookup(self, game):
        pid = self.platform.get(game.system.canon)
        if not pid:
            return None
        cand = score = None
        for q in game.search_titles:
            d = self.get(f"{self.base}/games", params={"key": self.c["key"], "search": q, "platforms": pid,
                                                       "page_size": 8, "search_precise": "true"})
            cands = [{"title": g.get("name", ""), "year": year_of(g.get("released")), "g": g}
                     for g in d.get("results") or []]
            cand, score = choose(game, cands, self.opts.min_score)
            if cand:
                break
        if not cand:
            return None
        g = cand["g"]
        m = new_match(self.id, g.get("id"), g.get("name", game.title), score)
        m["released"] = date_of(g.get("released"))
        m["year"] = year_of(m["released"])
        m["genre"] = ", ".join(x.get("name", "") for x in (g.get("genres") or [])[:2])
        if g.get("rating"):
            m["rating"] = round(float(g["rating"]) / 5.0, 3)
        if g.get("background_image") and "screenshot" in self.wants_media:
            m["media"]["screenshot"] = g["background_image"]
        need_detail = any(f in self.opts.fields for f in ("desc", "developer", "publisher"))
        if need_detail:
            try:
                det = self.get(f"{self.base}/games/{g['id']}", params={"key": self.c["key"]})
                m["desc"] = det.get("description_raw") or re.sub(r"<[^>]+>", " ", det.get("description") or "").strip()
                m["developer"] = ", ".join(x.get("name", "") for x in (det.get("developers") or [])[:1])
                m["publisher"] = ", ".join(x.get("name", "") for x in (det.get("publishers") or [])[:1])
            except HttpError:
                pass
        return m


# ----- Libretro thumbnails -------------------------------------------------- #

class Libretro(Service):
    id, name, site = "libretro", "Libretro Thumbnails", "https://thumbnails.libretro.com"
    blurb = "Box art, screenshots, title screens. No login. Matches by name (No-Intro style titles)."
    login = "none"
    base = "https://thumbnails.libretro.com"
    interval = 0.05
    supplies_media = ("boxart", "screenshot", "titlescreen", "logo")
    supplies_meta = False
    DIRS = {"boxart": "Named_Boxarts", "screenshot": "Named_Snaps", "titlescreen": "Named_Titles", "logo": "Named_Logos"}
    REGION_TAG = {"us": "USA", "eu": "Europe", "uk": "Europe", "jp": "Japan", "wor": "World", "fr": "France",
                  "de": "Germany", "es": "Spain", "it": "Italy", "br": "Brazil", "au": "Australia", "kr": "Korea"}

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.indexes, self.ilock = {}, threading.Lock()

    @staticmethod
    def _links(html):
        out = []
        for h in re.findall(r'href="([^"?#]+)"', html):
            h = urllib.parse.unquote(h)
            if h not in ("../", "/") and not h.startswith("/"):
                out.append(h)
        return out

    def check(self):
        try:
            html = http(self.base + "/", limiter=self.limiter, timeout=40)
        except HttpError as e:
            return False, f"Could not reach thumbnails.libretro.com ({e})"
        self._folders = [h.rstrip("/") for h in self._links(html) if h.endswith("/")]
        return (True, "Reachable") if self._folders else (False, "thumbnails.libretro.com returned no folders")

    def prepare(self, systems):
        folders = getattr(self, "_folders", None)
        if folders is None:
            ok, _ = self.check()
            folders = getattr(self, "_folders", [])
        lower = {f.lower(): f for f in folders}
        for s in systems:
            guess = LIBRETRO_GUESS.get(s.canon, "")
            if guess.lower() in lower:
                self.platform[s.canon] = lower[guess.lower()]
                continue
            hit = best_platform(s.names, [(f, [f.replace(" - ", " ")]) for f in folders], cutoff=0.8)
            if hit:
                self.platform[s.canon] = hit

    def index(self, folder, kind):
        """TitleIndex of every picture of one kind in one system folder."""
        key = (folder, kind)
        with self.ilock:
            if key in self.indexes:
                return self.indexes[key]
            idx = TitleIndex()
            try:
                url = f"{self.base}/{urllib.parse.quote(folder)}/{self.DIRS[kind]}/"
                html = http(url, limiter=self.limiter, timeout=120)
                for h in self._links(html):
                    if h.lower().endswith(".png"):
                        idx.add(h[:-4], h)
            except HttpError as e:
                if e.status not in (404, 403):
                    self.log(f"Libretro: could not list {folder}/{self.DIRS[kind]} ({e})")
            self.indexes[key] = idx
            return idx

    def pick_region(self, files):
        tags = [self.REGION_TAG[r] for r in self.regions if r in self.REGION_TAG]
        for t in tags:
            for f in files:
                if f"({t}" in f:
                    return f
        return files[0]

    def lookup(self, game):
        folder = self.platform.get(game.system.canon)
        if not folder:
            return None
        found, score, title = {}, 0.0, ""
        for kind in (k for k in self.DIRS if k in self.wants_media):
            files, s, _ = self.index(folder, kind).find(game.search_titles, self.opts.min_score)
            if files:
                f = self.pick_region(files)
                found[kind] = f"{self.base}/{urllib.parse.quote(folder)}/{self.DIRS[kind]}/{urllib.parse.quote(f)}"
                score = max(score, s)
                title = title or re.sub(r"\s*\([^)]*\)", "", f[:-4]).strip()
        if not found:
            return None
        m = new_match(self.id, next(iter(found.values())).rsplit("/", 1)[-1], title or game.title, score)
        m["media"] = found
        return m


# ----- LaunchBox Games Database --------------------------------------------- #

class LaunchBox(Service):
    id, name, site = "launchbox", "LaunchBox Games Database", "https://gamesdb.launchbox-app.com"
    blurb = "Descriptions, dates, box art and screenshots. No login - downloads one big metadata file (~100 MB) the first time."
    login = "none"
    meta_url = "https://gamesdb.launchbox-app.com/Metadata.zip"
    image_base = "https://images.launchbox-app.com/"
    interval = 0.05
    supplies_media = ("boxart", "screenshot", "titlescreen", "logo")
    IMG_TYPES = {"Box - Front": "boxart", "Screenshot - Gameplay": "screenshot",
                 "Screenshot - Game Title": "titlescreen", "Clear Logo": "logo", "Banner": "logo"}
    REGION_NAMES = {"us": "United States", "eu": "Europe", "uk": "United Kingdom", "jp": "Japan", "wor": "World"}

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.zip_path = APP_DIR / "launchbox_Metadata.zip"
        self.db = {}          # canon -> TitleIndex of game dicts

    def check(self):
        if self.zip_path.exists():
            return True, f"Using saved {self.zip_path.name}"
        try:
            http(self.meta_url, method="HEAD", timeout=30, retries=1)
        except HttpError as e:
            if e.status not in (405, 501):
                return False, f"Could not reach the LaunchBox database ({e})"
        return True, "Reachable"

    def _download(self):
        age_days = (time.time() - self.zip_path.stat().st_mtime) / 86400 if self.zip_path.exists() else 9999
        if age_days < 45:
            return
        self.log("LaunchBox: downloading Metadata.zip (this is a one-off, 100 MB or so)...")
        tmp = self.zip_path.with_name(self.zip_path.name + ".part")
        try:
            req = urllib.request.Request(self.meta_url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                total, last = 0, time.time()
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk or STOP.is_set():
                        break
                    f.write(chunk)
                    total += len(chunk)
                    BW.throttle(len(chunk))
                    if time.time() - last > 5:
                        self.log(f"LaunchBox: downloaded {human(total)}...")
                        last = time.time()
            if STOP.is_set():
                tmp.unlink()
                return
            os.replace(tmp, self.zip_path)
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            try:
                tmp.unlink()
            except OSError:
                pass
            if not self.zip_path.exists():
                raise HttpError(0, str(e), self.meta_url)
            self.log(f"LaunchBox: could not refresh the file ({e}); using the saved copy.")

    @staticmethod
    def _t(el, tag):
        v = el.findtext(tag)
        return v.strip() if v else ""

    def prepare(self, systems):
        try:
            self._download()
        except HttpError as e:
            self.dead = f"could not download the LaunchBox file ({e})"
            self.log("LaunchBox: " + self.dead)
            return
        if not self.zip_path.exists():
            return
        self.log("LaunchBox: reading the database (a minute or two for big systems)...")
        plat_memo = {}

        def canon_for(plat):
            if plat not in plat_memo:
                best, best_c = 0.0, None
                for s in systems:
                    for n in s.names:
                        sc = similarity(n, plat)
                        if sc > best:
                            best, best_c = sc, s.canon
                plat_memo[plat] = best_c if best >= 0.78 else None
            return plat_memo[plat]

        games, by_id, alts = {}, {}, {}
        tops = {"Game", "GameAlternateName", "GameImage"}
        try:
            with zipfile.ZipFile(self.zip_path) as z:
                name = next(n for n in z.namelist() if n.lower().endswith("metadata.xml"))
                for pass_no in (1, 2):
                    with z.open(name) as f:
                        root = None
                        for ev, el in ET.iterparse(f, events=("start", "end")):
                            if ev == "start":
                                if root is None:
                                    root = el
                                continue
                            if el.tag not in tops:
                                continue
                            if STOP.is_set():
                                return
                            if pass_no == 1 and el.tag == "Game":
                                c = canon_for(self._t(el, "Platform"))
                                if c:
                                    gid = self._t(el, "DatabaseID")
                                    g = {"id": gid, "title": self._t(el, "Name"), "desc": self._t(el, "Overview"),
                                         "released": date_of(self._t(el, "ReleaseDate")[:10]),
                                         "developer": self._t(el, "Developer"), "publisher": self._t(el, "Publisher"),
                                         "genre": ", ".join(x.strip() for x in self._t(el, "Genres").split(";")[:2] if x.strip()),
                                         "players": self._t(el, "MaxPlayers"), "rating": self._t(el, "CommunityRating"),
                                         "canon": c, "media": {}}
                                    g["year"] = year_of(g["released"])
                                    games.setdefault(c, []).append(g)
                                    by_id[gid] = g
                            elif pass_no == 1 and el.tag == "GameAlternateName":
                                alts.setdefault(self._t(el, "DatabaseID"), []).append(self._t(el, "AlternateName"))
                            elif pass_no == 2 and el.tag == "GameImage":
                                g = by_id.get(self._t(el, "DatabaseID"))
                                kind = self.IMG_TYPES.get(self._t(el, "Type"))
                                if g and kind and self._t(el, "FileName"):
                                    g["media"].setdefault(kind, []).append((self._t(el, "Region"), self._t(el, "FileName")))
                            if root is not None:
                                root.clear()
        except (zipfile.BadZipFile, ET.ParseError, StopIteration, OSError) as e:
            self.dead = f"could not read the LaunchBox file ({e}); delete {self.zip_path.name} to download it again"
            self.log("LaunchBox: " + self.dead)
            return
        for canon, lst in games.items():
            idx = TitleIndex()
            for g in lst:
                idx.add(g["title"], g)
                for a in alts.get(g["id"], []):
                    idx.add(a, g)
            self.db[canon] = idx
            self.platform[canon] = canon
        self.log(f"LaunchBox: {sum(len(v) for v in games.values()):,} games loaded for {len(games)} of your systems.")

    def lookup(self, game):
        idx = self.db.get(game.system.canon)
        if not idx:
            return None
        cands, s, _ = idx.find(game.search_titles, self.opts.min_score)
        if not cands:
            return None
        if game.year:
            cands = sorted(cands, key=lambda g: abs(g["year"] - game.year) if g["year"] else 50)
        g = cands[0]
        m = new_match(self.id, g["id"], g["title"], s)
        for k in ("desc", "released", "year", "developer", "publisher", "genre", "players"):
            m[k] = g[k]
        try:
            r = float(g["rating"])
            m["rating"] = round(r / 5.0, 3) if r > 0 else None
        except (TypeError, ValueError):
            pass
        pref = [self.REGION_NAMES.get(r, r) for r in self.regions]
        for kind, files in g["media"].items():
            if kind not in self.wants_media:
                continue
            choice = None
            for p in pref:
                choice = next((f for rg, f in files if rg.lower() == p.lower()), None)
                if choice:
                    break
            m["media"][kind] = self.image_base + (choice or files[0][1])
        return m


SERVICES = [ScreenScraper, TheGamesDB, IGDB, MobyGames, RAWG, Libretro, LaunchBox]
SERVICE_BY_ID = {s.id: s for s in SERVICES}
SERVICE_FIELDS.update({s.id: [f[0] for f in s.fields] for s in SERVICES})


# --------------------------------------------------------------------------- #
# Finding games
# --------------------------------------------------------------------------- #

def is_media_dir(name):
    return name.lower() in MEDIA_DIRS or name.startswith(".")


def find_systems(folders, log=print, depth=4):
    """Walk the chosen folders and return the System folders found inside them."""
    found, seen = [], set()

    def visit(p, level):
        try:
            real = p.resolve()
        except OSError:
            return
        if real in seen:
            return
        seen.add(real)
        res = resolve_system(p.name)
        if res and not is_media_dir(p.name) and p.name.lower() not in REASON_DIRS:
            found.append(System(res[0], res[1], p.name, p))
            return
        if level >= depth:
            return
        try:
            subs = sorted(d for d in p.iterdir() if d.is_dir() and not is_media_dir(d.name))
        except OSError:
            return
        for d in subs:
            visit(d, level + 1)

    for f in folders:
        p = Path(f)
        if p.is_dir():
            visit(p, 0)
        else:
            log(f"Folder not found: {f}")
    return found


def iter_roms(system):
    for dp, dns, fns in os.walk(system.path):
        dns[:] = sorted(d for d in dns if not is_media_dir(d))
        for fn in sorted(fns):
            if fn.startswith(".") or Path(fn).suffix.lower() in JUNK_EXT or fn.lower() == "gamelist.xml":
                continue
            yield Path(dp) / fn


def count_roms(system):
    n = 0
    for _ in iter_roms(system):
        n += 1
    system.files = n
    return n


# --------------------------------------------------------------------------- #
# What has been scraped so far (lets a run be stopped and resumed)
# --------------------------------------------------------------------------- #

class Manifest:
    def __init__(self, path=None):
        self.path, self.lock = Path(path or MANIFEST), threading.RLock()
        self.data = {"version": 1, "games": {}}
        self.dirty = 0
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(d.get("games"), dict):
                self.data = d
        except (OSError, ValueError):
            pass
        self.by_name = {}
        for k, e in self.data["games"].items():
            self.by_name.setdefault((e.get("system"), e.get("name")), k)

    def get(self, game):
        with self.lock:
            e = self.data["games"].get(game.key_abs)
            if e is None:                       # file moved (e.g. by the sorter): find it by name
                k = self.by_name.get((game.system.canon, game.path.name))
                e = self.data["games"].get(k) if k else None
            return e

    def put(self, game, entry):
        with self.lock:
            self.data["games"][game.key_abs] = entry
            self.by_name[(game.system.canon, game.path.name)] = game.key_abs
            self.dirty += 1
            if self.dirty >= 100:
                self.save()

    def save(self):
        with self.lock:
            try:
                atomic_write(self.path, json.dumps(self.data, ensure_ascii=False, separators=(",", ":")))
                self.dirty = 0
            except OSError:
                pass

    def for_system(self, system):
        base = str(system.path)
        with self.lock:
            return [(k, e) for k, e in self.data["games"].items()
                    if e.get("status") == "ok" and e.get("system_path") == base]


Game.key_abs = property(lambda self: str(self.path))


# --------------------------------------------------------------------------- #
# Saving pictures
# --------------------------------------------------------------------------- #

CDN_LIMITER = RateLimiter(0.08)


def sniff(data):
    """File extension from the first bytes, or '' if it doesn't look like media."""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    if data[4:8] == b"ftyp":
        return "mp4"
    if data[:4] == b"\x1aE\xdf\xa3":
        return "webm"
    return ""


def fetch_media(url, max_bytes):
    """Download up to max_bytes. Returns bytes; raises HttpError."""
    delay = 2.0
    for attempt in range(3):
        if STOP.is_set():
            raise HttpError(0, "stopped", url)
        CDN_LIMITER.wait()
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                length = int(r.headers.get("Content-Length") or 0)
                if length and length > max_bytes:
                    raise HttpError(413, "file too large", url)
                chunks, total = [], 0
                while True:
                    c = r.read(1 << 16)
                    if not c:
                        break
                    total += len(c)
                    if total > max_bytes:
                        raise HttpError(413, "file too large", url)
                    chunks.append(c)
                    BW.throttle(len(c))
                    if STOP.is_set():
                        raise HttpError(0, "stopped", url)
                return b"".join(chunks)
        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503, 504) and attempt < 2:
                time.sleep(delay)
                delay *= 2
                continue
            raise HttpError(e.code, "", url)
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            if attempt < 2:
                time.sleep(delay)
                delay *= 2
                continue
            raise HttpError(0, str(e), url)
    raise HttpError(0, "gave up", url)


class Layout:
    """Where pictures and lists go for the chosen output format."""

    # kind -> (folder, file name suffix, gamelist tag)
    ES_NAMES = {"boxart": ("images", "thumb", "thumbnail"), "screenshot": ("images", "image", "image"),
                "logo": ("images", "marquee", "marquee"), "titlescreen": ("images", "titlescreen", None),
                "video": ("videos", "video", "video")}
    RECALBOX_NAMES = {"boxart": ("media/thumbnails", "", "thumbnail"), "screenshot": ("media/images", "", "image"),
                      "logo": ("media/marquees", "", "marquee"), "titlescreen": ("media/titles", "", None),
                      "video": ("media/videos", "", "video")}
    ESDE_DIRS = {"boxart": "covers", "screenshot": "screenshots", "titlescreen": "titlescreens",
                 "logo": "marquees", "video": "videos"}

    def __init__(self, opts):
        self.fmt = opts.format
        self.out = Path(opts.output_dir).expanduser() if opts.output_dir else None
        # where ES-DE / generic output goes when no output folder is chosen:
        # beside the ROMs being scraped, never inside the app's install folder
        first = next((f for f in (opts.folders or []) if f), None)
        self.home = Path(first).expanduser() if first else Path.home()

    @property
    def table(self):
        return self.RECALBOX_NAMES if self.fmt == "recalbox" else self.ES_NAMES

    def media_path(self, game, kind, ext):
        s = game.system
        rel = Path(game.rel)
        stem_rel = rel.with_suffix("") if rel.suffix else rel
        if self.fmt in ("emulationstation", "recalbox"):
            base = (self.out / s.folder) if self.out else s.path
            folder, suffix, _ = self.table[kind]
            return base / folder / (safe_name(rel.stem) + (f"-{suffix}" if suffix else "") + f".{ext}")
        if self.fmt == "esde":
            base = (self.out or self.home) / "ES-DE" / "downloaded_media" / s.folder / self.ESDE_DIRS[kind]
            return base / stem_rel.parent / f"{safe_name(rel.stem)}.{ext}"
        base = (self.out or self.home) / "rom_scraper_media" / s.folder / kind
        return base / stem_rel.parent / f"{safe_name(rel.stem)}.{ext}"

    def gamelist_path(self, system):
        if self.fmt in ("emulationstation", "recalbox"):
            return ((self.out / system.folder) if self.out else system.path) / "gamelist.xml"
        if self.fmt == "esde":
            return (self.out or self.home) / "ES-DE" / "gamelists" / system.folder / "gamelist.xml"
        return None

    def gamelist_media_ref(self, system, kind, path):
        """(tag, text) for <image>/<thumbnail>/... : relative to the gamelist folder."""
        gl = self.gamelist_path(system)
        if not gl or self.fmt not in ("emulationstation", "recalbox"):
            return None
        tag = self.table[kind][2]
        if not tag:
            return None
        try:
            return tag, "./" + Path(path).relative_to(gl.parent).as_posix()
        except ValueError:
            return tag, str(path)


# --------------------------------------------------------------------------- #
# Working out which frontend the folders are set up for
# --------------------------------------------------------------------------- #

FRONTENDS = {"batocera": "Batocera", "retropie": "RetroPie", "recalbox": "Recalbox", "esde": "ES-DE",
             "mister": "MiSTer", "tosec": "plain TOSEC folder names"}
FRONTEND_FORMAT = {"batocera": "emulationstation", "retropie": "emulationstation", "recalbox": "recalbox",
                   "esde": "esde", "mister": "json", "tosec": "emulationstation"}
PATH_HINTS = {"batocera": ("batocera", "/userdata/roms", "\\userdata\\roms"), "recalbox": ("recalbox",),
              "retropie": ("retropie",), "esde": ("es-de", "es_de", "emudeck", "es-de/roms"),
              "mister": ("mister", "/media/fat/games")}


def detect_frontend(systems, folders):
    """Guess the frontend from folder names, the path, and files already there.
    -> {'frontend', 'name', 'format', 'reason', 'sure'}"""
    tables = {"batocera": BATOCERA, "retropie": RETROPIE, "recalbox": RECALBOX, "esde": ESDE, "mister": MISTER}
    score = {k: 0.0 for k in FRONTENDS}
    notes = {k: [] for k in FRONTENDS}
    users = {}
    for k, t in tables.items():
        for v in t.values():
            users.setdefault(v.lower(), set()).add(k)
    for s in systems:
        u = users.get(s.folder.lower())
        if u:
            for k in u:
                score[k] += 1.0 / len(u)
        else:
            score["tosec"] += 1.0
    for k in tables:
        if score[k] >= 1:
            notes[k].append(f"{score[k]:.0f} folder name(s) match its names")
    if score["tosec"] >= max(1, len(systems) / 2):
        notes["tosec"].append("folders keep their TOSEC names")
    paths = [str(Path(f).resolve()).lower().replace("\\", "/") for f in folders if Path(f).exists()]
    for k, words in PATH_HINTS.items():
        if any(w.replace("\\", "/") in p for p in paths for w in words):
            score[k] += 50
            notes[k].append("the folder path says so")
    for f in folders:
        p = Path(f).resolve()
        for anc in [p] + list(p.parents)[:3]:
            if (anc / "downloaded_media").is_dir() or (anc / "gamelists").is_dir() and anc.name.lower() == "es-de":
                score["esde"] += 40
                notes["esde"].append("a downloaded_media folder is next to the ROMs")
                break
    for s in systems:
        try:
            gl = s.path / "gamelist.xml"
            text = gl.read_text(encoding="utf-8", errors="ignore")[:20000] if gl.exists() else ""
        except OSError:
            text = ""
        if "./media/" in text or (s.path / "media").is_dir():
            score["recalbox"] += 3
            notes["recalbox"].append("a media folder / gamelist references ./media")
        if "./images/" in text or (s.path / "images").is_dir() or (s.path / "videos").is_dir():
            score["batocera"] += 1
            score["retropie"] += 1
            notes["batocera"].append("images/videos folders already there")
    best = max(score, key=lambda k: (score[k], k != "tosec"))
    if score[best] < 1:
        return {"frontend": "tosec", "name": FRONTENDS["tosec"], "format": "emulationstation", "sure": False,
                "reason": "no clear frontend found, using the common EmulationStation layout"}
    reason = "; ".join(dict.fromkeys(notes[best])) or "best match"
    sure = score[best] >= 5 or len(systems) <= 2 and score[best] >= 1
    return {"frontend": best, "name": FRONTENDS[best], "format": FRONTEND_FORMAT[best], "sure": sure, "reason": reason}


def indent_xml(elem, level=0):
    if hasattr(ET, "indent"):
        ET.indent(elem, space="\t")
        return
    pad = "\n" + level * "\t"
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = pad + "\t"
        for child in elem:
            indent_xml(child, level + 1)
            if not child.tail or not child.tail.strip():
                child.tail = pad + "\t"
        child.tail = pad
    elif level and (not elem.tail or not elem.tail.strip()):
        elem.tail = pad


def es_date(entry):
    d = entry.get("released") or (str(entry["year"]) if entry.get("year") else "")
    m = re.match(r"^(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?", d or "")
    if not m:
        return ""
    return f"{m.group(1)}{m.group(2) or '01'}{m.group(3) or '01'}T000000"


def write_gamelist(system, entries, layout, opts, log):
    """Create or update gamelist.xml for one system. Existing entries and tags are kept."""
    path = layout.gamelist_path(system)
    if not path or not entries:
        return None
    root = None
    if path.exists():
        try:
            root = ET.parse(path).getroot()
            bak = path.with_name(path.name + ".rom_scraper.bak")
            if not bak.exists():
                shutil.copy2(path, bak)
        except (ET.ParseError, OSError):
            log(f"  Could not read the existing {path.name} for {system.folder}; it was left alone as .unreadable")
            try:
                os.replace(path, path.with_name(path.name + ".unreadable"))
            except OSError:
                pass
            root = None
    if root is None or root.tag != "gameList":
        root = ET.Element("gameList")
    by_path = {}
    for g in root.findall("game"):
        p = (g.findtext("path") or "").strip()
        if p:
            by_path[p.replace("\\", "/")] = g

    def put(g, tag, value, overwrite):
        if value in (None, ""):
            return
        el = g.find(tag)
        if el is None:
            el = ET.SubElement(g, tag)
        elif (el.text or "").strip() and not overwrite:
            return
        el.text = str(value)

    for e in entries:
        ref = "./" + e["rel"]
        g = by_path.get(ref) or by_path.get(e["rel"])
        if g is None:
            g = ET.SubElement(root, "game")
            ET.SubElement(g, "path").text = ref
        om = opts.overwrite_meta
        put(g, "name", e.get("title"), om)
        put(g, "desc", e.get("desc"), om)
        if e.get("rating") is not None:
            put(g, "rating", f"{float(e['rating']):.2f}", om)
        put(g, "releasedate", es_date(e), om)
        put(g, "developer", e.get("developer"), om)
        put(g, "publisher", e.get("publisher"), om)
        put(g, "genre", e.get("genre"), om)
        put(g, "players", e.get("players"), om)
        media = dict(e.get("media") or {})
        if "screenshot" not in media and "titlescreen" in media:     # no screenshot: use the title screen
            media["screenshot"] = media["titlescreen"]
        for kind, p in media.items():
            ref2 = layout.gamelist_media_ref(system, kind, p)
            if ref2 and Path(p).exists():
                put(g, ref2[0], ref2[1], opts.overwrite_media)
    indent_xml(root)
    tmp = path.with_name(path.name + ".part")
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(tmp, encoding="utf-8", xml_declaration=True)
    os.replace(tmp, path)
    return path


# --------------------------------------------------------------------------- #
# Asking for logins
# --------------------------------------------------------------------------- #

class CliBroker:
    """Asks on the terminal (or skips the service when nobody is there to ask)."""

    def __init__(self, creds):
        self.creds = creds

    def ask(self, svc, reason, current):
        if not sys.stdin or not sys.stdin.isatty():
            print(f"{svc.name}: {reason}. Set environment variables "
                  + ", ".join(f"ROM_SCRAPER_{svc.id}_{f[0]}".upper() for f in svc.fields if f[3])
                  + " (or run from a terminal to be asked). Skipping.")
            return None
        print(f"\n{svc.name} needs a login ({reason}). {svc.site}")
        vals = dict(current)
        for key, label, secret, required, help_ in svc.fields:
            if help_:
                print(f"  {help_}")
            prompt = f"  {label}{'' if required else ' (optional)'}"
            if vals.get(key):
                prompt += " [Enter keeps the saved value]"
            prompt += ": "
            try:
                v = (getpass.getpass(prompt) if secret else input(prompt)).strip()
            except (EOFError, KeyboardInterrupt):
                return None
            if v:
                vals[key] = v
            elif required and not vals.get(key):
                return None
        try:
            remember = input("  Remember this login in rom_scraper_credentials.json? [y/N]: ").strip().lower() == "y"
        except (EOFError, KeyboardInterrupt):
            remember = False
        self.creds.set(svc.id, vals, remember)
        return vals


def connect_services(opts, creds, broker, log, systems):
    """Create the chosen services in priority order, getting and testing logins first."""
    ready = []
    for sid in opts.services:
        cls = SERVICE_BY_ID.get(sid)
        if not cls:
            continue
        svc = cls(creds, opts, log)
        reason, attempts = "", 0
        while True:
            if STOP.is_set():
                return ready
            if svc.missing() or reason:
                if not svc.fields:
                    log(f"{svc.name}: {reason}. Skipping.")
                    svc = None
                    break
                vals = broker.ask(svc, reason or "login needed", svc.c)
                if vals is None:
                    log(f"{svc.name}: no login given - skipping this service.")
                    svc = None
                    break
                svc.set_credentials(vals)
            log(f"{svc.name}: checking...")
            try:
                ok, msg = svc.check()
            except Exception as e:
                ok, msg = False, f"{type(e).__name__}: {e}"
            if ok:
                log(f"{svc.name}: {msg}")
                break
            reason = msg
            attempts += 1
            log(f"{svc.name}: {msg}")
            if attempts >= 4 or not svc.fields:
                log(f"{svc.name}: giving up - skipping this service.")
                svc = None
                break
        if svc is None:
            continue
        try:
            svc.prepare(systems)
        except (CredentialError, QuotaError) as e:
            log(f"{svc.name}: {e} - skipping this service.")
            continue
        except HttpError as e:
            log(f"{svc.name}: could not load its system list ({e}) - skipping this service.")
            continue
        if svc.dead:
            continue
        have = [s.label for s in systems if svc.supports(s)]
        log(f"{svc.name}: ready, knows {len(have)} of your {len(systems)} system(s)."
            + (f" Not covered: {', '.join(s.label for s in systems if not svc.supports(s))}" if len(have) < len(systems) else ""))
        ready.append(svc)
    return ready


# --------------------------------------------------------------------------- #
# The scrape itself
# --------------------------------------------------------------------------- #

def missing_fields(entry, want):
    out = []
    for f in want:
        if f == "rating":
            if entry.get("rating") is None:
                out.append(f)
        elif f == "year":
            if not entry.get("released") and not entry.get("year"):
                out.append(f)
        elif not entry.get(f):
            out.append(f)
    return out


def scrape_one(game, services, opts, layout, manifest, cache, cache_lock, log):
    """Look one game up, save its pictures. Returns (result, entry, note)."""
    old = manifest.get(game)
    wants_media = [m for m in opts.media]
    entry = {"status": "missing", "system": game.system.canon, "system_path": str(game.system.path),
             "name": game.path.name, "rel": game.rel, "title": "", "desc": "", "year": 0, "released": "",
             "developer": "", "publisher": "", "genre": "", "players": "", "rating": None,
             "media": {}, "sources": {}, "score": 0.0, "tried_media": [], "tried_fields": []}
    if old and old.get("status") == "ok":
        entry.update({k: v for k, v in old.items() if k in entry})
        entry["media"] = dict(old.get("media") or {})
        entry["sources"] = dict(old.get("sources") or {})
        entry["system_path"], entry["rel"], entry["name"] = str(game.system.path), game.rel, game.path.name
        entry["status"] = "ok"
        # pictures saved in another format (or deleted): copy / re-fetch below
        for kind, p in list(entry["media"].items()):
            if not Path(p).exists():
                del entry["media"][kind]
                entry["tried_media"] = [t for t in entry["tried_media"] if t != kind]
    todo_media = [m for m in wants_media if m not in entry["media"] and m not in entry["tried_media"]]
    todo_fields = [f for f in opts.fields if f in missing_fields(entry, [f]) and f not in entry["tried_fields"]]
    urls, notes = {}, []
    if not old or old.get("status") != "ok":
        todo_media, todo_fields = list(wants_media), list(opts.fields)
    used = []
    remaining_media, remaining_fields = set(todo_media), set(todo_fields)
    for svc in services:
        if not remaining_media and not remaining_fields:
            break
        if svc.dead or not svc.supports(game.system):
            continue
        adds_media = remaining_media & set(svc.supplies_media)
        adds_meta = svc.supplies_meta and remaining_fields
        if not adds_media and not adds_meta:
            continue
        ckey = (svc.id, game.system.canon, norm(game.title), game.year)
        with cache_lock:
            hit = cache.get(ckey, "unset")
        if hit == "unset":
            try:
                with svc.sem:
                    hit = svc.lookup(game)
            except (CredentialError, QuotaError) as e:
                svc.dead = svc.dead or str(e)
                log(f"{svc.name}: {e} - switched off for the rest of this run.")
                hit = None
            except HttpError as e:
                if e.status == 0 and e.body == "stopped":
                    break
                notes.append(f"{svc.name}: {e}")
                hit = None
            except Exception as e:                       # one odd reply must not stop the run
                notes.append(f"{svc.name}: {type(e).__name__}: {e}")
                hit = None
            else:
                with cache_lock:
                    cache[ckey] = hit
        m = hit
        if not m:
            continue
        got = []
        if not entry["title"]:
            entry["title"], entry["score"] = m["title"], m["score"]
        for f in list(remaining_fields):
            if svc.supplies_meta:
                if f == "year":
                    if m["released"] or m["year"]:
                        entry["released"], entry["year"] = m["released"], m["year"]
                        entry["sources"][f] = svc.id
                        remaining_fields.discard(f)
                        got.append(f)
                elif f == "rating":
                    if m["rating"] is not None:
                        entry["rating"] = m["rating"]
                        entry["sources"][f] = svc.id
                        remaining_fields.discard(f)
                        got.append(f)
                elif m.get(f):
                    entry[f] = m[f]
                    entry["sources"][f] = svc.id
                    remaining_fields.discard(f)
                    got.append(f)
        for kind in list(remaining_media):
            if kind in m["media"] and kind not in urls:
                urls[kind] = m["media"][kind]
                entry["sources"][kind] = svc.id
                remaining_media.discard(kind)
                got.append(kind)
        if got:
            used.append(svc.id)
    entry["tried_media"] = sorted(set(entry["tried_media"]) | set(todo_media))
    entry["tried_fields"] = sorted(set(entry["tried_fields"]) | set(todo_fields))
    found_any = bool(urls) or any(entry.get(f) not in ("", None, 0) for f in ("desc", "developer", "publisher", "genre", "players", "rating", "released"))
    if entry["status"] != "ok" and not found_any and not entry["media"]:
        return "Not found", entry, "; ".join(notes) or "No service had this game"
    entry["status"] = "ok"
    saved = []
    if not opts.dry_run:
        for kind, url in urls.items():
            try:
                cap = (opts.video_max_mb if kind == "video" else 40) * 1048576
                data = fetch_media(url, cap)
                ext = sniff(data)
                if not ext or (kind == "video") != (ext in ("mp4", "webm")):
                    notes.append(f"{kind}: not a valid {'video' if kind == 'video' else 'picture'}")
                    continue
                dest = layout.media_path(game, kind, ext)
                if dest.exists() and not opts.overwrite_media:
                    entry["media"][kind] = str(dest)
                    continue
                atomic_write(dest, data, binary=True)
                entry["media"][kind] = str(dest)
                saved.append(kind)
            except HttpError as e:
                if e.status == 0 and e.body == "stopped":
                    break
                notes.append(f"{kind}: download failed ({e})")
        # same pictures wanted in a different layout: copy the files that already exist
        if old and old.get("status") == "ok":
            for kind, p in (old.get("media") or {}).items():
                if kind in entry["media"] and Path(entry["media"][kind]).exists():
                    want = layout.media_path(game, kind, Path(entry["media"][kind]).suffix.lstrip(".") or "png")
                    if str(want) != entry["media"][kind] and not want.exists():
                        try:
                            want.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(entry["media"][kind], want)
                            entry["media"][kind] = str(want)
                        except OSError as e:
                            notes.append(f"copy {kind}: {e}")
    entry["format"] = opts.format
    entry["when"] = datetime.datetime.now().isoformat(timespec="seconds")
    result = "Scraped" if (used or saved) else "Up to date"
    return result, entry, "; ".join(notes)


def run(opts, creds, broker, log=print, progress=lambda n, t: None, systems=None):
    """Scrape everything the options describe. Returns a summary dict."""
    opts = copy.copy(opts).normalise()
    STOP.clear()
    PAUSED.clear()
    summary = {"games": 0, "scraped": 0, "uptodate": 0, "notfound": 0, "skipped": 0, "errors": 0,
               "media": 0, "report": None}
    if systems is None:
        systems = find_systems(opts.folders, log)
    if opts.systems is not None:
        chosen = set(opts.systems)
        systems = [s for s in systems if str(s.path) in chosen]
    if not systems:
        log("No known system folders were found in the chosen folders.")
        return summary
    log(f"{len(systems)} system folder(s) to scrape.")
    if not opts.services:
        log("No services selected.")
        return summary
    services = connect_services(opts, creds, broker, log, systems)
    if not services:
        log("None of the selected services could be used.")
        return summary
    log("Services in priority order: " + " > ".join(s.name for s in services))

    if opts.format == "auto":
        det = detect_frontend(systems, opts.folders)
        opts.format = det["format"]
        log(f"Folder layout looks like {det['name']} ({det['reason']}"
            + ("" if det["sure"] else "; not certain - change it on the 'What to save' tab if wrong")
            + f"). Saving as: {FORMATS[opts.format]}")
    BW.configure(opts.limit_kbps, opts.schedule, opts.schedule_on)
    log("Download speed: " + BW.current()[2]
        + (f" (+ {len(BW.rules)} schedule rule(s))" if opts.schedule_on and BW.rules else ""))
    layout = Layout(opts)
    manifest = Manifest()
    PAUSE_HOOK["fn"] = manifest.save
    games = []
    for s in systems:
        for p in iter_roms(s):
            games.append(Game(p, s, s.path))
    total = len(games)
    log(f"{total:,} file(s) to look at.")
    if opts.dry_run:
        log("DRY RUN: looking games up, but saving no pictures, lists or progress.")

    cache, cache_lock = {}, threading.Lock()
    rows, rows_lock = [], threading.Lock()
    done = 0

    def work(g):
        wait_if_paused()
        if STOP.is_set():
            return "Skipped", None, "Stopped"
        old = manifest.get(g)
        if old and opts.skip_done:
            if old.get("status") == "missing" and not opts.retry_missing:
                return "Skipped", None, "Not found last time (tick 'look again for games not found')"
            if old.get("status") == "ok" and old.get("format") == opts.format:
                want_new = [m for m in opts.media if m not in (old.get("media") or {}) and m not in old.get("tried_media", [])]
                want_f = [f for f in opts.fields if f in missing_fields(old, [f]) and f not in old.get("tried_fields", [])]
                gone = [m for m, p in (old.get("media") or {}).items() if not Path(p).exists()]
                if not want_new and not want_f and not gone:
                    return "Skipped", old, "Already scraped"
        return scrape_one(g, services, opts, layout, manifest, cache, cache_lock, log)

    pool = ThreadPoolExecutor(max_workers=opts.workers)
    futs = {pool.submit(work, g): g for g in games}
    try:
        for fut in as_completed(futs):
            g = futs[fut]
            try:
                result, entry, note = fut.result()
            except Exception as e:
                result, entry, note = "Error", None, f"{type(e).__name__}: {e}"
                log(f"ERROR on {g.path.name}: {note}")
            done += 1
            summary["games"] += 1
            key = {"Scraped": "scraped", "Up to date": "uptodate", "Not found": "notfound",
                   "Skipped": "skipped", "Error": "errors"}[result]
            summary[key] += 1
            if entry is not None and result in ("Scraped", "Up to date", "Not found") and not opts.dry_run:
                manifest.put(g, entry)
            if entry and result in ("Scraped", "Up to date"):
                summary["media"] += len(entry.get("media") or {})
            with rows_lock:
                rows.append([result, g.system.label, g.rel, (entry or {}).get("title", ""),
                             ",".join(sorted({v for v in ((entry or {}).get("sources") or {}).values()})),
                             (entry or {}).get("score", ""), ",".join(sorted((entry or {}).get("media") or {})), note])
            if done % 10 == 0 or done == total:
                progress(done, total)
            if STOP.is_set():
                log("Stopping...")
                for f in futs:
                    f.cancel()
                break
    finally:
        try:
            pool.shutdown(wait=True, cancel_futures=True)
        except TypeError:                      # Python 3.8
            pool.shutdown(wait=True)
    if not opts.dry_run:
        manifest.save()
        if opts.format in ("emulationstation", "recalbox", "esde"):
            for s in systems:
                entries = [dict(e, rel=e.get("rel", "")) for _, e in manifest.for_system(s)]
                entries = [e for e in entries if e.get("rel")]
                try:
                    p = write_gamelist(s, entries, layout, opts, log)
                    if p:
                        log(f"Wrote {p}")
                except OSError as e:
                    log(f"Could not write the gamelist for {s.folder}: {e}")
    summary["bytes"] = BW.total
    summary["format"] = opts.format
    PAUSE_HOOK["fn"] = None
    log(f"Done. {summary['scraped']:,} scraped, {summary['uptodate']:,} already complete, "
        f"{summary['notfound']:,} not found, {summary['skipped']:,} skipped, {summary['errors']:,} errors.")
    if opts.write_csv and rows:
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        rep_dir = Path(opts.output_dir).expanduser() if opts.output_dir else (
            Path(opts.folders[0]).expanduser() if opts.folders else APP_DIR)
        try:
            rep_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            rep_dir = APP_DIR
        path = rep_dir / f"rom_scraper_report_{stamp}.csv"
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["Result", "System", "File", "Matched title", "Services", "Match score", "Pictures", "Note"])
                w.writerows(sorted(rows, key=lambda r: (r[1], r[2])))
            summary["report"] = path
            log(f"Report written: {path.name}")
        except OSError as e:
            log(f"Could not write the report: {e}")
    elif not opts.write_csv:
        log("CSV report skipped (turned off).")
    return summary


# --------------------------------------------------------------------------- #
# Window
# --------------------------------------------------------------------------- #

if tk is not None:

    class LoginDialog:
        """Asks for one service's login / key, can test it, and can remember it."""

        def __init__(self, win, svc, reason, current, creds):
            self.svc, self.creds, self.result = svc, creds, None
            self.top = tk.Toplevel(win)
            self.top.title(f"{svc.name} login")
            self.top.transient(win)
            self.top.resizable(False, False)
            f = ttk.Frame(self.top, padding=14)
            f.pack(fill="both", expand=True)
            ttk.Label(f, text=f"{svc.name} needs a login", font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
            ttk.Label(f, text=svc.site, foreground="gray").pack(anchor="w")
            if reason:
                ttk.Label(f, text=reason, foreground="#b00020", wraplength=430).pack(anchor="w", pady=(6, 0))
            self.vars = {}
            grid = ttk.Frame(f)
            grid.pack(fill="x", pady=8)
            for i, (key, label, secret, required, help_) in enumerate(svc.fields):
                ttk.Label(grid, text=label + ("" if required else " (optional)")).grid(row=i * 2, column=0, sticky="w", pady=(6, 0))
                v = tk.StringVar(value=current.get(key, ""))
                self.vars[key] = v
                ttk.Entry(grid, textvariable=v, width=46, show="*" if secret else "").grid(row=i * 2, column=1, padx=8, pady=(6, 0))
                if help_:
                    ttk.Label(grid, text=help_, foreground="gray", wraplength=430).grid(row=i * 2 + 1, column=0, columnspan=2, sticky="w")
            self.remember = tk.BooleanVar(value=svc.id in creds.remember)
            ttk.Checkbutton(f, variable=self.remember,
                            text="Remember this on this computer (saved as plain text in rom_scraper_credentials.json)").pack(anchor="w")
            self.msg = ttk.Label(f, text="", wraplength=430)
            self.msg.pack(anchor="w", pady=(6, 0))
            bt = ttk.Frame(f)
            bt.pack(fill="x", pady=(8, 0))
            self.b_test = ttk.Button(bt, text="Test login", command=self.test)
            self.b_test.pack(side="left")
            ttk.Button(bt, text="Cancel (skip this service)", command=self.top.destroy).pack(side="right")
            ttk.Button(bt, text="Save", command=self.save).pack(side="right", padx=6)
            self.top.protocol("WM_DELETE_WINDOW", self.top.destroy)
            self.top.update_idletasks()
            self.top.grab_set()

        def values(self):
            return {k: v.get().strip() for k, v in self.vars.items()}

        def test(self):
            vals = self.values()
            self.msg.config(text="Testing...", foreground="gray")
            self.b_test.state(["disabled"])
            probe = type(self.svc)(self.creds, self.svc.opts, lambda m: None)
            probe.set_credentials(vals)

            def work():
                if probe.missing():
                    ok, text = False, "Fill in the required boxes first."
                else:
                    try:
                        ok, text = probe.check()
                    except Exception as e:
                        ok, text = False, f"{type(e).__name__}: {e}"
                self.top.after(0, lambda: self.done(ok, text))
            threading.Thread(target=work, daemon=True).start()

        def done(self, ok, text):
            try:
                self.msg.config(text=("Works: " if ok else "Failed: ") + text, foreground="#1b7f3b" if ok else "#b00020")
                self.b_test.state(["!disabled"])
            except tk.TclError:
                pass

        def save(self):
            vals = self.values()
            miss = [f[1] for f in self.svc.fields if f[3] and not vals.get(f[0])]
            if miss:
                self.msg.config(text="Still needed: " + ", ".join(miss), foreground="#b00020")
                return
            self.creds.set(self.svc.id, vals, self.remember.get())
            self.result = vals
            self.top.destroy()


    class GuiBroker:
        """Lets the worker thread ask the window for a login and wait for the answer."""

        def __init__(self, app):
            self.app = app

        def ask(self, svc, reason, current):
            reply = queue.Queue()
            self.app.q.put(("ask", svc, reason, current, reply))
            while True:
                try:
                    return reply.get(timeout=0.5)
                except queue.Empty:
                    if STOP.is_set():
                        return None


    class App:
        def __init__(self, win):
            self.win = win
            self.q = queue.Queue()
            self.busy = False
            self.creds = Credentials()
            self.broker = GuiBroker(self)
            self.systems = []
            self.sys_tick = {}
            self.scan_id = 0
            win.title("ROM Scraper - created by normanlove")
            win.geometry("1000x860")
            frm = ttk.Frame(win, padding=10)
            frm.pack(fill="both", expand=True)
            self.nb = ttk.Notebook(frm)
            self.nb.pack(fill="both", expand=True)
            self.o = Options.load()
            self.build_folders_tab()
            self.build_services_tab()
            self.build_save_tab()
            self.build_speed_tab()

            bt = ttk.Frame(frm)
            bt.pack(fill="x", pady=8)
            self.b_dry = ttk.Button(bt, text="Dry run (looks up, saves nothing)", command=lambda: self.start(True))
            self.b_run = ttk.Button(bt, text="Scrape", command=lambda: self.start(False))
            self.b_pause = ttk.Button(bt, text="Pause", command=self.toggle_pause)
            self.b_stop = ttk.Button(bt, text="Stop", command=self.request_stop)
            for b in (self.b_run, self.b_dry, self.b_pause, self.b_stop):
                b.pack(side="left", padx=(0, 8))
            self.b_stop.state(["disabled"])
            self.b_pause.state(["disabled"])
            self.bar = ttk.Progressbar(frm, mode="determinate")
            self.bar.pack(fill="x")
            self.speed_label = ttk.Label(frm, text="", font=("TkFixedFont", 10))
            self.speed_label.pack(anchor="w", pady=(4, 0))
            self.prog, self.t0, self.last_status = (0, 0), time.time(), 0.0
            box = ttk.Frame(frm)
            box.pack(fill="both", expand=True, pady=(8, 0))
            sb = ttk.Scrollbar(box)
            sb.pack(side="right", fill="y")
            self.text = tk.Text(box, height=11, wrap="word", state="disabled", yscrollcommand=sb.set)
            self.text.pack(side="left", fill="both", expand=True)
            sb.config(command=self.text.yview)

            self.apply(self.o)
            self.log("ROM Scraper - created by normanlove.")
            self.log("Add your ROM folders, tick the services you want, then Scrape. "
                     "Services that need a login will ask for it first.")
            win.protocol("WM_DELETE_WINDOW", self.close)
            win.after(100, self.poll)
            self.rescan()

        # ---- tab 1: folders and systems ----
        def build_folders_tab(self):
            t = ttk.Frame(self.nb, padding=10)
            self.nb.add(t, text="1. Folders")
            ttk.Label(t, text="Folders to scrape (every system folder inside them is found automatically):").pack(anchor="w")
            row = ttk.Frame(t)
            row.pack(fill="x", pady=4)
            self.lb = tk.Listbox(row, height=5, selectmode="extended")
            self.lb.pack(side="left", fill="x", expand=True)
            col = ttk.Frame(row)
            col.pack(side="left", padx=8)
            ttk.Button(col, text="Add folder...", command=self.add_folder).pack(fill="x")
            ttk.Button(col, text="Remove", command=self.remove_folder).pack(fill="x", pady=4)
            ttk.Button(col, text="Re-scan", command=self.rescan).pack(fill="x")
            ttk.Label(t, text="Systems found (click a row to tick / untick it):").pack(anchor="w", pady=(10, 0))
            self.tree = ttk.Treeview(t, columns=("use", "system", "folder", "files"), show="headings", height=14)
            for c, w, txt in (("use", 40, ""), ("system", 230, "System"), ("folder", 400, "Folder"), ("files", 80, "Files")):
                self.tree.heading(c, text=txt)
                self.tree.column(c, width=w, anchor="e" if c == "files" else "w")
            self.tree.pack(fill="both", expand=True, pady=4)
            self.tree.bind("<Button-1>", self.tree_click)
            r = ttk.Frame(t)
            r.pack(fill="x")
            ttk.Button(r, text="Tick all", command=lambda: self.tick_all(True)).pack(side="left")
            ttk.Button(r, text="Untick all", command=lambda: self.tick_all(False)).pack(side="left", padx=6)
            self.sys_label = ttk.Label(r, text="", foreground="gray")
            self.sys_label.pack(side="left", padx=10)
            self.detect_label = ttk.Label(t, text="", wraplength=900)
            self.detect_label.pack(anchor="w", pady=(6, 0))

        def add_folder(self):
            d = filedialog.askdirectory(title="Choose a folder of ROMs", initialdir=(self.lb.get("end") if self.lb.size() else "") or sorter_rom_folder() or str(Path.home()))
            if d and d not in self.lb.get(0, "end"):
                self.lb.insert("end", d)
                self.rescan()

        def remove_folder(self):
            for i in reversed(self.lb.curselection()):
                self.lb.delete(i)
            self.rescan()

        def rescan(self):
            if self.busy:
                return
            folders = list(self.lb.get(0, "end"))
            self.scan_id += 1
            sid = self.scan_id
            self.sys_label.config(text="Scanning...")

            def work():
                systems = find_systems(folders, lambda m: None)
                for s in systems:
                    count_roms(s)
                self.q.put(("systems", sid, systems))
            threading.Thread(target=work, daemon=True).start()

        def populate(self, systems):
            old = dict(self.sys_tick)
            self.systems = systems
            self.sys_tick = {}
            self.tree.delete(*self.tree.get_children())
            for s in systems:
                iid = str(s.path)
                self.sys_tick[iid] = old.get(iid, True)
                self.tree.insert("", "end", iid=iid, values=("☑" if self.sys_tick[iid] else "☐", s.label, s.folder + "  —  " + str(s.path.parent), f"{s.files:,}"))
            total = sum(s.files for s in systems)
            if systems:
                det = detect_frontend(systems, list(self.lb.get(0, "end")))
                self.detect_label.config(
                    text=f"Looks like: {det['name']} ({det['reason']}). With 'Detect from my folders' on the "
                         f"'What to save' tab, results will be saved in the {FORMATS[det['format']].split(':')[0]} layout."
                         + ("" if det["sure"] else "  (not certain)"))
            else:
                self.detect_label.config(text="")
            self.sys_label.config(text=f"{len(systems)} system(s), {total:,} files" if systems else
                                  "No known system folders found - add the folder that holds them (e.g. 'English ROMs').")

        def tree_click(self, e):
            iid = self.tree.identify_row(e.y)
            if iid and self.tree.identify_region(e.x, e.y) == "cell":
                self.sys_tick[iid] = not self.sys_tick.get(iid, True)
                v = list(self.tree.item(iid, "values"))
                v[0] = "☑" if self.sys_tick[iid] else "☐"
                self.tree.item(iid, values=v)
                return "break"

        def tick_all(self, state):
            for iid in self.sys_tick:
                self.sys_tick[iid] = state
                v = list(self.tree.item(iid, "values"))
                v[0] = "☑" if state else "☐"
                self.tree.item(iid, values=v)

        # ---- tab 2: services ----
        def build_services_tab(self):
            t = ttk.Frame(self.nb, padding=10)
            self.nb.add(t, text="2. Services")
            ttk.Label(t, text="Tick the services to use. The top one is tried first; the ones below only fill in what it is missing.").pack(anchor="w")
            self.order = [s.id for s in SERVICES]
            self.use = {s.id: False for s in SERVICES}
            row = ttk.Frame(t)
            row.pack(fill="both", expand=True, pady=6)
            self.stree = ttk.Treeview(row, columns=("use", "name", "login", "status"), show="headings", height=8)
            for c, w, txt in (("use", 40, ""), ("name", 200, "Service"), ("login", 150, "Login"), ("status", 330, "Status")):
                self.stree.heading(c, text=txt)
                self.stree.column(c, width=w, anchor="w")
            self.stree.pack(side="left", fill="both", expand=True)
            self.stree.bind("<Button-1>", self.stree_click)
            self.stree.bind("<<TreeviewSelect>>", lambda e: self.show_blurb())
            col = ttk.Frame(row)
            col.pack(side="left", padx=8, anchor="n")
            ttk.Button(col, text="Move up", command=lambda: self.move(-1)).pack(fill="x")
            ttk.Button(col, text="Move down", command=lambda: self.move(1)).pack(fill="x", pady=4)
            ttk.Button(col, text="Login / key...", command=self.edit_login).pack(fill="x", pady=(12, 0))
            self.blurb = ttk.Label(t, text="", wraplength=900, foreground="gray")
            self.blurb.pack(anchor="w", pady=4)
            ttk.Label(t, wraplength=900, foreground="gray",
                      text="Services that need a login will ask for it before scraping starts and test it. "
                           "Logins are only saved if you tick 'Remember'.").pack(anchor="w")

        def refresh_services(self, keep=None):
            self.stree.delete(*self.stree.get_children())
            for sid in self.order:
                cls = SERVICE_BY_ID[sid]
                login = {"none": "None needed", "key": "API key", "account": "Account / keys"}[cls.login]
                if cls.fields:
                    have = not [f for f in cls.fields if f[3] and not self.creds.get(sid).get(f[0])]
                    status = ("Saved - will be tested before use" if sid in self.creds.remember else "Set for this session") if have else "Not set yet - you will be asked"
                else:
                    status = "Ready"
                self.stree.insert("", "end", iid=sid, values=("☑" if self.use[sid] else "☐", cls.name, login, status))
            if keep and self.stree.exists(keep):
                self.stree.selection_set(keep)

        def stree_click(self, e):
            iid = self.stree.identify_row(e.y)
            if iid and self.stree.identify_column(e.x) == "#1":
                self.use[iid] = not self.use[iid]
                self.refresh_services(iid)
                return "break"

        def show_blurb(self):
            sel = self.stree.selection()
            if sel:
                cls = SERVICE_BY_ID[sel[0]]
                self.blurb.config(text=f"{cls.name}: {cls.blurb}  ({cls.site})")

        def move(self, d):
            sel = self.stree.selection()
            if not sel:
                return
            i = self.order.index(sel[0])
            j = i + d
            if 0 <= j < len(self.order):
                self.order[i], self.order[j] = self.order[j], self.order[i]
                self.refresh_services(sel[0])

        def edit_login(self):
            sel = self.stree.selection()
            if not sel:
                messagebox.showinfo("ROM Scraper", "Select a service first.")
                return
            cls = SERVICE_BY_ID[sel[0]]
            if not cls.fields:
                messagebox.showinfo("ROM Scraper", f"{cls.name} needs no login.")
                return
            svc = cls(self.creds, self.options(), lambda m: None)
            dlg = LoginDialog(self.win, svc, "", self.creds.get(cls.id), self.creds)
            self.win.wait_window(dlg.top)
            self.refresh_services(sel[0])

        # ---- tab 3: what to save ----
        def build_save_tab(self):
            t = ttk.Frame(self.nb, padding=10)
            self.nb.add(t, text="3. What to save")
            lf = ttk.LabelFrame(t, text="Information", padding=6)
            lf.pack(fill="x")
            self.v_fields = {k: tk.BooleanVar() for k, _ in FIELDS}
            for i, (k, label) in enumerate(FIELDS):
                ttk.Checkbutton(lf, text=label, variable=self.v_fields[k]).grid(row=i // 4, column=i % 4, sticky="w", padx=6)
            lf = ttk.LabelFrame(t, text="Pictures and video", padding=6)
            lf.pack(fill="x", pady=6)
            self.v_media = {k: tk.BooleanVar() for k, _ in MEDIA}
            for i, (k, label) in enumerate(MEDIA):
                ttk.Checkbutton(lf, text=label, variable=self.v_media[k]).grid(row=0, column=i, sticky="w", padx=6)
            lf = ttk.LabelFrame(t, text="Where it goes", padding=6)
            lf.pack(fill="x")
            self.v_format = tk.StringVar()
            for k, label in FORMATS.items():
                ttk.Radiobutton(lf, variable=self.v_format, value=k, text=label).pack(anchor="w")
            r = ttk.Frame(lf)
            r.pack(anchor="w", pady=(6, 0))
            ttk.Label(r, text="Save somewhere else (optional):").pack(side="left")
            self.v_out = tk.StringVar()
            ttk.Entry(r, textvariable=self.v_out, width=44).pack(side="left", padx=6)
            ttk.Button(r, text="Browse...", command=lambda: self.v_out.set(filedialog.askdirectory() or self.v_out.get())).pack(side="left")
            ttk.Label(lf, foreground="gray", wraplength=900,
                      text="Blank = gamelist.xml and pictures go inside each system's own folder. "
                           "Your ROMs are never moved, renamed or changed.").pack(anchor="w")
            lf = ttk.LabelFrame(t, text="Options", padding=6)
            lf.pack(fill="x", pady=6)
            self.v_skip = tk.BooleanVar()
            self.v_retry = tk.BooleanVar()
            self.v_ow_meta = tk.BooleanVar()
            self.v_ow_media = tk.BooleanVar()
            self.v_csv = tk.BooleanVar()
            self.v_hash = tk.BooleanVar()
            for var, text in ((self.v_skip, "Skip games that were already scraped (lets you stop and resume)"),
                              (self.v_retry, "Look again for games that were not found last time"),
                              (self.v_ow_meta, "Replace text already in an existing gamelist.xml"),
                              (self.v_ow_media, "Replace pictures that already exist"),
                              (self.v_hash, "Identify games by file contents too (ScreenScraper; slower, more accurate)"),
                              (self.v_csv, "Write a CSV report after each run")):
                ttk.Checkbutton(lf, variable=var, text=text).pack(anchor="w")
            r = ttk.Frame(lf)
            r.pack(anchor="w", pady=(6, 0))
            self.v_score = tk.StringVar()
            self.v_regions = tk.StringVar()
            self.v_lang = tk.StringVar()
            self.v_workers = tk.IntVar()
            ttk.Label(r, text="Match strictness (0.5 loose - 1.0 exact):").pack(side="left")
            ttk.Spinbox(r, from_=0.5, to=1.0, increment=0.05, width=5, textvariable=self.v_score).pack(side="left", padx=6)
            ttk.Label(r, text="Preferred regions:").pack(side="left", padx=(12, 0))
            ttk.Entry(r, textvariable=self.v_regions, width=18).pack(side="left", padx=6)
            ttk.Label(r, text="Language:").pack(side="left", padx=(12, 0))
            ttk.Entry(r, textvariable=self.v_lang, width=4).pack(side="left", padx=6)
            ttk.Label(r, text="Games at once:").pack(side="left", padx=(12, 0))
            ttk.Spinbox(r, from_=1, to=16, width=3, textvariable=self.v_workers).pack(side="left", padx=6)

        # ---- tab 4: speed, schedule ----
        def build_speed_tab(self):
            t = ttk.Frame(self.nb, padding=10)
            self.nb.add(t, text="4. Speed & schedule")
            self.big_speed = ttk.Label(t, text="Not downloading", font=("TkDefaultFont", 18, "bold"))
            self.big_speed.pack(anchor="w")
            self.now_label = ttk.Label(t, text="", foreground="gray")
            self.now_label.pack(anchor="w", pady=(0, 8))
            lf = ttk.LabelFrame(t, text="Speed limit (changes take effect straight away, even mid-run)", padding=8)
            lf.pack(fill="x")
            self.v_lmode = tk.StringVar(value="full")
            self.v_lval = tk.StringVar(value="500")
            self.v_lunit = tk.StringVar(value="KB/s")
            r = ttk.Frame(lf)
            r.pack(anchor="w")
            ttk.Radiobutton(r, text="Full speed", variable=self.v_lmode, value="full").pack(side="left")
            ttk.Radiobutton(r, text="Limit to", variable=self.v_lmode, value="limit").pack(side="left", padx=(14, 0))
            ttk.Spinbox(r, from_=1, to=100000, width=7, textvariable=self.v_lval).pack(side="left", padx=4)
            ttk.Combobox(r, textvariable=self.v_lunit, values=["KB/s", "MB/s"], width=6, state="readonly").pack(side="left")
            ttk.Label(lf, foreground="gray", wraplength=900,
                      text="This slows the pictures and files being downloaded so the scraper doesn't use all your "
                           "internet connection. (Each website also has its own limit on how fast it lets you ask questions.)").pack(anchor="w", pady=(4, 0))
            for v in (self.v_lmode, self.v_lval, self.v_lunit):
                v.trace_add("write", self.apply_speed)

            lf = ttk.LabelFrame(t, text="Time-of-day schedule", padding=8)
            lf.pack(fill="both", expand=True, pady=8)
            self.v_sched = tk.BooleanVar()
            self.v_sched.trace_add("write", self.apply_speed)
            ttk.Checkbutton(lf, variable=self.v_sched,
                            text="Use the schedule below (the first rule that matches the current time wins; "
                                 "outside every rule the limit above applies)").pack(anchor="w")
            self.rules = []
            self.rtree = ttk.Treeview(lf, columns=("rule",), show="headings", height=5)
            self.rtree.heading("rule", text="Rules")
            self.rtree.column("rule", width=700)
            self.rtree.pack(fill="x", pady=4)
            r = ttk.Frame(lf)
            r.pack(anchor="w", pady=4)
            self.v_from, self.v_to = tk.StringVar(value="00:00"), tk.StringVar(value="07:00")
            self.v_rspeed = tk.StringVar(value="full")
            ttk.Label(r, text="From").pack(side="left")
            ttk.Entry(r, textvariable=self.v_from, width=6).pack(side="left", padx=4)
            ttk.Label(r, text="to").pack(side="left")
            ttk.Entry(r, textvariable=self.v_to, width=6).pack(side="left", padx=4)
            ttk.Label(r, text="  Speed:").pack(side="left")
            ttk.Combobox(r, textvariable=self.v_rspeed, width=10,
                         values=["full", "pause", "100", "250", "500", "1000", "2mb", "5mb"]).pack(side="left", padx=4)
            ttk.Label(r, text="(full, pause, or KB/s - or 2mb)", foreground="gray").pack(side="left")
            r = ttk.Frame(lf)
            r.pack(anchor="w", pady=2)
            self.v_day = {d: tk.BooleanVar(value=True) for d in DAY_NAMES}
            ttk.Label(r, text="Days:").pack(side="left")
            for d in DAY_NAMES:
                ttk.Checkbutton(r, text=d.title(), variable=self.v_day[d]).pack(side="left", padx=2)
            r = ttk.Frame(lf)
            r.pack(anchor="w", pady=4)
            ttk.Button(r, text="Add rule", command=self.add_rule).pack(side="left")
            ttk.Button(r, text="Remove selected", command=self.remove_rule).pack(side="left", padx=6)
            ttk.Button(r, text="Example: full speed overnight, 300 KB/s by day", command=self.example_rules).pack(side="left")
            ttk.Label(lf, foreground="gray", wraplength=900,
                      text="Times are 24-hour on this computer's clock. A rule can cross midnight (22:00 to 06:00). "
                           "'pause' stops the scraper completely during that time and carries on afterwards.").pack(anchor="w")

        def limit_value(self):
            if self.v_lmode.get() != "limit":
                return 0
            try:
                v = float(self.v_lval.get())
            except ValueError:
                return 0
            return int(v * (1024 if self.v_lunit.get() == "MB/s" else 1))

        def apply_speed(self, *a):
            try:
                BW.configure(self.limit_value(), self.rules, self.v_sched.get())
            except (ValueError, tk.TclError):
                pass

        def refresh_rules(self):
            self.rtree.delete(*self.rtree.get_children())
            for i, r in enumerate(self.rules):
                try:
                    txt = parse_rule(r).describe()
                except ValueError:
                    txt = r
                days = r.split("@")[1].split("=")[0] if "@" in r else "every day"
                self.rtree.insert("", "end", iid=str(i), values=(f"{txt}   ({days})",))
            self.apply_speed()

        def add_rule(self):
            days = [i for i, d in enumerate(DAY_NAMES) if self.v_day[d].get()]
            if not days:
                messagebox.showinfo("ROM Scraper", "Tick at least one day.")
                return
            text = make_rule_text(self.v_from.get().strip(), self.v_to.get().strip(), days, self.v_rspeed.get().strip())
            try:
                parse_rule(text)
            except ValueError as e:
                messagebox.showinfo("ROM Scraper", str(e))
                return
            self.rules.append(text)
            self.refresh_rules()

        def remove_rule(self):
            for iid in sorted(self.rtree.selection(), key=int, reverse=True):
                del self.rules[int(iid)]
            self.refresh_rules()

        def example_rules(self):
            self.rules = ["00:00-07:00=full", "07:00-24:00=300"]
            self.v_sched.set(True)
            self.refresh_rules()

        def toggle_pause(self):
            if not self.busy:
                return
            if PAUSED.is_set():
                PAUSED.clear()
                self.b_pause.config(text="Pause")
                self.log("Resumed.")
            else:
                PAUSED.set()
                self.b_pause.config(text="Resume")
                self.log("Paused. Progress so far is saved; downloads stop within a moment. Press Resume to carry on.")

        def update_status(self):
            st = BW.status()
            n, total = self.prog
            eta = ""
            if self.busy and n > 0 and total > n and not st["state"]:
                secs = (time.time() - self.t0) / n * (total - n)
                eta = f"   about {int(secs // 3600)}h {int(secs % 3600 // 60):02d}m left" if secs >= 3600 else f"   about {int(secs // 60)}m {int(secs % 60):02d}s left"
            state = f"   [{st['state'].upper()}]" if st["state"] else ""
            line = f"Down {human(st['speed'])}/s   total {human(st['total'])}   {st['desc']}{state}"
            if self.busy and total:
                line += f"   game {n:,} of {total:,}{eta}"
            self.speed_label.config(text=line)
            self.big_speed.config(text=("Paused" if st["state"] else f"{human(st['speed'])}/s") if self.busy or st["speed"] else "Not downloading")
            self.now_label.config(text=f"Right now: {st['desc']}" + (f" ({st['state']})" if st["state"] else "")
                                  + f"   -   {human(st['total'])} downloaded this session")

        # ---- options <-> widgets ----
        def apply(self, o):
            self.lb.delete(0, "end")
            folders = o.folders or ([sorter_rom_folder()] if sorter_rom_folder() else [])
            for f in folders:
                self.lb.insert("end", f)
            ordered = [s for s in o.services if s in SERVICE_BY_ID]
            self.order = ordered + [s.id for s in SERVICES if s.id not in ordered]
            self.use = {s.id: s.id in ordered for s in SERVICES}
            self.refresh_services()
            for k, v in self.v_fields.items():
                v.set(k in o.fields)
            for k, v in self.v_media.items():
                v.set(k in o.media)
            self.v_format.set(o.format)
            self.v_out.set(o.output_dir)
            self.v_skip.set(o.skip_done)
            self.v_retry.set(o.retry_missing)
            self.v_ow_meta.set(o.overwrite_meta)
            self.v_ow_media.set(o.overwrite_media)
            self.v_csv.set(o.write_csv)
            self.v_hash.set(o.hash_lookup)
            self.v_score.set(f"{o.min_score:.2f}")
            self.v_regions.set(o.regions)
            self.v_lang.set(o.language)
            self.v_workers.set(o.workers)
            self.v_sched.set(o.schedule_on)
            self.rules = list(o.schedule)
            kb = o.limit_kbps
            self.v_lmode.set("limit" if kb else "full")
            if kb and kb % 1024 == 0:
                self.v_lval.set(str(kb // 1024))
                self.v_lunit.set("MB/s")
            else:
                self.v_lval.set(str(kb or 500))
                self.v_lunit.set("KB/s")
            self.refresh_rules()

        def options(self):
            o = Options()
            o.folders = list(self.lb.get(0, "end"))
            o.services = [sid for sid in self.order if self.use.get(sid)]
            o.fields = [k for k, v in self.v_fields.items() if v.get()]
            o.media = [k for k, v in self.v_media.items() if v.get()]
            o.format = self.v_format.get()
            o.output_dir = self.v_out.get().strip()
            o.skip_done = self.v_skip.get()
            o.retry_missing = self.v_retry.get()
            o.overwrite_meta = self.v_ow_meta.get()
            o.overwrite_media = self.v_ow_media.get()
            o.write_csv = self.v_csv.get()
            o.hash_lookup = self.v_hash.get()
            o.min_score = self.v_score.get()
            o.regions = self.v_regions.get()
            o.language = self.v_lang.get().strip() or "en"
            try:
                o.workers = int(self.v_workers.get())
            except (ValueError, tk.TclError):
                o.workers = 3
            o.limit_kbps = self.limit_value()
            o.schedule_on = self.v_sched.get()
            o.schedule = list(self.rules)
            return o.normalise()

        def close(self):
            try:
                self.options().save()
            except Exception:
                pass
            self.win.destroy()

        # ---- thread-safe plumbing ----
        def log(self, msg):
            self.q.put(("log", msg))

        def progress(self, n, total):
            self.q.put(("progress", n, total))

        def poll(self):
            try:
                while True:
                    item = self.q.get_nowait()
                    kind = item[0]
                    if kind == "log":
                        self.text.configure(state="normal")
                        self.text.insert("end", item[1] + "\n")
                        self.text.see("end")
                        self.text.configure(state="disabled")
                    elif kind == "progress":
                        self.bar["maximum"], self.bar["value"] = item[2], item[1]
                        self.prog = (item[1], item[2])
                    elif kind == "systems":
                        if item[1] == self.scan_id:
                            self.populate(item[2])
                    elif kind == "ask":
                        _, svc, reason, current, reply = item
                        dlg = LoginDialog(self.win, svc, reason, current, self.creds)
                        self.win.wait_window(dlg.top)
                        reply.put(dlg.result)
                        self.refresh_services()
                    elif kind == "done":
                        self.busy = False
                        PAUSED.clear()
                        self.b_pause.config(text="Pause")
                        self.b_pause.state(["disabled"])
                        self.b_run.state(["!disabled"])
                        self.b_dry.state(["!disabled"])
                        self.b_stop.state(["disabled"])
            except queue.Empty:
                pass
            if time.time() - self.last_status > 0.5:
                self.last_status = time.time()
                try:
                    self.update_status()
                except Exception:
                    pass
            self.win.after(100, self.poll)

        def request_stop(self):
            STOP.set()
            self.log("Stopping after the games currently in progress...")

        def start(self, dry):
            if self.busy:
                return
            o = self.options()
            if not o.folders:
                messagebox.showinfo("ROM Scraper", "Add a folder first.")
                return
            if not o.services:
                messagebox.showinfo("ROM Scraper", "Tick at least one service on the Services tab.")
                return
            if not o.fields and not o.media:
                messagebox.showinfo("ROM Scraper", "Choose something to save on the 'What to save' tab.")
                return
            picked = [iid for iid, t in self.sys_tick.items() if t]
            if self.systems and not picked:
                messagebox.showinfo("ROM Scraper", "Tick at least one system.")
                return
            o.systems = picked if self.systems else None
            o.dry_run = dry
            o.save()
            self.busy = True
            STOP.clear()
            self.b_run.state(["disabled"])
            self.b_dry.state(["disabled"])
            self.b_stop.state(["!disabled"])
            self.b_pause.state(["!disabled"])
            self.prog, self.t0 = (0, 0), time.time()
            threading.Thread(target=self.worker, args=(o,), daemon=True).start()

        def worker(self, o):
            try:
                self.log("--- " + ("DRY RUN" if o.dry_run else "SCRAPING") + " ---")
                run(o, self.creds, self.broker, self.log, self.progress, systems=None)
            except Exception:
                self.log("ERROR:\n" + traceback.format_exc())
            self.q.put(("done",))


# --------------------------------------------------------------------------- #
# Command line
# --------------------------------------------------------------------------- #

def cli(argv):
    ap = argparse.ArgumentParser(description="ROM Scraper (created by normanlove) - fetch descriptions and pictures for your ROMs.")
    ap.add_argument("--list-services", action="store_true", help="show the services and what logins they need")
    ap.add_argument("--list-systems", action="store_true", help="show the system folders found in --folders")
    ap.add_argument("--folders", help="comma-separated folders to scrape (default: the 'English ROMs' folder of the ROM folder last used in the sorter)")
    ap.add_argument("--services", help="comma-separated, in priority order (see --list-services)")
    ap.add_argument("--systems", help="only these system folder names (comma-separated)")
    ap.add_argument("--format", choices=list(FORMATS), help="output layout (default: auto = detect from the folders)")
    ap.add_argument("--output-dir", help="save pictures and lists here instead of inside each system folder")
    ap.add_argument("--fields", help="comma-separated: " + ",".join(k for k, _ in FIELDS) + " (or 'none')")
    ap.add_argument("--media", help="comma-separated: " + ",".join(k for k, _ in MEDIA) + " (or 'none')")
    ap.add_argument("--min-score", type=float)
    ap.add_argument("--regions", help="preferred regions, e.g. us,wor,eu,jp")
    ap.add_argument("--language")
    ap.add_argument("--workers", type=int)
    ap.add_argument("--rescrape", action="store_true", help="do not skip games that were already scraped")
    ap.add_argument("--retry-missing", action="store_true")
    ap.add_argument("--overwrite-meta", action="store_true")
    ap.add_argument("--overwrite-media", action="store_true")
    ap.add_argument("--no-hash", action="store_true", help="do not read ROM contents to identify them")
    ap.add_argument("--limit", type=float, metavar="KB_PER_SEC", help="download speed limit in KB/s (0 = full speed)")
    ap.add_argument("--schedule", action="append", metavar="RULE",
                    help="time-of-day speed rule, repeatable: e.g. 00:00-07:00=full  07:00-23:00@mon-fri=300  "
                         "12:00-13:00=pause  (speed = full, pause, KB/s, or 2mb)")
    ap.add_argument("--no-report", action="store_true", help="do not write the CSV report")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)

    if a.list_services:
        for s in SERVICES:
            print(f"{s.id:14s} {s.name:26s} {'login: ' + ', '.join(f[1] for f in s.fields if f[3]) if s.fields else 'no login needed'}")
            print(f"{'':14s} {s.blurb}")
        return 0
    o = Options.load()
    if a.folders:
        o.folders = [x.strip() for x in a.folders.split(",") if x.strip()]
    if not o.folders:
        o.folders = [sorter_rom_folder()] if sorter_rom_folder() else []
    if not o.folders:
        print("No ROM folders chosen. Use --folders \"path1,path2\" (or pick folders in the GUI).")
        return 2
    if a.list_systems:
        for s in find_systems(o.folders):
            print(f"{s.label:34s} {count_roms(s):>7,} files  {s.path}")
        return 0
    if a.services:
        o.services = [x.strip().lower() for x in a.services.split(",") if x.strip()]
        bad = [x for x in o.services if x not in SERVICE_BY_ID]
        if bad:
            ap.error("unknown service(s): " + ", ".join(bad))
    if a.systems:
        names = {x.strip().lower() for x in a.systems.split(",")}
        o.systems = [str(s.path) for s in find_systems(o.folders) if s.folder.lower() in names or s.label.lower() in names]
    if a.format:
        o.format = a.format
    if a.output_dir:
        o.output_dir = a.output_dir
    if a.fields:
        o.fields = [] if a.fields == "none" else [x.strip() for x in a.fields.split(",") if x.strip()]
    if a.media:
        o.media = [] if a.media == "none" else [x.strip() for x in a.media.split(",") if x.strip()]
    if a.min_score is not None:
        o.min_score = a.min_score
    if a.regions:
        o.regions = a.regions
    if a.language:
        o.language = a.language
    if a.workers:
        o.workers = a.workers
    o.skip_done = not a.rescrape
    o.retry_missing = a.retry_missing
    o.overwrite_meta, o.overwrite_media = a.overwrite_meta, a.overwrite_media
    o.hash_lookup = o.hash_lookup and not a.no_hash
    o.write_csv = not a.no_report
    o.dry_run = a.dry_run
    if a.limit is not None:
        o.limit_kbps = a.limit
    if a.schedule:
        o.schedule, o.schedule_on = list(a.schedule), True
        for r in o.schedule:
            try:
                parse_rule(r)
            except ValueError as e:
                ap.error(str(e))
    creds = Credentials()
    result = {}

    def target():
        try:
            result["s"] = run(o, creds, CliBroker(creds), print, lambda n, t: None)
        except Exception:
            traceback.print_exc()
            result["s"] = {"errors": 1}
    th = threading.Thread(target=target, daemon=True)
    th.start()
    last = time.time()
    while th.is_alive():
        try:
            th.join(0.5)
            if time.time() - last >= 20:
                last = time.time()
                st = BW.status()
                if st["speed"] > 0 or st["state"]:
                    print(f"  [{human(st['speed'])}/s, {human(st['total'])} downloaded, {st['desc']}"
                          + (f", {st['state']}" if st["state"] else "") + "]")
        except KeyboardInterrupt:                    # Ctrl+C = pause
            PAUSED.set()
            print("\nPaused (progress is saved). Press Enter to resume, or type s then Enter to stop.")
            try:
                ans = input("> ") if sys.stdin and sys.stdin.isatty() else "s"
            except (EOFError, KeyboardInterrupt):
                ans = "s"
            if ans.strip().lower().startswith("s"):
                STOP.set()
            else:
                print("Resuming...")
            PAUSED.clear()
    th.join()
    return 1 if result.get("s", {}).get("errors") else 0


def main():
    if len(sys.argv) > 1:
        sys.exit(cli(sys.argv[1:]))
    if tk is None:
        print("Tkinter is not available in this Python installation. Use the command line: python rom_scraper.py --help")
        sys.exit(1)
    win = tk.Tk()
    App(win)
    win.mainloop()


if __name__ == "__main__":
    main()
